package com.siegmann.oneblockadventure;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;
import com.siegmann.oneblockadventure.core.module.CoreModules;
import com.siegmann.oneblockadventure.core.module.ModuleRegistry;
import com.siegmann.oneblockadventure.core.migration.MigrationManager;

@Mod(SiegmannOneblockAdventure.MOD_ID)
public final class SiegmannOneblockAdventure {
    public static final String MOD_ID = "siegmann_oneblock_adventure";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SiegmannOneblockAdventure(IEventBus modBus) {
        CoreModules.registerAll();
        ModuleRegistry.initializeAll();
        var migration = MigrationManager.migrate();
        LOGGER.info(migration.message());
        ExternalContentConfig.load();
        DataDrivenCore.reload();
        LOGGER.info("SiegmannOneblockAdventure loaded");
    }
}
