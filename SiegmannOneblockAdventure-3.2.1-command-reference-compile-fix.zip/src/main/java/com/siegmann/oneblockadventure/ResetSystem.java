package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;

public final class ResetSystem {
    private ResetSystem(){}
    public static int reset(ServerPlayer admin, ServerPlayer target, String confirmation) {
        if(!"CONFIRM".equalsIgnoreCase(confirmation)){
            admin.sendSystemMessage(Component.literal("Reset cancelled. Use /soa admin resetplayer <player> CONFIRM").withStyle(ChatFormatting.RED));return 0;
        }
        ServerLevel overworld=admin.getServer().overworld();
        MultiOneSavedData multi=MultiOneSavedData.get(overworld);
        multi.byOwner(target.getUUID()).ifPresent(island->{ServerLevel level=admin.getServer().getLevel(island.dimension());if(level!=null){BlockPos p=island.pos();for(int x=-12;x<=12;x++)for(int y=-6;y<=12;y++)for(int z=-12;z<=12;z++)level.setBlockAndUpdate(p.offset(x,y,z),Blocks.AIR.defaultBlockState());}});
        multi.clearCompletely(target.getUUID());
        EconomySavedData.get(overworld).clear(target.getUUID());
        AdventureSavedData.get(overworld).clearPlayer(target.getUUID());
        PrestigeSavedData.get(overworld).clear(target.getUUID());
        QuestSavedData.get(overworld).clear(target.getUUID());
        CommunitySavedData.get(overworld).clearPlayer(target.getUUID());
        target.getInventory().clearContent();
        target.getEnderChestInventory().clearContent();
        target.setExperienceLevels(0);target.setExperiencePoints(0);target.setHealth(target.getMaxHealth());target.getFoodData().setFoodLevel(20);
        target.teleportTo(overworld,overworld.getSharedSpawnPos().getX()+0.5D,overworld.getSharedSpawnPos().getY()+1D,overworld.getSharedSpawnPos().getZ()+0.5D,0F,0F);
        RankSystem.update(target,0L);ScoreboardSystem.update(target,0L);
        admin.sendSystemMessage(Component.literal("Completely reset "+target.getName().getString()+". Their island area, inventory, economy, ranks, titles, rewards, quests, skills, kits, prestige, marketplace listings, statistics, playtime rewards, and progression were cleared.").withStyle(ChatFormatting.GREEN));
        target.sendSystemMessage(Component.literal("Your Siegmann OneBlock Adventure profile was reset by an administrator. Use /soa startnew to begin again.").withStyle(ChatFormatting.GOLD));
        return 1;
    }
}
