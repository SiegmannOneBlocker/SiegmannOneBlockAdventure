package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Persistent server-wide expansion settings and per-player class choices. */
public final class ServerSystemsSavedData extends SavedData {
    private static final String NAME = "soa_server_systems";
    private static final Factory<ServerSystemsSavedData> FACTORY =
            new Factory<>(ServerSystemsSavedData::new, ServerSystemsSavedData::load, null);

    private final Map<UUID, String> playerClasses = new HashMap<>();
    private int economyBuyPercent = 100;
    private int economySellPercent = 100;
    private boolean classesLockedAfterSelection = true;
    private long seasonNumber = 1;

    public static ServerSystemsSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    public String playerClass(UUID player) { return playerClasses.getOrDefault(player, "none"); }
    public boolean hasClass(UUID player) { return !"none".equals(playerClass(player)); }
    public boolean setPlayerClass(UUID player, String value, boolean force) {
        String normalized = value == null ? "none" : value.toLowerCase(Locale.ROOT);
        if (!force && classesLockedAfterSelection && hasClass(player)) return false;
        if ("none".equals(normalized)) playerClasses.remove(player); else playerClasses.put(player, normalized);
        setDirty();
        return true;
    }
    public int economyBuyPercent() { return economyBuyPercent; }
    public int economySellPercent() { return economySellPercent; }
    public void setEconomyBuyPercent(int value) { economyBuyPercent = clamp(value); setDirty(); }
    public void setEconomySellPercent(int value) { economySellPercent = clamp(value); setDirty(); }
    public boolean classesLockedAfterSelection() { return classesLockedAfterSelection; }
    public void setClassesLockedAfterSelection(boolean value) { classesLockedAfterSelection = value; setDirty(); }
    public long seasonNumber() { return seasonNumber; }
    public void nextSeason() { seasonNumber++; setDirty(); }
    private static int clamp(int value) { return Math.max(10, Math.min(500, value)); }

    private static ServerSystemsSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        ServerSystemsSavedData data = new ServerSystemsSavedData();
        data.economyBuyPercent = clamp(tag.contains("EconomyBuy") ? tag.getInt("EconomyBuy") : 100);
        data.economySellPercent = clamp(tag.contains("EconomySell") ? tag.getInt("EconomySell") : 100);
        data.classesLockedAfterSelection = !tag.contains("ClassLock") || tag.getBoolean("ClassLock");
        data.seasonNumber = Math.max(1L, tag.getLong("SeasonNumber"));
        ListTag classes = tag.getList("Classes", Tag.TAG_COMPOUND);
        for (int i = 0; i < classes.size(); i++) {
            CompoundTag entry = classes.getCompound(i);
            if (entry.hasUUID("Player")) data.playerClasses.put(entry.getUUID("Player"), entry.getString("Class"));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("EconomyBuy", economyBuyPercent);
        tag.putInt("EconomySell", economySellPercent);
        tag.putBoolean("ClassLock", classesLockedAfterSelection);
        tag.putLong("SeasonNumber", seasonNumber);
        ListTag classes = new ListTag();
        playerClasses.forEach((player, value) -> {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Player", player);
            entry.putString("Class", value);
            classes.add(entry);
        });
        tag.put("Classes", classes);
        return tag;
    }
}
