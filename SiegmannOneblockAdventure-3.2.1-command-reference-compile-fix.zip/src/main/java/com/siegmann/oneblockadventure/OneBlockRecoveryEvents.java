package com.siegmann.oneblockadventure;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.List;

/**
 * Restores and advances a player's OneBlock when automation removes it without
 * firing a normal player BlockEvent.BreakEvent. This is required for Create's
 * Mechanical Drill and similar contraption-based breakers.
 */
@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class OneBlockRecoveryEvents {
    private OneBlockRecoveryEvents() {}

    @SubscribeEvent
    public static void afterServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        MultiOneSavedData storage = MultiOneSavedData.get(server.overworld());

        // Copy the collection because advancing an island updates saved data.
        for (MultiOneSavedData.Island island : List.copyOf(storage.all())) {
            ServerLevel level = server.getLevel(island.dimension());
            if (level == null || !level.hasChunkAt(island.pos())) {
                continue;
            }

            var state = level.getBlockState(island.pos());

            // Defensive cleanup for old configs or earlier builds that allowed a
            // water/lava source to occupy the OneBlock position. Replace it
            // without advancing progress or creating drops.
            if (!state.getFluidState().isEmpty()) {
                level.setBlockAndUpdate(island.pos(), CreateProgression.nextBlock(level, island.generated()));
                continue;
            }

            // A normal player break is cancelled and replaced immediately, so
            // an air block here means automation removed the OneBlock directly.
            if (!state.isAir()) {
                continue;
            }

            ServerPlayer owner = server.getPlayerList().getPlayer(island.owner());
            MultiOneEvents.advanceIsland(level, island, owner, null, false);
        }
    }
}
