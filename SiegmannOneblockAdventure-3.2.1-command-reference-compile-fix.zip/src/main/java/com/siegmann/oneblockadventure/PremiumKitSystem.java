package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantments;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** Expensive, repeatable progression kits containing named and enchanted equipment. */
public final class PremiumKitSystem {
    private PremiumKitSystem() {}

    private record Kit(String id, String name, Item icon, long price, int requiredPhase, String description) {}

    private static final List<Kit> KITS = List.of(
            new Kit("builder", "Master Builder Kit", Items.DIAMOND_AXE, 250_000L, 25,
                    "Enchanted building tools, lighting, scaffolding, and premium materials."),
            new Kit("miner", "Fortune Miner Kit", Items.DIAMOND_PICKAXE, 1_500_000L, 75,
                    "A powerful Fortune pickaxe with mining supplies and valuable ores."),
            new Kit("warrior", "Champion Combat Kit", Items.DIAMOND_SWORD, 3_500_000L, 100,
                    "High-grade enchanted weapons, armor, food, and survival items."),
            new Kit("engineer", "Master Engineer Kit", Items.REDSTONE, 7_500_000L, 140,
                    "Rare Create components, precision mechanisms, and enchanted tools."),
            new Kit("netherite", "Netherite Artisan Kit", Items.NETHERITE_PICKAXE, 20_000_000L, 200,
                    "Named Netherite tools with premium enchantments and ancient materials."),
            new Kit("legend", "OneBlock Legend Kit", Items.NETHER_STAR, 75_000_000L, 250,
                    "The most valuable kit: elite tools, armor, rare items, and endgame supplies.")
    );

    public static void openMenu(ServerPlayer player) {
        SimpleContainer container = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();
        int[] slots = {10, 12, 14, 16, 28, 32};
        int phase = phase(player);

        for (int i = 0; i < KITS.size(); i++) {
            Kit kit = KITS.get(i);
            boolean unlocked = phase >= kit.requiredPhase();
            ItemStack icon = new ItemStack(unlocked ? kit.icon() : Items.GRAY_DYE);
            icon.set(DataComponents.CUSTOM_NAME, Component.literal(kit.name())
                    .withStyle(unlocked ? ChatFormatting.GOLD : ChatFormatting.DARK_GRAY, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new ItemLore(List.of(
                    Component.literal(kit.description()).withStyle(ChatFormatting.GRAY),
                    Component.literal("Price: $" + String.format("%,d", kit.price())).withStyle(ChatFormatting.GREEN),
                    Component.literal("Required phase: " + kit.requiredPhase()).withStyle(unlocked ? ChatFormatting.YELLOW : ChatFormatting.RED),
                    Component.literal(unlocked ? "Click to review and purchase." : "This kit is still locked.")
                            .withStyle(unlocked ? ChatFormatting.AQUA : ChatFormatting.DARK_RED)
            )));
            container.setItem(slots[i], icon);
            if (unlocked) actions.put(slots[i], p -> openDetails(p, kit));
        }

        ItemStack balance = new ItemStack(Items.GOLD_INGOT);
        balance.set(DataComponents.CUSTOM_NAME, Component.literal("Your Balance").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        balance.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("$" + String.format("%,d", EconomySavedData.get(player.serverLevel()).balance(player.getUUID()))).withStyle(ChatFormatting.GREEN))));
        container.setItem(4, balance);

        back(container, actions, 49);
        open(player, container, actions, 6, "Premium Kits");
    }

    private static void openDetails(ServerPlayer player, Kit kit) {
        SimpleContainer container = new SimpleContainer(45);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();

        List<ItemStack> preview = contents(player, kit.id());
        int slot = 10;
        for (ItemStack stack : preview) {
            if (slot == 17) slot = 19;
            if (slot >= 35) break;
            container.setItem(slot++, stack.copy());
        }

        ItemStack buy = new ItemStack(Items.EMERALD_BLOCK);
        buy.set(DataComponents.CUSTOM_NAME, Component.literal("Buy " + kit.name()).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
        buy.set(DataComponents.LORE, new ItemLore(List.of(
                Component.literal("Price: $" + String.format("%,d", kit.price())).withStyle(ChatFormatting.GOLD),
                Component.literal("Kits can be purchased more than once.").withStyle(ChatFormatting.GRAY),
                Component.literal("Click to confirm purchase.").withStyle(ChatFormatting.AQUA)
        )));
        container.setItem(40, buy);
        actions.put(40, p -> purchase(p, kit));

        ItemStack cancel = new ItemStack(Items.BARRIER);
        cancel.set(DataComponents.CUSTOM_NAME, Component.literal("Back to Premium Kits").withStyle(ChatFormatting.RED));
        container.setItem(36, cancel);
        actions.put(36, PremiumKitSystem::openMenu);

        open(player, container, actions, 5, kit.name());
    }

    private static void purchase(ServerPlayer player, Kit kit) {
        int phase = phase(player);
        if (phase < kit.requiredPhase()) {
            player.sendSystemMessage(Component.literal("This kit unlocks at Phase " + kit.requiredPhase() + ".").withStyle(ChatFormatting.RED));
            openMenu(player);
            return;
        }
        EconomySavedData economy = EconomySavedData.get(player.serverLevel());
        if (!economy.take(player.getUUID(), kit.price())) {
            player.sendSystemMessage(Component.literal("You need $" + String.format("%,d", kit.price()) + " to buy this kit.").withStyle(ChatFormatting.RED));
            openDetails(player, kit);
            return;
        }

        for (ItemStack stack : contents(player, kit.id())) {
            if (!stack.isEmpty() && !player.getInventory().add(stack.copy())) player.drop(stack.copy(), false);
        }
        player.closeContainer();
        player.sendSystemMessage(Component.literal("Purchased the " + kit.name() + " for $" + String.format("%,d", kit.price()) + "!")
                .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
    }

    private static List<ItemStack> contents(ServerPlayer player, String id) {
        return switch (id) {
            case "builder" -> List.of(
                    enchanted(player, Items.DIAMOND_AXE, "Architect's Axe", 4, 3, 0, 0, 1),
                    enchanted(player, Items.DIAMOND_PICKAXE, "Architect's Pickaxe", 4, 3, 1, 0, 1),
                    enchanted(player, Items.DIAMOND_SHOVEL, "Architect's Shovel", 4, 3, 0, 0, 1),
                    new ItemStack(Items.SCAFFOLDING, 64), new ItemStack(Items.LANTERN, 32),
                    new ItemStack(Items.QUARTZ_BLOCK, 64), new ItemStack(Items.DEEPSLATE_BRICKS, 64),
                    new ItemStack(Items.GLASS, 64), new ItemStack(Items.ENDER_CHEST));
            case "miner" -> List.of(
                    enchanted(player, Items.DIAMOND_PICKAXE, "Fortune Seeker", 5, 3, 3, 0, 1),
                    enchanted(player, Items.DIAMOND_PICKAXE, "Silk Delver", 5, 3, 0, 1, 1),
                    new ItemStack(Items.TORCH, 64), new ItemStack(Items.EXPERIENCE_BOTTLE, 64),
                    new ItemStack(Items.DIAMOND, 16), new ItemStack(Items.EMERALD, 32),
                    new ItemStack(Items.GOLD_INGOT, 64), new ItemStack(Items.IRON_INGOT, 64));
            case "warrior" -> List.of(
                    combatSword(player, Items.DIAMOND_SWORD, "Champion's Blade", 5, 3, 3, 1),
                    enchantedArmor(player, Items.DIAMOND_CHESTPLATE, "Champion's Plate", 4, 3, 1),
                    enchantedArmor(player, Items.DIAMOND_LEGGINGS, "Champion's Guard", 4, 3, 1),
                    enchantedArmor(player, Items.DIAMOND_HELMET, "Champion's Helm", 4, 3, 1),
                    enchantedArmor(player, Items.DIAMOND_BOOTS, "Champion's Steps", 4, 3, 1),
                    new ItemStack(Items.TOTEM_OF_UNDYING, 2), new ItemStack(Items.GOLDEN_APPLE, 16),
                    new ItemStack(Items.COOKED_BEEF, 64));
            case "engineer" -> List.of(
                    enchanted(player, Items.DIAMOND_PICKAXE, "Engineer's Calibrator", 5, 3, 1, 0, 1),
                    modItem("create:wrench", 1), modItem("create:precision_mechanism", 16),
                    modItem("create:brass_casing", 32), modItem("create:mechanical_crafter", 16),
                    modItem("create:deployer", 4), modItem("create:mechanical_arm", 2),
                    modItem("create:railway_casing", 16), modItem("create:track", 64));
            case "netherite" -> List.of(
                    enchanted(player, Items.NETHERITE_PICKAXE, "Ancient Fortune", 5, 3, 3, 0, 1),
                    enchanted(player, Items.NETHERITE_AXE, "Ancient Cleaver", 5, 3, 0, 0, 1),
                    enchanted(player, Items.NETHERITE_SHOVEL, "Ancient Excavator", 5, 3, 0, 1, 1),
                    combatSword(player, Items.NETHERITE_SWORD, "Ancient Edge", 5, 3, 3, 1),
                    new ItemStack(Items.NETHERITE_INGOT, 4), new ItemStack(Items.ANCIENT_DEBRIS, 16),
                    new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
            default -> List.of(
                    enchanted(player, Items.NETHERITE_PICKAXE, "OneBlock Breaker", 6, 4, 4, 0, 1),
                    combatSword(player, Items.NETHERITE_SWORD, "Legend's Judgment", 6, 4, 4, 1),
                    enchantedArmor(player, Items.NETHERITE_CHESTPLATE, "Legend's Aegis", 5, 4, 1),
                    enchantedArmor(player, Items.NETHERITE_LEGGINGS, "Legend's Resolve", 5, 4, 1),
                    enchantedArmor(player, Items.NETHERITE_HELMET, "Legend's Crown", 5, 4, 1),
                    enchantedArmor(player, Items.NETHERITE_BOOTS, "Legend's Flight", 5, 4, 1),
                    new ItemStack(Items.ELYTRA), new ItemStack(Items.NETHER_STAR, 4),
                    new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 8), new ItemStack(Items.TOTEM_OF_UNDYING, 8),
                    new ItemStack(Items.SHULKER_BOX, 4), new ItemStack(Items.BEACON));
        };
    }

    private static ItemStack enchanted(ServerPlayer player, Item item, String name, int efficiency, int unbreaking, int fortune, int silkTouch, int mending) {
        ItemStack stack = named(item, name);
        var enchantments = player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        if (efficiency > 0) stack.enchant(enchantments.getOrThrow(Enchantments.EFFICIENCY), efficiency);
        if (unbreaking > 0) stack.enchant(enchantments.getOrThrow(Enchantments.UNBREAKING), unbreaking);
        if (fortune > 0) stack.enchant(enchantments.getOrThrow(Enchantments.FORTUNE), fortune);
        if (silkTouch > 0) stack.enchant(enchantments.getOrThrow(Enchantments.SILK_TOUCH), silkTouch);
        if (mending > 0) stack.enchant(enchantments.getOrThrow(Enchantments.MENDING), mending);
        return stack;
    }

    private static ItemStack combatSword(ServerPlayer player, Item item, String name, int sharpness, int unbreaking, int looting, int mending) {
        ItemStack stack = named(item, name);
        var enchantments = player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        stack.enchant(enchantments.getOrThrow(Enchantments.SHARPNESS), sharpness);
        stack.enchant(enchantments.getOrThrow(Enchantments.UNBREAKING), unbreaking);
        stack.enchant(enchantments.getOrThrow(Enchantments.LOOTING), looting);
        if (mending > 0) stack.enchant(enchantments.getOrThrow(Enchantments.MENDING), mending);
        return stack;
    }

    private static ItemStack enchantedArmor(ServerPlayer player, Item item, String name, int protection, int unbreaking, int mending) {
        ItemStack stack = named(item, name);
        var enchantments = player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        stack.enchant(enchantments.getOrThrow(Enchantments.PROTECTION), protection);
        stack.enchant(enchantments.getOrThrow(Enchantments.UNBREAKING), unbreaking);
        if (mending > 0) stack.enchant(enchantments.getOrThrow(Enchantments.MENDING), mending);
        return stack;
    }

    private static ItemStack named(Item item, String name) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
        return stack;
    }

    private static ItemStack modItem(String id, int count) {
        Item item = AdventureSystem.resolve(id);
        return item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item, count);
    }

    private static int phase(ServerPlayer player) {
        long generated = MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID())
                .map(MultiOneSavedData.Island::generated).orElse(-1L);
        return generated < 0 ? 0 : Math.min(CreateProgression.STORY_PHASES,
                (int) (generated / CreateProgression.BLOCKS_PER_PHASE) + 1);
    }

    private static void back(SimpleContainer container, Map<Integer, Consumer<ServerPlayer>> actions, int slot) {
        ItemStack stack = new ItemStack(Items.BARRIER);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal("Back").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        stack.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("Return to the main menu.").withStyle(ChatFormatting.GRAY))));
        container.setItem(slot, stack);
        actions.put(slot, AdventureSystem::openMenu);
    }

    private static void open(ServerPlayer player, SimpleContainer container, Map<Integer, Consumer<ServerPlayer>> actions, int rows, String title) {
        player.openMenu(new SimpleMenuProvider((id, inventory, p) -> new ActionMenu(rows, id, inventory, container, actions), Component.literal(title)));
    }
}
