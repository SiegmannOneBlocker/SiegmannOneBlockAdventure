package com.siegmann.oneblockadventure;

import net.minecraft.commands.Commands;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** Phase 1 command organization aliases. Legacy roots remain available for compatibility. */
@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class Phase1Commands {
    private Phase1Commands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        var dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("soa")
                .then(Commands.literal("home").executes(context -> {
                    AdventureSystem.openMenu(context.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("guide").executes(context -> {
                    Stage31Menus.openGuide(context.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("profile").executes(context -> {
                    JoinMessageService.sendReturningJoin(
                            context.getSource().getPlayerOrException(),
                            MultiOneSavedData.get(context.getSource().getLevel())
                                    .byOwner(context.getSource().getPlayerOrException().getUUID())
                                    .map(MultiOneSavedData.Island::generated)
                                    .orElse(0L),
                            MailSavedData.get(context.getSource().getLevel())
                                    .box(context.getSource().getPlayerOrException().getUUID()).size());
                    return 1;
                }))
                .then(Commands.literal("admin").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("menu").executes(context -> {
                            AdminControlMenu.open(context.getSource().getPlayerOrException());
                            return 1;
                        }))
                        .then(Commands.literal("diagnostics").executes(context ->
                                DiagnosticsSystem.run(context.getSource().getPlayerOrException())))
                        .then(Commands.literal("compatibility").executes(context -> {
                            Stage31Menus.openCompatibility(context.getSource().getPlayerOrException());
                            return 1;
                        }))));
    }
}
