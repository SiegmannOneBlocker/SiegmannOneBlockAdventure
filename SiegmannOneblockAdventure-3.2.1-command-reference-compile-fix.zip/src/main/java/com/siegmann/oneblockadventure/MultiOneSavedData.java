package com.siegmann.oneblockadventure;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class MultiOneSavedData extends SavedData {
    private static final String NAME = "craftbound_multione";
    private static final Factory<MultiOneSavedData> FACTORY =
            new Factory<>(MultiOneSavedData::new, MultiOneSavedData::load, null);

    public record Island(UUID owner, ResourceKey<Level> dimension, BlockPos pos, long generated) {
        public Island withGenerated(long value) {
            return new Island(owner, dimension, pos, Math.max(0L, value));
        }
    }

    private final Map<UUID, Island> islands = new HashMap<>();
    private final Set<UUID> everCreated = new HashSet<>();
    private final Map<UUID, Long> lastSetEpochMillis = new HashMap<>();

    public static MultiOneSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    public Optional<Island> byOwner(UUID owner) {
        return Optional.ofNullable(islands.get(owner));
    }

    public Optional<Island> at(ResourceKey<Level> dimension, BlockPos pos) {
        return islands.values().stream()
                .filter(i -> i.dimension().equals(dimension) && i.pos().equals(pos))
                .findFirst();
    }

    public boolean hasEverCreated(UUID owner) {
        return everCreated.contains(owner) || islands.containsKey(owner);
    }

    public void markCreated(UUID owner) {
        everCreated.add(owner);
        setDirty();
    }

    public long lastSetTime(UUID owner) {
        return lastSetEpochMillis.getOrDefault(owner, 0L);
    }

    public void markSetNow(UUID owner, long now) {
        lastSetEpochMillis.put(owner, Math.max(0L, now));
        setDirty();
    }

    public Collection<Island> all() {
        return Collections.unmodifiableCollection(islands.values());
    }

    public void put(Island island) {
        islands.put(island.owner(), island);
        setDirty();
    }

    public boolean remove(UUID owner) {
        boolean removed = islands.remove(owner) != null;
        if (removed) setDirty();
        return removed;
    }

    public void clearCompletely(UUID owner) {
        islands.remove(owner);
        everCreated.remove(owner);
        lastSetEpochMillis.remove(owner);
        setDirty();
    }

    private static MultiOneSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        MultiOneSavedData data = new MultiOneSavedData();
        ListTag list = tag.getList("Islands", Tag.TAG_COMPOUND);
        for (int index = 0; index < list.size(); index++) {
            CompoundTag entry = list.getCompound(index);
            try {
                UUID owner = entry.getUUID("Owner");
                ResourceLocation id = ResourceLocation.parse(entry.getString("Dimension"));
                ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, id);
                BlockPos pos = new BlockPos(entry.getInt("X"), entry.getInt("Y"), entry.getInt("Z"));
                long generated = Math.max(0L, entry.getLong("Generated"));
                data.islands.put(owner, new Island(owner, dimension, pos, generated));
                data.everCreated.add(owner);
            } catch (RuntimeException ex) {
                SiegmannOneblockAdventure.LOGGER.warn("Skipped invalid MultiOne island save entry", ex);
            }
        }
        ListTag createdList = tag.getList("EverCreated", Tag.TAG_COMPOUND);
        for (int index = 0; index < createdList.size(); index++) {
            CompoundTag entry = createdList.getCompound(index);
            if (entry.hasUUID("Owner")) data.everCreated.add(entry.getUUID("Owner"));
        }
        ListTag cooldownList = tag.getList("SetCooldowns", Tag.TAG_COMPOUND);
        for (int index = 0; index < cooldownList.size(); index++) {
            CompoundTag entry = cooldownList.getCompound(index);
            if (entry.hasUUID("Owner")) data.lastSetEpochMillis.put(entry.getUUID("Owner"), Math.max(0L, entry.getLong("Time")));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Island island : islands.values()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Owner", island.owner());
            entry.putString("Dimension", island.dimension().location().toString());
            entry.putInt("X", island.pos().getX());
            entry.putInt("Y", island.pos().getY());
            entry.putInt("Z", island.pos().getZ());
            entry.putLong("Generated", island.generated());
            list.add(entry);
        }
        tag.put("Islands", list);

        ListTag createdList = new ListTag();
        for (UUID owner : everCreated) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Owner", owner);
            createdList.add(entry);
        }
        tag.put("EverCreated", createdList);

        ListTag cooldownList = new ListTag();
        for (Map.Entry<UUID, Long> cooldown : lastSetEpochMillis.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Owner", cooldown.getKey());
            entry.putLong("Time", cooldown.getValue());
            cooldownList.add(entry);
        }
        tag.put("SetCooldowns", cooldownList);
        return tag;
    }
}
