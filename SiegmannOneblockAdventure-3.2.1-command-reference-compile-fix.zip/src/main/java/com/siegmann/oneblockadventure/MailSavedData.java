package com.siegmann.oneblockadventure;
import net.minecraft.core.HolderLookup;import net.minecraft.nbt.*;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.level.saveddata.SavedData;import java.util.*;
public final class MailSavedData extends SavedData{
 private static final String NAME="soa_mail";private static final Factory<MailSavedData> FACTORY=new Factory<>(MailSavedData::new,MailSavedData::load,null);
 public record Mail(long id,UUID sender,String senderName,String message,String itemId,int count,long cash,long created){}
 private final Map<UUID,List<Mail>> boxes=new HashMap<>();private long nextId=1;
 public static MailSavedData get(ServerLevel l){return l.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY,NAME);}public List<Mail> box(UUID id){return List.copyOf(boxes.getOrDefault(id,List.of()));}
 public Mail send(UUID to,UUID from,String name,String msg,String item,int count,long cash){Mail m=new Mail(nextId++,from,name,msg,item,Math.max(0,count),Math.max(0,cash),System.currentTimeMillis());boxes.computeIfAbsent(to,x->new ArrayList<>()).add(m);setDirty();return m;}
 public Mail remove(UUID to,long id){List<Mail>b=boxes.get(to);if(b==null)return null;for(int i=0;i<b.size();i++)if(b.get(i).id()==id){Mail m=b.remove(i);setDirty();return m;}return null;}
 private static MailSavedData load(CompoundTag t,HolderLookup.Provider p){MailSavedData d=new MailSavedData();d.nextId=Math.max(1,t.getLong("Next"));ListTag l=t.getList("Boxes",Tag.TAG_COMPOUND);for(int i=0;i<l.size();i++){CompoundTag e=l.getCompound(i);if(!e.hasUUID("To"))continue;UUID to=e.getUUID("To"),from=e.hasUUID("From")?e.getUUID("From"):new UUID(0,0);d.boxes.computeIfAbsent(to,x->new ArrayList<>()).add(new Mail(e.getLong("Id"),from,e.getString("FromName"),e.getString("Message"),e.getString("Item"),e.getInt("Count"),e.getLong("Cash"),e.getLong("Created")));}return d;}
 public CompoundTag save(CompoundTag t,HolderLookup.Provider p){t.putLong("Next",nextId);ListTag l=new ListTag();boxes.forEach((to,ms)->ms.forEach(m->{CompoundTag e=new CompoundTag();e.putUUID("To",to);e.putUUID("From",m.sender());e.putLong("Id",m.id());e.putString("FromName",m.senderName());e.putString("Message",m.message());e.putString("Item",m.itemId());e.putInt("Count",m.count());e.putLong("Cash",m.cash());e.putLong("Created",m.created());l.add(e);}));t.put("Boxes",l);return t;}
}
