package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Locale;

/** One-time skill kits at levels 5, 10, 20, 35 and 50. */
public final class SkillKitSystem {
    private static final int[] LEVELS = {5, 10, 20, 35, 50};
    private SkillKitSystem() {}

    public static int claim(ServerPlayer player, String skill) {
        skill = skill.toLowerCase(Locale.ROOT);
        AdventureSavedData data = AdventureSavedData.get(player.serverLevel());
        AdventureSavedData.Profile p = data.profile(player.getUUID());
        int level = switch (skill) {
            case "mining" -> AdventureSystem.skillLevel(p.miningXp);
            case "engineering" -> AdventureSystem.skillLevel(p.engineeringXp);
            case "farming" -> AdventureSystem.skillLevel(p.farmingXp);
            case "combat" -> AdventureSystem.skillLevel(p.combatXp);
            default -> -1;
        };
        if (level < 0) { player.sendSystemMessage(Component.literal("Use mining, engineering, farming, or combat.")); return 0; }
        int claimed = claimedTier(p, skill);
        int available = availableTier(level);
        if (available <= claimed) {
            player.sendSystemMessage(Component.literal("No new " + skill + " kit is available. Next kits unlock at levels 5, 10, 20, 35, and 50.").withStyle(ChatFormatting.YELLOW));
            return 0;
        }
        give(player, skill, available);
        setClaimedTier(p, skill, available);
        data.dirty();
        player.sendSystemMessage(Component.literal("Claimed the " + skill + " skill kit, tier " + available + "!").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
        return 1;
    }

    public static int nextKitLevel(ServerPlayer player, String skill) {
        AdventureSavedData.Profile p = AdventureSavedData.get(player.serverLevel()).profile(player.getUUID());
        int claimed = claimedTier(p, skill.toLowerCase(Locale.ROOT));
        return claimed >= LEVELS.length ? -1 : LEVELS[claimed];
    }

    private static int availableTier(int level) { int tier=0; for (int required:LEVELS) if(level>=required) tier++; return tier; }
    private static int claimedTier(AdventureSavedData.Profile p,String skill){return switch(skill){case"mining"->p.miningKitTier;case"engineering"->p.engineeringKitTier;case"farming"->p.farmingKitTier;case"combat"->p.combatKitTier;default->0;};}
    private static void setClaimedTier(AdventureSavedData.Profile p,String skill,int tier){switch(skill){case"mining"->p.miningKitTier=tier;case"engineering"->p.engineeringKitTier=tier;case"farming"->p.farmingKitTier=tier;case"combat"->p.combatKitTier=tier;}}

    private static void give(ServerPlayer p,String skill,int tier){
        ItemStack[] items=switch(skill){
            case"mining"->switch(tier){
                case 1->new ItemStack[]{new ItemStack(Items.IRON_PICKAXE),new ItemStack(Items.TORCH,32),new ItemStack(Items.COAL,24)};
                case 2->new ItemStack[]{new ItemStack(Items.DIAMOND_PICKAXE),new ItemStack(Items.IRON_INGOT,24),new ItemStack(Items.LAPIS_LAZULI,16)};
                case 3->new ItemStack[]{new ItemStack(Items.DIAMOND_PICKAXE),new ItemStack(Items.DIAMOND,8),new ItemStack(Items.EXPERIENCE_BOTTLE,32)};
                case 4->new ItemStack[]{new ItemStack(Items.NETHERITE_PICKAXE),new ItemStack(Items.DIAMOND,16),new ItemStack(Items.ANCIENT_DEBRIS,4)};
                default->new ItemStack[]{new ItemStack(Items.NETHERITE_PICKAXE),new ItemStack(Items.NETHERITE_INGOT,2),new ItemStack(Items.ENCHANTED_GOLDEN_APPLE)};};
            case"engineering"->switch(tier){
                case 1->new ItemStack[]{item("create:andesite_alloy",24),item("create:wrench",1),item("create:shaft",32)};
                case 2->new ItemStack[]{item("create:cogwheel",32),item("create:large_cogwheel",16),item("create:andesite_casing",16)};
                case 3->new ItemStack[]{item("create:brass_casing",12),item("create:precision_mechanism",4),item("create:deployer",1)};
                case 4->new ItemStack[]{item("create:mechanical_arm",1),item("create:railway_casing",8),item("create:track",64)};
                default->new ItemStack[]{item("create:steam_engine",2),item("create:mechanical_crafter",16),item("create:precision_mechanism",16)};};
            case"farming"->switch(tier){
                case 1->new ItemStack[]{new ItemStack(Items.WHEAT_SEEDS,32),new ItemStack(Items.CARROT,16),new ItemStack(Items.POTATO,16),new ItemStack(Items.WATER_BUCKET)};
                case 2->new ItemStack[]{new ItemStack(Items.PUMPKIN_SEEDS,16),new ItemStack(Items.MELON_SEEDS,16),new ItemStack(Items.BONE_MEAL,64),new ItemStack(Items.OAK_SAPLING,8)};
                case 3->new ItemStack[]{new ItemStack(Items.COW_SPAWN_EGG,2),new ItemStack(Items.SHEEP_SPAWN_EGG,2),new ItemStack(Items.CHICKEN_SPAWN_EGG,2),new ItemStack(Items.HAY_BLOCK,16)};
                case 4->new ItemStack[]{new ItemStack(Items.VILLAGER_SPAWN_EGG,2),new ItemStack(Items.GOLDEN_CARROT,32),new ItemStack(Items.CHERRY_SAPLING,8)};
                default->new ItemStack[]{new ItemStack(Items.MOOSHROOM_SPAWN_EGG,2),new ItemStack(Items.ENCHANTED_GOLDEN_APPLE),new ItemStack(Items.BEACON)};};
            default->switch(tier){
                case 1->new ItemStack[]{new ItemStack(Items.IRON_SWORD),new ItemStack(Items.SHIELD),new ItemStack(Items.COOKED_BEEF,32)};
                case 2->new ItemStack[]{new ItemStack(Items.DIAMOND_SWORD),new ItemStack(Items.BOW),new ItemStack(Items.ARROW,64)};
                case 3->new ItemStack[]{new ItemStack(Items.DIAMOND_CHESTPLATE),new ItemStack(Items.GOLDEN_APPLE,8),new ItemStack(Items.TOTEM_OF_UNDYING)};
                case 4->new ItemStack[]{new ItemStack(Items.NETHERITE_SWORD),new ItemStack(Items.TOTEM_OF_UNDYING,2),new ItemStack(Items.EXPERIENCE_BOTTLE,64)};
                default->new ItemStack[]{new ItemStack(Items.NETHERITE_CHESTPLATE),new ItemStack(Items.TOTEM_OF_UNDYING,4),new ItemStack(Items.ENCHANTED_GOLDEN_APPLE,2)};};
        };
        for(ItemStack stack:items) if(!stack.isEmpty()&&!p.getInventory().add(stack))p.drop(stack,false);
    }
    private static ItemStack item(String id,int count){var item=AdventureSystem.resolve(id);return item==Items.AIR?ItemStack.EMPTY:new ItemStack(item,count);}
}
