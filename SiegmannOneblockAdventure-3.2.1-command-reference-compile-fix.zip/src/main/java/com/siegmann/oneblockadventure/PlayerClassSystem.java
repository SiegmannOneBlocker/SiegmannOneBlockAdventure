package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Six persistent RPG professions with modest, server-safe passive bonuses. */
public final class PlayerClassSystem {
    public record Profession(String id, String display, Item icon, String description, String bonus) {}
    private static final List<Profession> PROFESSIONS = List.of(
            new Profession("engineer", "Engineer", Items.REDSTONE, "Create-focused industrial specialist.", "+20% engineering XP and +5% cash"),
            new Profession("farmer", "Farmer", Items.GOLDEN_HOE, "Crop, animal, and food specialist.", "+25% farming XP"),
            new Profession("miner", "Miner", Items.DIAMOND_PICKAXE, "Ore and OneBlock specialist.", "+20% mining XP and +3% rare chance"),
            new Profession("hunter", "Hunter", Items.BOW, "Combat and boss specialist.", "+25% combat XP and +10% mob cash"),
            new Profession("merchant", "Merchant", Items.EMERALD, "Economy and trading specialist.", "+10% cash rewards"),
            new Profession("explorer", "Explorer", Items.SPYGLASS, "Structures and travel specialist.", "+10% structure/event rewards")
    );
    private PlayerClassSystem() {}

    public static String selected(ServerPlayer player) { return ServerSystemsSavedData.get(player.serverLevel()).playerClass(player.getUUID()); }
    public static double cashMultiplier(ServerPlayer player) {
        return switch (selected(player)) { case "merchant" -> 1.10D; case "engineer" -> 1.05D; default -> 1.0D; };
    }
    public static int miningXp(ServerPlayer player, int base) { return "miner".equals(selected(player)) ? Math.max(base, Math.round(base * 1.20F)) : base; }
    public static int engineeringXp(ServerPlayer player, int base) { return "engineer".equals(selected(player)) ? Math.max(base, Math.round(base * 1.20F)) : base; }
    public static int farmingXp(ServerPlayer player, int base) { return "farmer".equals(selected(player)) ? Math.max(base, Math.round(base * 1.25F)) : base; }
    public static int combatXp(ServerPlayer player, int base) { return "hunter".equals(selected(player)) ? Math.max(base, Math.round(base * 1.25F)) : base; }

    public static void open(ServerPlayer player) {
        SimpleContainer inventory = new SimpleContainer(36);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        String current = selected(player);
        int[] slots = {10, 11, 12, 14, 15, 16};
        for (int i = 0; i < PROFESSIONS.size(); i++) {
            Profession profession = PROFESSIONS.get(i);
            ItemStack icon = new ItemStack(profession.icon());
            boolean selected = profession.id().equals(current);
            icon.set(DataComponents.CUSTOM_NAME, Component.literal(profession.display() + (selected ? " [SELECTED]" : "")).withStyle(selected ? ChatFormatting.GREEN : ChatFormatting.GOLD, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new ItemLore(List.of(
                    Component.literal(profession.description()).withStyle(ChatFormatting.GRAY),
                    Component.literal(profession.bonus()).withStyle(ChatFormatting.AQUA),
                    Component.literal(selected ? "This is your profession." : current.equals("none") ? "Click to choose permanently." : "An administrator must reset your class.").withStyle(selected ? ChatFormatting.GREEN : ChatFormatting.YELLOW))));
            inventory.setItem(slots[i], icon);
            if (current.equals("none")) actions.put(slots[i], p -> choose(p, profession.id(), false));
        }
        ItemStack info = new ItemStack(Items.WRITTEN_BOOK);
        info.set(DataComponents.CUSTOM_NAME, Component.literal("Profession Rules").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD));
        info.set(DataComponents.LORE, new ItemLore(List.of(
                Component.literal("Profession bonuses are intentionally modest.").withStyle(ChatFormatting.GRAY),
                Component.literal("They never bypass phase or shop unlocks.").withStyle(ChatFormatting.GRAY))));
        inventory.setItem(4, info);
        ItemStack back = new ItemStack(Items.BARRIER);
        back.set(DataComponents.CUSTOM_NAME, Component.literal("Back").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        back.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("Return to the main menu.").withStyle(ChatFormatting.GRAY))));
        inventory.setItem(31, back);
        actions.put(31, AdventureSystem::openMenu);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(4, id, inv, inventory, actions), Component.literal("Choose Your Profession")));
    }

    public static int choose(ServerPlayer player, String raw, boolean force) {
        String value = raw.toLowerCase(Locale.ROOT);
        Profession profession = PROFESSIONS.stream().filter(p -> p.id().equals(value)).findFirst().orElse(null);
        if (profession == null) {
            player.sendSystemMessage(Component.literal("Unknown profession. Use engineer, farmer, miner, hunter, merchant, or explorer.").withStyle(ChatFormatting.RED));
            return 0;
        }
        if (!ServerSystemsSavedData.get(player.serverLevel()).setPlayerClass(player.getUUID(), value, force)) {
            player.sendSystemMessage(Component.literal("Your profession is already locked. Ask an administrator to reset it.").withStyle(ChatFormatting.RED));
            return 0;
        }
        player.sendSystemMessage(Component.literal("Profession selected: " + profession.display()).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
        open(player);
        return 1;
    }

    public static int reset(ServerPlayer admin, ServerPlayer target) {
        ServerSystemsSavedData.get(target.serverLevel()).setPlayerClass(target.getUUID(), "none", true);
        admin.sendSystemMessage(Component.literal("Reset " + target.getName().getString() + "'s profession.").withStyle(ChatFormatting.GREEN));
        target.sendSystemMessage(Component.literal("Your profession was reset. Use /class to choose again.").withStyle(ChatFormatting.YELLOW));
        return 1;
    }
}
