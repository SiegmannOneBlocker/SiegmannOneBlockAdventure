package com.siegmann.oneblockadventure;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid=SiegmannOneblockAdventure.MOD_ID)
public final class ExpansionCommands {
    private ExpansionCommands(){}
    @SubscribeEvent public static void register(RegisterCommandsEvent event){
        var d=event.getDispatcher();
        d.register(Commands.literal("leaderboard").executes(c->{ExpansionSystem.openLeaderboards(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("phasecounter").executes(c->{ExpansionSystem.openProgress(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("encyclopedia").executes(c->{ExpansionSystem.openEncyclopedia(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("collection").executes(c->{ExpansionSystem.openCollection(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("achievements").executes(c->{ExpansionSystem.openAchievements(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("challenge").executes(c->{ExpansionSystem.openDailyChallenge(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("artifacts").executes(c->{ExpansionSystem.openArtifacts(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("merchant").executes(c->{ExpansionSystem.openMerchant(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("events").executes(c->{ExpansionSystem.openEvents(c.getSource().getPlayerOrException());return 1;}));
        d.register(Commands.literal("structures").executes(c->{ExpansionSystem.openStructures(c.getSource().getPlayerOrException());return 1;}).then(Commands.literal("locate").executes(c->StructureSystem.locateNearest(c.getSource().getPlayerOrException()))));
        d.register(Commands.literal("soa")
          .then(Commands.literal("adventure").executes(c->{ExpansionSystem.openHub(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("leaderboard").executes(c->{ExpansionSystem.openLeaderboards(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("progressmenu").executes(c->{ExpansionSystem.openProgress(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("structures").executes(c->{ExpansionSystem.openStructures(c.getSource().getPlayerOrException());return 1;}).then(Commands.literal("locate").executes(c->StructureSystem.locateNearest(c.getSource().getPlayerOrException()))))
          .then(Commands.literal("encyclopedia").executes(c->{ExpansionSystem.openEncyclopedia(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("collection").executes(c->{ExpansionSystem.openCollection(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("achievements").executes(c->{ExpansionSystem.openAchievements(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("challenge").executes(c->{ExpansionSystem.openDailyChallenge(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("artifacts").executes(c->{ExpansionSystem.openArtifacts(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("merchant").executes(c->{ExpansionSystem.openMerchant(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("events").executes(c->{ExpansionSystem.openEvents(c.getSource().getPlayerOrException());return 1;}))
          .then(Commands.literal("rate").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("stars",IntegerArgumentType.integer(1,5)).executes(c->rate(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player"),IntegerArgumentType.getInteger(c,"stars"))))))
          .then(Commands.literal("admin").requires(s->s.hasPermission(2))
            .then(Commands.literal("resetplayer").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("confirmation",StringArgumentType.word()).executes(c->ResetSystem.reset(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player"),StringArgumentType.getString(c,"confirmation"))))))
            .then(Commands.literal("structure").then(Commands.literal("generate").then(Commands.argument("type",StringArgumentType.word()).executes(c->generateStructure(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"type"))))))
            .then(Commands.literal("event").then(Commands.literal("start").then(Commands.argument("name",StringArgumentType.word()).then(Commands.argument("minutes",IntegerArgumentType.integer(1,10080)).executes(c->startEvent(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"name"),IntegerArgumentType.getInteger(c,"minutes")))))).then(Commands.literal("stop").executes(c->stopEvent(c.getSource().getPlayerOrException()))))
            .then(Commands.literal("weeklyboss").executes(c->weeklyBoss(c.getSource().getPlayerOrException())))
            .then(Commands.literal("auditcommands").executes(c->auditCommands(c.getSource().getPlayerOrException())))
          ));
    }
    private static int rate(ServerPlayer voter,ServerPlayer target,int stars){if(voter.getUUID().equals(target.getUUID())){voter.sendSystemMessage(Component.literal("You cannot rate your own island.").withStyle(ChatFormatting.RED));return 0;}CommunitySavedData.get(voter.serverLevel()).rate(target.getUUID(),stars);voter.sendSystemMessage(Component.literal("Rated "+target.getName().getString()+"'s island "+stars+"/5.").withStyle(ChatFormatting.GREEN));return 1;}
    private static int generateStructure(ServerPlayer admin,String type){var pos=StructureSystem.generateRandom(admin.serverLevel(),admin.blockPosition(),type);admin.sendSystemMessage(Component.literal("Generated structure at "+pos.toShortString()).withStyle(ChatFormatting.GREEN));return 1;}
    private static int startEvent(ServerPlayer admin,String name,int minutes){CommunitySavedData.get(admin.serverLevel()).setEvent(name.replace('_',' '),System.currentTimeMillis()+minutes*60000L);admin.getServer().getPlayerList().broadcastSystemMessage(Component.literal("World Event: "+name.replace('_',' ')+" for "+minutes+" minutes!").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD),false);return 1;}
    private static int stopEvent(ServerPlayer admin){CommunitySavedData.get(admin.serverLevel()).setEvent("None",0L);admin.sendSystemMessage(Component.literal("Stopped the active world event.").withStyle(ChatFormatting.YELLOW));return 1;}
    private static int weeklyBoss(ServerPlayer admin){var ravager=EntityType.RAVAGER.spawn(admin.serverLevel(),admin.blockPosition().offset(3,0,3),MobSpawnType.COMMAND);if(ravager==null)return 0;ravager.setCustomName(Component.literal("Weekly Factory Breaker").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD));ravager.setCustomNameVisible(true);admin.getServer().getPlayerList().broadcastSystemMessage(Component.literal("The Weekly Factory Breaker has appeared near "+admin.getName().getString()+"!").withStyle(ChatFormatting.RED,ChatFormatting.BOLD),false);return 1;}
    private static int auditCommands(ServerPlayer admin){String[] groups={"Core: /soa, /menu, /soa startnew, /soa tp, /soa spawn, /soa progress","Economy: /shop, /balance, /market, /kits","Progression: /quests, /skills, /rewards, /prestige, /endgame","Community: /soa adventure, /leaderboard, /phasecounter, /structures locate, /collection","Expansion: /achievements, /challenge, /artifacts, /merchant, /events","Admin: resetplayer, structure generate, event start/stop, weeklyboss, auditprogression, auditcommands"};admin.sendSystemMessage(Component.literal("Command audit: registered command groups").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));for(String g:groups)admin.sendSystemMessage(Component.literal(g).withStyle(ChatFormatting.GRAY));return 1;}
}
