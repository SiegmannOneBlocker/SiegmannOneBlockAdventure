package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** In-game command reference kept with the actual command registration groups. */
public final class CommandReferenceMenu {
    private CommandReferenceMenu() {}

    public static void open(ServerPlayer player) {
        SimpleContainer c = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
        category(c, 10, Items.GRASS_BLOCK, "Island & Travel", List.of(
                "/soa startnew", "/soa create", "/soa tp", "/spawn", "/teleports", "/islandteam"));
        category(c, 12, Items.EMERALD, "Economy & Shop", List.of(
                "/shop", "/balance", "/market", "/kits", "/crates"));
        category(c, 14, Items.EXPERIENCE_BOTTLE, "Progression & Classes", List.of(
                "/soa progress", "/phasecounter", "/quest", "/skills", "/class", "/rewards", "/prestige"));
        category(c, 16, Items.MAP, "Adventure", List.of(
                "/structures", "/encyclopedia", "/collection", "/achievements", "/events"));
        category(c, 28, Items.IRON_SWORD, "Competitive", List.of(
                "/pvp", "/dragoncup", "/leaderboard"));
        category(c, 30, Items.PLAYER_HEAD, "Community", List.of(
                "/islandteam invite <player>", "/islandteam accept <owner>", "/soa rate <player> <1-5>"));
        if (player.hasPermissions(2)) {
            category(c, 32, Items.COMMAND_BLOCK, "Administrator", List.of(
                    "/adminmenu", "/soasystems", "/soa admin diagnose", "/soa admin auditprogression",
                    "/soaworld list", "/soacompetitive arena generate", "/soa admin resetplayer <player> CONFIRM"));
        }
        button(c, a, 49, Items.BARRIER, "Back", "Return to the main menu.", AdventureSystem::openMenu);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, c, a), Component.literal("Command Guide")));
    }

    private static void category(SimpleContainer c, int slot, Item icon, String name, List<String> commands) {
        ItemStack s = new ItemStack(icon);
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        s.set(DataComponents.LORE, new ItemLore(commands.stream()
                .<Component>map(x -> Component.literal(x).withStyle(ChatFormatting.GRAY))
                .toList()));
        c.setItem(slot, s);
    }

    private static void button(SimpleContainer c, Map<Integer, Consumer<ServerPlayer>> a, int slot, Item icon,
                               String name, String lore, Consumer<ServerPlayer> action) {
        ItemStack s = new ItemStack(icon);
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        s.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY))));
        c.setItem(slot, s);
        a.put(slot, action);
    }
}
