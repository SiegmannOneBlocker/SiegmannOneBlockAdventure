package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;

/** Persistent data for world profiles, live events, Create metrics, guide state, and hub settings. */
public final class Stage31SavedData extends SavedData {
    private static final String NAME="soa_stage31";
    private static final Factory<Stage31SavedData> FACTORY=new Factory<>(Stage31SavedData::new,Stage31SavedData::load,null);
    public String worldProfile="classic_oneblock";
    public String activeEvent="none";
    public long eventEndsAt=0L;
    public boolean hubEnabled=true;
    public boolean dashboardExportEnabled=true;
    private final Map<UUID,Metrics> metrics=new HashMap<>();
    public static Stage31SavedData get(ServerLevel l){return l.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY,NAME);}
    public Metrics metrics(UUID id){return metrics.computeIfAbsent(id,k->new Metrics());}
    public void dirty(){setDirty();}
    public static final class Metrics {public long machines,belts,deployers,automated,structures,bosses,dragonWins;}
    private static Stage31SavedData load(CompoundTag t,HolderLookup.Provider r){Stage31SavedData d=new Stage31SavedData();d.worldProfile=t.getString("WorldProfile");if(d.worldProfile.isBlank())d.worldProfile="classic_oneblock";d.activeEvent=t.getString("ActiveEvent");if(d.activeEvent.isBlank())d.activeEvent="none";d.eventEndsAt=t.getLong("EventEndsAt");d.hubEnabled=!t.contains("HubEnabled")||t.getBoolean("HubEnabled");d.dashboardExportEnabled=!t.contains("DashboardExport")||t.getBoolean("DashboardExport");ListTag list=t.getList("Metrics",Tag.TAG_COMPOUND);for(int i=0;i<list.size();i++){CompoundTag e=list.getCompound(i);if(!e.hasUUID("Player"))continue;Metrics m=new Metrics();m.machines=e.getLong("Machines");m.belts=e.getLong("Belts");m.deployers=e.getLong("Deployers");m.automated=e.getLong("Automated");m.structures=e.getLong("Structures");m.bosses=e.getLong("Bosses");m.dragonWins=e.getLong("DragonWins");d.metrics.put(e.getUUID("Player"),m);}return d;}
    @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider r){t.putString("WorldProfile",worldProfile);t.putString("ActiveEvent",activeEvent);t.putLong("EventEndsAt",eventEndsAt);t.putBoolean("HubEnabled",hubEnabled);t.putBoolean("DashboardExport",dashboardExportEnabled);ListTag list=new ListTag();metrics.forEach((id,m)->{CompoundTag e=new CompoundTag();e.putUUID("Player",id);e.putLong("Machines",m.machines);e.putLong("Belts",m.belts);e.putLong("Deployers",m.deployers);e.putLong("Automated",m.automated);e.putLong("Structures",m.structures);e.putLong("Bosses",m.bosses);e.putLong("DragonWins",m.dragonWins);list.add(e);});t.put("Metrics",list);return t;}
}
