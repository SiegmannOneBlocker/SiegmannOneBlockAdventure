package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Registry-driven server shop. Every normal item registered by Minecraft and installed mods is
 * automatically included. Explicit JSON offers override the generated price/count/phase values.
 */
public final class ShopSystem {
    public record Offer(String itemId, int count, int buy, int sell, int unlockPhase, String category) {}
    public record SpawnerOffer(String entityId, String displayName, int buy, int requiredTier) {}

    private static final String SPAWNER_CATEGORY = "Endgame Spawners";
    private static final List<SpawnerOffer> SPAWNER_OFFERS = List.of(
            new SpawnerOffer("minecraft:zombie", "Zombie Spawner", 5_000_000, 5),
            new SpawnerOffer("minecraft:skeleton", "Skeleton Spawner", 5_000_000, 5),
            new SpawnerOffer("minecraft:spider", "Spider Spawner", 4_500_000, 5),
            new SpawnerOffer("minecraft:creeper", "Creeper Spawner", 10_000_000, 10),
            new SpawnerOffer("minecraft:blaze", "Blaze Spawner", 15_000_000, 15),
            new SpawnerOffer("minecraft:enderman", "Enderman Spawner", 25_000_000, 20),
            new SpawnerOffer("minecraft:witch", "Witch Spawner", 35_000_000, 25),
            new SpawnerOffer("minecraft:iron_golem", "Iron Golem Spawner", 50_000_000, 30)
    );
    private static final int ITEMS_PER_PAGE = 45;
    private static final int CATEGORIES_PER_PAGE = 45;

    // Unsafe operator/technical items stay excluded unless explicitly added to shop_offers.json.
    private static final Set<String> DEFAULT_EXCLUSIONS = Set.of(
            "minecraft:air", "minecraft:cave_air", "minecraft:void_air",
            "minecraft:barrier", "minecraft:light", "minecraft:structure_void",
            "minecraft:command_block", "minecraft:chain_command_block", "minecraft:repeating_command_block",
            "minecraft:command_block_minecart", "minecraft:structure_block", "minecraft:jigsaw",
            "minecraft:debug_stick", "minecraft:knowledge_book", "minecraft:spawner",
            "minecraft:end_portal_frame", "minecraft:bedrock",
            "minecraft:trial_spawner", "minecraft:vault", "minecraft:reinforced_deepslate",
            "minecraft:petrified_oak_slab"
    );

    private ShopSystem() {}

    public static List<Offer> offers() {
        List<Offer> configured = ExternalContentConfig.shopOffers();
        java.util.Map<String, Offer> byId = new java.util.LinkedHashMap<>();

        // Generate one sensible default offer for every registered item from every installed mod.
        BuiltInRegistries.ITEM.keySet().stream()
                .sorted(Comparator.comparing(ResourceLocation::toString))
                .forEach(id -> {
                    String key = id.toString();
                    Item item = BuiltInRegistries.ITEM.get(id);
                    if (item == Items.AIR || isExcludedByDefault(key)) return;
                    ItemStack sample = new ItemStack(item);
                    if (sample.isEmpty()) return;
                    int count = defaultCount(item);
                    int buy = defaultBuyPrice(id, item);
                    int sell = Math.max(1, buy / 4);
                    byId.put(key, new Offer(key, count, buy, sell, defaultUnlockPhase(id), category(id)));
                });

        // A config entry replaces the generated entry for the same item, or adds an excluded item.
        // Offers are sanitized so a typo cannot create negative prices, impossible counts,
        // invalid phases, or a buy-low/sell-high economy exploit.
        for (Offer offer : configured) {
            Offer safe = sanitize(offer);
            if (safe != null) byId.put(safe.itemId(), safe);
        }
        return List.copyOf(byId.values());
    }

    public static int offerCount() { return offers().size(); }
    public static int pageCount() { return Math.max(1, (offerCount() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE); }

    /** Only offers the player has actually unlocked are ever passed to a shop GUI. */
    private static List<Offer> unlockedOffers(ServerPlayer player) {
        int phase = currentPhase(player);
        return offers().stream()
                .filter(o -> o.unlockPhase() <= phase)
                .map(o -> pricedOffer(player, o))
                .toList();
    }

    public static void open(ServerPlayer player) { openCategories(player); }

    /** Opens the clickable category menu. Categories are generated from all installed mods/items. */
    public static void openCategories(ServerPlayer player) { openCategories(player, 1); }

    private static void openCategories(ServerPlayer player, int requestedPage) {
        List<Offer> unlocked = unlockedOffers(player);
        List<String> categories = new ArrayList<>(new LinkedHashSet<>(unlocked.stream().map(Offer::category).sorted().toList()));
        if (!unlockedSpawnerOffers(player).isEmpty()) categories.add(SPAWNER_CATEGORY);
        int pages = Math.max(1, (categories.size() + CATEGORIES_PER_PAGE - 1) / CATEGORIES_PER_PAGE);
        int page = Math.max(1, Math.min(requestedPage, pages));
        int start = (page - 1) * CATEGORIES_PER_PAGE;
        int end = Math.min(start + CATEGORIES_PER_PAGE, categories.size());

        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        for (int index = start, slot = 0; index < end; index++, slot++) {
            String category = categories.get(index);
            boolean spawnerCategory = SPAWNER_CATEGORY.equals(category);
            Offer first = unlocked.stream().filter(o -> o.category().equals(category)).findFirst().orElse(null);
            Item iconItem = spawnerCategory ? Items.SPAWNER : (first == null ? Items.CHEST : item(first.itemId()));
            if (iconItem == null || iconItem == Items.AIR) iconItem = Items.CHEST;
            long count = spawnerCategory ? unlockedSpawnerOffers(player).size()
                    : unlocked.stream().filter(o -> o.category().equals(category)).count();
            ItemStack icon = new ItemStack(iconItem);
            icon.set(DataComponents.CUSTOM_NAME, Component.literal(category).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
                    Component.literal(count + " unlocked items").withStyle(ChatFormatting.GRAY),
                    Component.literal("Click to browse").withStyle(ChatFormatting.GREEN))));
            inventory.setItem(slot, icon);
            final String selected = category;
            actions.put(slot, p -> {
                if (SPAWNER_CATEGORY.equals(selected)) {
                    openSpawnerShop(p);
                } else {
                    openCategory(p, selected, 1);
                }
            });
        }
        menuIcon(inventory, 45, Items.ARROW, "Previous Categories", page > 1 ? "Go to page " + (page - 1) : "Already on the first page");
        if (page > 1) actions.put(45, p -> openCategories(p, page - 1));
        menuIcon(inventory, 47, Items.GOLD_INGOT, "Balance: $" + balance(player), "Your current cash");
        menuIcon(inventory, 48, Items.COMPASS, "All Unlocked Items", "Browse every item you have unlocked");
        actions.put(48, p -> open(p, 1));
        menuIcon(inventory, 49, Items.HOPPER, "Sell Held Stack", canSell(player) ? "Click to sell" : "Unlocks after Phase 250");
        if (canSell(player)) actions.put(49, p -> { sellHand(p); openCategories(p, page); });
        menuIcon(inventory, 50, Items.CHEST, "Sell Inventory", canSell(player) ? "Click to sell eligible items" : "Unlocks after Phase 250");
        if (canSell(player)) actions.put(50, p -> { sellAll(p); openCategories(p, page); });
        menuIcon(inventory, 51, Items.BARRIER, "Back", "Return to the main menu");
        actions.put(51, AdventureSystem::openMenu);
        menuIcon(inventory, 53, Items.ARROW, "Next Categories", page < pages ? "Go to page " + (page + 1) : "Already on the last page");
        if (page < pages) actions.put(53, p -> openCategories(p, page + 1));
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, inventory, actions),
                Component.literal("Siegmann Shop — Categories " + page + "/" + pages)));
    }

    public static void open(ServerPlayer player, int requestedPage) {
        List<Offer> all = unlockedOffers(player);
        int pages = Math.max(1, (all.size() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE);
        int page = Math.max(1, Math.min(requestedPage, pages));
        openList(player, all, page, "All Items", null);
    }

    public static void openCategory(ServerPlayer player, String category, int requestedPage) {
        List<Offer> matches = unlockedOffers(player).stream().filter(o -> o.category().equalsIgnoreCase(category)).toList();
        int pages = Math.max(1, (matches.size() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE);
        int page = Math.max(1, Math.min(requestedPage, pages));
        openList(player, matches, page, category, category);
    }

    public static void search(ServerPlayer player, String query, int requestedPage) {
        String needle = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
        List<Offer> matches = unlockedOffers(player).stream().filter(offer -> {
            Item item = item(offer.itemId());
            String display = item == null ? "" : new ItemStack(item).getHoverName().getString().toLowerCase(Locale.ROOT);
            return offer.itemId().toLowerCase(Locale.ROOT).contains(needle)
                    || offer.category().toLowerCase(Locale.ROOT).contains(needle)
                    || display.contains(needle);
        }).toList();
        int pages = Math.max(1, (matches.size() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE);
        int page = Math.max(1, Math.min(requestedPage, pages));
        openList(player, matches, page, "Search: " + query, null);
    }

    private static void openList(ServerPlayer player, List<Offer> shown, int page, String label, String category) {
        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        int start = (page - 1) * ITEMS_PER_PAGE;
        int end = Math.min(start + ITEMS_PER_PAGE, shown.size());
        for (int listIndex = start, slot = 0; listIndex < end; listIndex++, slot++) {
            Offer offer = shown.get(listIndex);
            Item item = item(offer.itemId());
            if (item == null) continue;
            ItemStack icon = new ItemStack(item, Math.min(offer.count(), iconMax(item)));
            int globalNumber = globalOfferNumber(offer.itemId());
            icon.set(DataComponents.CUSTOM_NAME, Component.literal(icon.getHoverName().getString())
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
                    Component.literal("Buy: $" + offer.buy() + "  Sell: $" + offer.sell()).withStyle(ChatFormatting.GOLD),
                    Component.literal("Price is per item  |  Item #" + globalNumber).withStyle(ChatFormatting.GRAY),
                    Component.literal("Unlocked at Phase " + offer.unlockPhase()).withStyle(ChatFormatting.DARK_GRAY),
                    Component.literal("Click to buy").withStyle(ChatFormatting.GREEN))));
            inventory.setItem(slot, icon);
            actions.put(slot, p -> openOfferMenu(p, offer, label, category, page));
        }

        int pages = Math.max(1, (shown.size() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE);
        menuIcon(inventory, 45, Items.ARROW, "Previous Page", page > 1 ? "Click to go to page " + (page - 1) : "Already on the first page");
        if (page > 1) actions.put(45, p -> openList(p, shown, page - 1, label, category));
        menuIcon(inventory, 47, Items.HOPPER, "Sell Held Stack", canSell(player) ? "Click to sell" : "Unlocks after Phase 250");
        actions.put(47, p -> { sellHand(p); openList(p, shown, page, label, category); });
        menuIcon(inventory, 48, Items.GOLD_INGOT, "Balance: $" + balance(player), "Your current cash");
        menuIcon(inventory, 49, Items.PAPER, label + " — Page " + page + "/" + pages, shown.size() + " items");
        menuIcon(inventory, 50, Items.CHEST, "Categories", "Return to shop categories");
        actions.put(50, ShopSystem::openCategories);
        menuIcon(inventory, 53, Items.ARROW, "Next Page", page < pages ? "Click to go to page " + (page + 1) : "Already on the last page");
        if (page < pages) actions.put(53, p -> openList(p, shown, page + 1, label, category));
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, inventory, actions),
                Component.literal("Siegmann Shop — " + label + " " + page + "/" + pages)));
    }

    /** Opens a confirmation/quantity menu instead of buying immediately. */
    private static void openOfferMenu(ServerPlayer player, Offer offer, String label, String category, int returnPage) {
        SimpleContainer inventory = new SimpleContainer(27);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        Item item = item(offer.itemId());
        if (item == null) { openCategories(player); return; }
        int maxStack = Math.max(1, item.getDefaultMaxStackSize());
        int[] quantities = purchaseQuantities(maxStack);
        int[] slots = quantities.length == 1 ? new int[]{12} : new int[]{10, 11, 12, 13, 14};
        for (int i = 0; i < quantities.length; i++) {
            int quantity = quantities[i];
            long totalCost = (long) offer.buy() * quantity;
            int totalItems = quantity;
            ItemStack icon = new ItemStack(item, Math.min(Math.max(1, totalItems), iconMax(item)));
            icon.set(DataComponents.CUSTOM_NAME, Component.literal("Buy " + totalItems + "x " + icon.getHoverName().getString()).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
                    Component.literal("Total price: $" + totalCost).withStyle(ChatFormatting.GOLD),
                    Component.literal("Sell value: $" + ((long) offer.sell() * quantity)).withStyle(ChatFormatting.YELLOW),
                    Component.literal("Click to confirm purchase").withStyle(ChatFormatting.GREEN))));
            inventory.setItem(slots[i], icon);
            actions.put(slots[i], p -> { buyQuantity(p, offer, quantity); openOfferMenu(p, offer, label, category, returnPage); });
        }
        menuIcon(inventory, 4, item, new ItemStack(item).getHoverName().getString(), "Price per item: Buy $" + offer.buy() + " | Sell $" + offer.sell());
        menuIcon(inventory, 22, Items.BARRIER, "Back", "Return to the previous shop page");
        actions.put(22, p -> reopenFiltered(p, label, category, returnPage));
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(3, id, inv, inventory, actions),
                Component.literal("Shop — Choose Amount")));
    }

    private static int buyQuantity(ServerPlayer player, Offer offer, int quantity) {
        if (currentPhase(player) < offer.unlockPhase()) return 0;
        Item item = item(offer.itemId());
        if (item == null) return 0;
        long cost = (long) offer.buy() * quantity;
        EconomySavedData eco = EconomySavedData.get(player.serverLevel());
        if (!eco.take(player.getUUID(), cost)) {
            player.sendSystemMessage(Component.literal("Not enough cash. Cost: $" + cost).withStyle(ChatFormatting.RED));
            return 0;
        }
        int remaining = quantity;
        while (remaining > 0) {
            int amount = Math.min(remaining, Math.max(1, item.getDefaultMaxStackSize()));
            ItemStack stack = new ItemStack(item, amount);
            if (!player.getInventory().add(stack)) player.drop(stack, false);
            remaining -= amount;
        }
        player.sendSystemMessage(Component.literal("Purchased " + quantity + "x " + new ItemStack(item).getHoverName().getString() + " for $" + cost + ".").withStyle(ChatFormatting.GREEN));
        updateScore(player);
        return 1;
    }

    /** Opens the buy-only endgame spawner shop. Only currently unlocked spawners are visible. */
    public static void openSpawnerShop(ServerPlayer player) {
        List<SpawnerOffer> shown = unlockedSpawnerOffers(player);
        if (shown.isEmpty()) {
            player.sendSystemMessage(Component.literal("Endgame spawners unlock at Endless Tier 5.").withStyle(ChatFormatting.RED));
            return;
        }

        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        for (int slot = 0; slot < shown.size() && slot < ITEMS_PER_PAGE; slot++) {
            SpawnerOffer offer = shown.get(slot);
            ItemStack icon = createSpawnerStack(offer);
            icon.set(DataComponents.CUSTOM_NAME, Component.literal(offer.displayName()).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
            icon.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
                    Component.literal("Price: $" + ShopPriceSavedData.get(player.serverLevel()).adjustedBuy("minecraft:spawner", offer.buy())).withStyle(ChatFormatting.GOLD),
                    Component.literal("Required Endless Tier: " + offer.requiredTier()).withStyle(ChatFormatting.GRAY),
                    Component.literal("Buy only — cannot be sold").withStyle(ChatFormatting.RED),
                    Component.literal("Click to purchase").withStyle(ChatFormatting.GREEN))));
            inventory.setItem(slot, icon);
            final SpawnerOffer selected = offer;
            actions.put(slot, p -> { buySpawner(p, selected); openSpawnerShop(p); });
        }

        menuIcon(inventory, 47, Items.GOLD_INGOT, "Balance: $" + balance(player), "Your current cash");
        menuIcon(inventory, 49, Items.NETHER_STAR, "Endgame Spawners", "Only unlocked spawners are shown");
        menuIcon(inventory, 51, Items.BARRIER, "Back", "Return to shop categories");
        actions.put(51, ShopSystem::openCategories);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, inventory, actions),
                Component.literal("Siegmann Shop — Endgame Spawners")));
    }

    private static List<SpawnerOffer> unlockedSpawnerOffers(ServerPlayer player) {
        int tier = currentEndgameTier(player);
        return SPAWNER_OFFERS.stream().filter(o -> o.requiredTier() <= tier).toList();
    }

    private static int currentEndgameTier(ServerPlayer player) {
        return MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID())
                .filter(island -> CreateProgression.isEndgame(island.generated()))
                .map(island -> EndgameSystem.tier(island.generated()))
                .orElse(0);
    }

    private static int buySpawner(ServerPlayer player, SpawnerOffer offer) {
        int tier = currentEndgameTier(player);
        if (tier < offer.requiredTier()) {
            player.sendSystemMessage(Component.literal(offer.displayName() + " unlocks at Endless Tier "
                    + offer.requiredTier() + ".").withStyle(ChatFormatting.RED));
            return 0;
        }
        EconomySavedData eco = EconomySavedData.get(player.serverLevel());
        long adjustedPrice = ShopPriceSavedData.get(player.serverLevel()).adjustedBuy("minecraft:spawner", offer.buy());
        if (!eco.take(player.getUUID(), adjustedPrice)) {
            player.sendSystemMessage(Component.literal("Not enough cash. Cost: $" + adjustedPrice).withStyle(ChatFormatting.RED));
            return 0;
        }
        ItemStack stack = createSpawnerStack(offer);
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        player.sendSystemMessage(Component.literal("Purchased a " + offer.displayName() + " for $" + adjustedPrice
                + ". Balance: $" + eco.balance(player.getUUID())).withStyle(ChatFormatting.GREEN));
        updateScore(player);
        return 1;
    }

    /** Adds the vanilla block-entity data used by a placed spawner to remember its mob type. */
    private static ItemStack createSpawnerStack(SpawnerOffer offer) {
        ItemStack stack = new ItemStack(Items.SPAWNER);
        CompoundTag entity = new CompoundTag();
        entity.putString("id", offer.entityId());
        CompoundTag spawnData = new CompoundTag();
        spawnData.put("entity", entity);
        CompoundTag blockEntityData = new CompoundTag();
        blockEntityData.putString("id", "minecraft:mob_spawner");
        blockEntityData.put("SpawnData", spawnData);
        stack.set(DataComponents.BLOCK_ENTITY_DATA, CustomData.of(blockEntityData));
        return stack;
    }

    private static Offer pricedOffer(ServerPlayer player, Offer base) {
        ShopPriceSavedData prices = ShopPriceSavedData.get(player.serverLevel());
        ServerSystemsSavedData systems = ServerSystemsSavedData.get(player.serverLevel());
        long adjustedBuy = Math.max(1L, prices.adjustedBuy(base.itemId(), base.buy()) * systems.economyBuyPercent() / 100L);
        long adjustedSell = Math.max(0L, prices.adjustedSell(base.itemId(), base.sell()) * systems.economySellPercent() / 100L);
        int buy = (int) Math.min(Integer.MAX_VALUE, Math.max(1L, adjustedBuy));
        int sell = (int) Math.min(Integer.MAX_VALUE, Math.max(0L, adjustedSell));
        // Selling can never exceed one third of the current buy price.
        sell = Math.min(sell, buy / 3);
        return new Offer(base.itemId(), 1, buy, sell, base.unlockPhase(), base.category());
    }

    private static int[] purchaseQuantities(int maxStack) {
        if (maxStack <= 1) return new int[]{1};
        if (maxStack <= 8) return java.util.stream.IntStream.of(1, 2, 4, 8)
                .filter(value -> value <= maxStack).distinct().toArray();
        if (maxStack <= 16) return new int[]{1, 2, 4, 8};
        return new int[]{1, 4, 8, 32, 64};
    }

    private static void menuIcon(SimpleContainer inventory, int slot, Item item, String name, String lore) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        stack.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY))));
        inventory.setItem(slot, stack);
    }

    private static int globalOfferNumber(String itemId) {
        List<Offer> all = offers();
        for (int i = 0; i < all.size(); i++) if (all.get(i).itemId().equals(itemId)) return i + 1;
        return 0;
    }

    public static int buy(ServerPlayer player, int slot) {
        List<Offer> all = offers();
        if (slot < 1 || slot > all.size()) return 0;
        Offer offer = pricedOffer(player, all.get(slot - 1));
        if (currentPhase(player) < offer.unlockPhase()) {
            player.sendSystemMessage(Component.literal("That item unlocks at Phase " + offer.unlockPhase() + ".").withStyle(ChatFormatting.RED));
            return 0;
        }
        Item item = item(offer.itemId());
        if (item == null) return 0;
        EconomySavedData eco = EconomySavedData.get(player.serverLevel());
        if (!eco.take(player.getUUID(), offer.buy())) {
            player.sendSystemMessage(Component.literal("Not enough cash. Cost: $" + offer.buy()).withStyle(ChatFormatting.RED));
            return 0;
        }
        ItemStack stack = new ItemStack(item, offer.count());
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        player.sendSystemMessage(Component.literal("Purchased " + offer.count() + "x " + stack.getHoverName().getString()
                + " for $" + offer.buy() + ". Balance: $" + eco.balance(player.getUUID())).withStyle(ChatFormatting.GREEN));
        updateScore(player);
        return 1;
    }

    public static int sellHand(ServerPlayer player) {
        if (!requireSellingUnlocked(player)) return 0;
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) return 0;
        long cash = sellStack(player, held);
        if (cash <= 0) {
            player.sendSystemMessage(Component.literal("That item is not currently sellable.").withStyle(ChatFormatting.RED));
            return 0;
        }
        player.sendSystemMessage(Component.literal("Sold held stack for $" + cash + ". Balance: $" + balance(player)).withStyle(ChatFormatting.GREEN));
        updateScore(player);
        return 1;
    }

    public static int sellAll(ServerPlayer player) {
        if (!requireSellingUnlocked(player)) return 0;
        long total = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) total += sellStack(player, player.getInventory().getItem(i));
        if (total <= 0) {
            player.sendSystemMessage(Component.literal("No sellable items were found in your inventory.").withStyle(ChatFormatting.RED));
            return 0;
        }
        player.sendSystemMessage(Component.literal("Sold eligible inventory items for $" + total + ". Balance: $" + balance(player)).withStyle(ChatFormatting.GREEN));
        updateScore(player);
        return 1;
    }

    private static long sellStack(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        Offer match = offers().stream().filter(offer -> offer.itemId().equals(id.toString())).findFirst().orElse(null);
        if (match != null) match = pricedOffer(player, match);
        if (match == null || match.sell() <= 0) return 0;
        int count = stack.getCount();
        long cash = (long) match.sell() * count / Math.max(1, match.count());
        if (cash <= 0) return 0;
        stack.shrink(count);
        EconomySavedData.get(player.serverLevel()).add(player.getUUID(), cash);
        return cash;
    }

    private static boolean canSell(ServerPlayer player) {
        return MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID())
                .map(island -> CreateProgression.isEndgame(island.generated())).orElse(false);
    }

    private static boolean requireSellingUnlocked(ServerPlayer player) {
        if (canSell(player)) return true;
        player.sendSystemMessage(Component.literal("Selling unlocks after you complete Phase 250.").withStyle(ChatFormatting.RED));
        return false;
    }

    private static int defaultCount(Item item) {
        // Every shop offer is priced and displayed per single item. Quantity is selected
        // only after the player clicks the item, preventing confusing 4x/16x base bundles.
        return 1;
    }

    private static int defaultBuyPrice(ResourceLocation id, Item item) {
        String path = id.getPath().toLowerCase(Locale.ROOT);
        int unit;

        // Base prices are for one item. The final offer price is scaled by the offer count.
        if (containsAny(path, "netherite", "elytra", "dragon_egg", "nether_star", "beacon", "enchanted_golden_apple")) unit = 4000;
        else if (containsAny(path, "diamond", "ancient_debris", "shulker", "totem")) unit = 650;
        else if (containsAny(path, "precision_mechanism", "steam_engine", "electric_motor", "alternator", "controller")) unit = 500;
        else if (containsAny(path, "mechanical_crafter", "deployer", "mechanical_arm", "train_station", "track_station")) unit = 400;
        else if (containsAny(path, "machine", "motor", "mechanism", "press", "mixer", "crusher", "millstone", "saw")) unit = 250;
        else if (containsAny(path, "emerald", "blaze_rod", "ender_pearl", "gold_ingot", "quartz")) unit = 90;
        else if (containsAny(path, "iron_ingot", "copper_ingot", "zinc_ingot", "redstone", "lapis")) unit = 35;
        else if (containsAny(path, "ore", "raw_")) unit = 45;
        else if (containsAny(path, "log", "planks", "stone", "dirt", "sand", "gravel", "clay")) unit = 3;
        else if (item.getDefaultMaxStackSize() == 1) unit = 125;
        else unit = 10;

        int count = defaultCount(item);
        long total = (long) unit * count;
        return (int) Math.max(1L, Math.min(1_000_000L, total));
    }

    private static int defaultUnlockPhase(ResourceLocation id) {
        String namespace = id.getNamespace().toLowerCase(Locale.ROOT);
        String path = id.getPath().toLowerCase(Locale.ROOT);

        if (containsAny(path, "netherite", "elytra", "dragon_egg", "nether_star", "beacon", "enchanted_golden_apple")) return 250;
        if (containsAny(path, "end_", "shulker", "chorus", "purpur", "totem")) return 220;
        if (containsAny(path, "ancient_debris", "obsidian", "crying_obsidian")) return 205;
        if (containsAny(namespace, "railways", "steam_and_rails") || containsAny(path, "train", "railway", "track_station")) return 175;
        if (containsAny(namespace, "createaddition", "create_new_age") || containsAny(path, "electric_motor", "alternator", "electrum")) return 145;
        if (containsAny(path, "diamond", "emerald")) return 130;
        if (containsAny(path, "brass", "precision", "deployer", "mechanical_arm", "mechanical_crafter")) return 105;
        if (containsAny(path, "nether", "blaze", "quartz", "soul_", "blackstone", "basalt")) return 85;
        if (containsAny(path, "redstone", "gold", "lapis", "amethyst")) return 65;
        if (namespace.equals("create") || namespace.startsWith("create_")) return 40;
        if (containsAny(path, "iron", "copper", "zinc", "ore", "raw_")) return 25;
        if (!namespace.equals("minecraft")) return 20;
        return 1;
    }

    private static Offer sanitize(Offer offer) {
        if (offer == null || ResourceLocation.tryParse(offer.itemId()) == null) return null;
        // Normalize legacy/configured bundle offers to one item. The quantity menu handles
        // multi-item purchases, so category pages never show a built-in stack of 16.
        int count = 1;
        int buy = Math.max(1, Math.min(1_000_000, offer.buy()));
        int sell = Math.max(0, Math.min(offer.sell(), Math.max(0, buy / 3)));
        int unlock = Math.max(1, Math.min(CreateProgression.STORY_PHASES, offer.unlockPhase()));
        String category = offer.category() == null || offer.category().isBlank() ? "Other" : offer.category().trim();
        return new Offer(offer.itemId(), count, buy, sell, unlock, category);
    }

    private static boolean isExcludedByDefault(String itemId) {
        if (DEFAULT_EXCLUSIONS.contains(itemId)) return true;
        String path = itemId.substring(itemId.indexOf(':') + 1).toLowerCase(Locale.ROOT);
        return path.endsWith("_spawn_egg")
                || path.contains("command_block")
                || path.contains("structure_block")
                || path.contains("structure_void")
                || path.contains("debug")
                || path.contains("jigsaw")
                || path.contains("portal_frame");
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static void reopenFiltered(ServerPlayer player, String label, String category, int page) {
        if (category != null) openCategory(player, category, page);
        else open(player, page);
    }

    private static String category(ResourceLocation id) {
        return id.getNamespace().equals("minecraft") ? "Minecraft" : id.getNamespace();
    }

    public static long balance(ServerPlayer player) { return EconomySavedData.get(player.serverLevel()).balance(player.getUUID()); }
    private static int currentPhase(ServerPlayer player) { return MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID()).map(i -> CreateProgression.phaseNumber(i.generated())).orElse(0); }
    private static void updateScore(ServerPlayer player) { ScoreboardSystem.update(player, MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L)); }
    private static Item item(String id) { ResourceLocation rl = ResourceLocation.tryParse(id); return rl != null && BuiltInRegistries.ITEM.containsKey(rl) ? BuiltInRegistries.ITEM.get(rl) : null; }
    private static int iconMax(Item item) { return Math.max(1, item.getDefaultMaxStackSize()); }

}
