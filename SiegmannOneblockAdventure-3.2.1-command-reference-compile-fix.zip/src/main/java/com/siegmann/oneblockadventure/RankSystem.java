package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/** Progression ranks, player-specific prefixes/suffixes, unlockable titles and a below-name rank number. */
public final class RankSystem {
    private static final List<String> RANKS = List.of(
            "Newcomer","Stoneworker","Prospector","Zinc Seeker","Engineer",
            "Machinist","Controller","Goldsmith","Nether Scout","Heat Master",
            "Brasswright","Factory Builder","Agriculturalist","Quartermaster","Electrician",
            "Industrialist","Architect","Railway Worker","Railway Baron","Deep Delver",
            "Ancient Hunter","End Explorer","Void Engineer","Master Automator","OneBlock Legend");
    private RankSystem() {}

    public static int rankNumber(long generated){return Math.min(25,Math.max(1,(CreateProgression.phaseNumber(generated)-1)/10+1));}
    public static String rankName(long generated){return RANKS.get(rankNumber(generated)-1);}
    public static boolean isTitleUnlocked(String title,long generated){return title.equalsIgnoreCase("none")||RANKS.stream().limit(rankNumber(generated)).anyMatch(x->x.equalsIgnoreCase(title));}
    public static List<String> unlockedTitles(long generated){return RANKS.subList(0,rankNumber(generated));}

    public static void update(ServerPlayer player,long generated){
        MinecraftServer server=player.getServer(); if(server==null)return;
        int rank=rankNumber(generated); String name=player.getGameProfile().getName();
        String team="soa_"+Integer.toUnsignedString(player.getUUID().hashCode(),36);
        if(team.length()>16)team=team.substring(0,16);
        AdventureSavedData data=AdventureSavedData.get(player.serverLevel());
        AdventureSavedData.Profile profile=data.profile(player.getUUID());
        if(!profile.title.isBlank()&&!isTitleUnlocked(profile.title,generated)){profile.title="";data.dirty();}
        String suffix=profile.title.isBlank()?"":" <"+profile.title+">";
        run(server,"team add "+team);
        run(server,"team modify "+team+" prefix {\"text\":\"["+escape(rankName(generated))+"] \",\"color\":\"gold\"}");
        run(server,"team modify "+team+" suffix {\"text\":\""+escape(suffix)+"\",\"color\":\"gray\"}");
        run(server,"team join "+team+" "+name);
        run(server,"scoreboard players set "+name+" soa_rank "+rank);
        // The scoreboard team prefix/suffix controls the player-list and overhead name formatting
        // on NeoForge 1.21.1. ServerPlayer#setTabListDisplayName is not available in this mapping.
    }
    private static String escape(String text){return text.replace("\\","\\\\").replace("\"","\\\"");}
    private static void run(MinecraftServer server,String command){try{server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),command);}catch(RuntimeException ignored){}}
}
