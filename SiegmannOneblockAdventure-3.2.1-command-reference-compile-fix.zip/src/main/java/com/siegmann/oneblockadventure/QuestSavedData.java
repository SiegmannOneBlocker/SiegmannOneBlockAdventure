package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class QuestSavedData extends SavedData {
    private static final String NAME = "craftbound_multione_quests";
    private static final Factory<QuestSavedData> FACTORY = new Factory<>(QuestSavedData::new, QuestSavedData::load, null);
    private final Map<UUID, Set<String>> completed = new HashMap<>();

    public static QuestSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    public boolean isCompleted(UUID player, String questId) {
        return completed.getOrDefault(player, Set.of()).contains(questId);
    }

    public boolean complete(UUID player, String questId) {
        boolean added = completed.computeIfAbsent(player, ignored -> new HashSet<>()).add(questId);
        if (added) setDirty();
        return added;
    }

    public void clear(UUID player) { completed.remove(player); setDirty(); }

    public int completedCount(UUID player) {
        return completed.getOrDefault(player, Set.of()).size();
    }

    private static QuestSavedData load(CompoundTag tag, HolderLookup.Provider provider) {
        QuestSavedData data = new QuestSavedData();
        ListTag players = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < players.size(); i++) {
            CompoundTag entry = players.getCompound(i);
            if (!entry.hasUUID("Player")) continue;
            Set<String> quests = new HashSet<>();
            ListTag list = entry.getList("Completed", Tag.TAG_STRING);
            for (int j = 0; j < list.size(); j++) quests.add(list.getString(j));
            data.completed.put(entry.getUUID("Player"), quests);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        ListTag players = new ListTag();
        completed.forEach((uuid, quests) -> {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Player", uuid);
            ListTag list = new ListTag();
            quests.stream().sorted().forEach(id -> list.add(net.minecraft.nbt.StringTag.valueOf(id)));
            entry.put("Completed", list);
            players.add(entry);
        });
        tag.put("Players", players);
        return tag;
    }
}
