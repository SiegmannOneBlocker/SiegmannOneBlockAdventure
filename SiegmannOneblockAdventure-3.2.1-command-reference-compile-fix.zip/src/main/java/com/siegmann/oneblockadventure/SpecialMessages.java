package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class SpecialMessages {
    private SpecialMessages() {}

    public static void created(MinecraftServer server, ServerPlayer owner) {
        broadcast(server, Component.literal("✦ ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(owner.getName().getString() + " has begun a new OneBlock journey!")
                        .withStyle(ChatFormatting.AQUA)));
        owner.sendSystemMessage(Component.literal("Break the block beneath you to begin. Every 200 blocks unlocks a new phase.")
                .withStyle(ChatFormatting.YELLOW));
    }

    public static void phaseUnlocked(MinecraftServer server, ServerPlayer player, int index, CreateProgression.Phase phase) {
        String heading = phase.number() > CreateProgression.STORY_PHASES ? "⚙ ENDLESS MODE: " : "⚙ PHASE " + (index + 1) + ": ";
        broadcast(server, Component.literal(heading).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                .append(Component.literal(phase.name()).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD))
                .append(Component.literal(" — " + player.getName().getString()).withStyle(ChatFormatting.GRAY)));
        player.sendSystemMessage(Component.literal(phase.subtitle()).withStyle(ChatFormatting.YELLOW));
    }

    public static void progress(ServerPlayer player, long generated) {
        CreateProgression.Phase phase = CreateProgression.phase(generated);
        long inPhase = generated % CreateProgression.BLOCKS_PER_PHASE;
        String text = CreateProgression.isEndgame(generated)
                ? phase.name() + " — " + generated + " total blocks; selling is unlocked"
                : "Phase " + phase.number() + "/250 — " + inPhase + "/" + CreateProgression.BLOCKS_PER_PHASE
                    + " blocks — " + phase.name();
        player.sendSystemMessage(Component.literal("⚙ " + text).withStyle(ChatFormatting.AQUA));
    }

    public static void milestone(ServerPlayer player, long generated) {
        player.sendSystemMessage(Component.literal("✦ Milestone reached: " + generated + " blocks!")
                .withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
    }

    private static void broadcast(MinecraftServer server, Component message) {
        server.getPlayerList().broadcastSystemMessage(message, false);
    }
}
