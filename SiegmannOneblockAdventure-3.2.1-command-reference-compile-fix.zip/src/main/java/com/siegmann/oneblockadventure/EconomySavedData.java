package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class EconomySavedData extends SavedData {
    private static final String NAME = "craftbound_multione_economy";
    private static final Factory<EconomySavedData> FACTORY = new Factory<>(EconomySavedData::new, EconomySavedData::load, null);
    private final Map<UUID, Long> balances = new HashMap<>();
    public static EconomySavedData get(ServerLevel level) { return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME); }
    public long balance(UUID id) { return balances.getOrDefault(id, 0L); }
    public void add(UUID id, long amount) { balances.put(id, Math.max(0L, balance(id) + amount)); setDirty(); }
    public boolean take(UUID id, long amount) { if (amount < 0 || balance(id) < amount) return false; add(id, -amount); return true; }
    public void clear(UUID id) { balances.remove(id); setDirty(); }
    private static EconomySavedData load(CompoundTag tag, HolderLookup.Provider provider) {
        EconomySavedData data = new EconomySavedData(); ListTag list = tag.getList("Balances", Tag.TAG_COMPOUND);
        for (int i=0;i<list.size();i++) { CompoundTag e=list.getCompound(i); if(e.hasUUID("Player")) data.balances.put(e.getUUID("Player"), Math.max(0,e.getLong("Cash"))); }
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        ListTag list=new ListTag(); balances.forEach((id,cash)->{CompoundTag e=new CompoundTag();e.putUUID("Player",id);e.putLong("Cash",cash);list.add(e);}); tag.put("Balances",list); return tag;
    }
}
