package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/** Lightweight floating adventure structures that do not require datapacks or worldgen registration. */
public final class StructureSystem {
    private static final List<String> TYPES=List.of("camp","ruin","shrine","tower","factory","pirate_ship","sky_castle");
    private StructureSystem(){}

    public static void generateAroundNewIsland(ServerLevel level, BlockPos island) {
        for(int i=0;i<3;i++){
            int distance=600+i*350+level.getRandom().nextInt(250);
            int dx=level.getRandom().nextBoolean()?distance:-distance;
            int dz=level.getRandom().nextBoolean()?distance/2:-distance/2;
            generate(level,island.offset(dx,level.getRandom().nextInt(30)-10,dz),TYPES.get(level.getRandom().nextInt(TYPES.size())));
        }
    }

    public static BlockPos generateRandom(ServerLevel level, BlockPos origin, String requested) {
        String type=TYPES.contains(requested)?requested:TYPES.get(level.getRandom().nextInt(TYPES.size()));
        int distance=500+level.getRandom().nextInt(1500);double angle=level.getRandom().nextDouble()*Math.PI*2D;
        BlockPos pos=new BlockPos(origin.getX()+(int)(Math.cos(angle)*distance),Math.max(90,origin.getY()+level.getRandom().nextInt(61)-30),origin.getZ()+(int)(Math.sin(angle)*distance));
        generate(level,pos,type);return pos;
    }

    private static void generate(ServerLevel level, BlockPos c, String type) {
        level.getChunk(c);
        int radius=type.equals("sky_castle")?8:type.equals("factory")?6:4;
        for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++){
            if(x*x+z*z>radius*radius+3)continue;
            level.setBlockAndUpdate(c.offset(x,-1,z),Blocks.STONE_BRICKS.defaultBlockState());
            if(Math.abs(x)==radius||Math.abs(z)==radius)level.setBlockAndUpdate(c.offset(x,0,z),Blocks.COBBLESTONE_WALL.defaultBlockState());
        }
        if(type.equals("camp")){level.setBlockAndUpdate(c,Blocks.CAMPFIRE.defaultBlockState());level.setBlockAndUpdate(c.offset(2,0,0),Blocks.OAK_LOG.defaultBlockState());}
        else if(type.equals("tower")||type.equals("sky_castle")){for(int y=0;y<8;y++)for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)if(Math.abs(x)==2||Math.abs(z)==2)level.setBlockAndUpdate(c.offset(x,y,z),Blocks.STONE_BRICKS.defaultBlockState());}
        else if(type.equals("factory")){level.setBlockAndUpdate(c,Blocks.BLAST_FURNACE.defaultBlockState());level.setBlockAndUpdate(c.offset(2,0,0),Blocks.ANVIL.defaultBlockState());}
        else if(type.equals("pirate_ship")){for(int x=-6;x<=6;x++)for(int z=-2;z<=2;z++)level.setBlockAndUpdate(c.offset(x,0,z),Blocks.DARK_OAK_PLANKS.defaultBlockState());for(int y=1;y<8;y++)level.setBlockAndUpdate(c.offset(0,y,0),Blocks.DARK_OAK_LOG.defaultBlockState());}
        else {level.setBlockAndUpdate(c,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());}
        BlockPos chestPos=c.offset(1,0,1);level.setBlockAndUpdate(chestPos,Blocks.CHEST.defaultBlockState());
        if(level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest){chest.setItem(0,new ItemStack(Items.EMERALD,4+level.getRandom().nextInt(13)));chest.setItem(1,new ItemStack(Items.IRON_INGOT,8+level.getRandom().nextInt(17)));chest.setItem(2,new ItemStack(Items.EXPERIENCE_BOTTLE,4+level.getRandom().nextInt(9)));if(type.equals("sky_castle")||type.equals("factory"))chest.setItem(3,new ItemStack(Items.DIAMOND,1+level.getRandom().nextInt(4)));chest.setChanged();}
        CommunitySavedData.get(level).addStructure(type,c);
    }

    public static int locateNearest(ServerPlayer player) {
        var sites=CommunitySavedData.get(player.serverLevel()).structures();if(sites.isEmpty()){player.sendSystemMessage(Component.literal("No adventure structures have generated yet.").withStyle(ChatFormatting.RED));return 0;}
        CommunitySavedData.StructureSite best=null;double dist=Double.MAX_VALUE;for(var s:sites){double d=s.pos().distSqr(player.blockPosition());if(d<dist){dist=d;best=s;}}
        player.sendSystemMessage(Component.literal("Nearest "+best.type().replace('_',' ')+": "+best.pos().toShortString()+" (about "+(int)Math.sqrt(dist)+" blocks)").withStyle(ChatFormatting.AQUA));return 1;
    }
}
