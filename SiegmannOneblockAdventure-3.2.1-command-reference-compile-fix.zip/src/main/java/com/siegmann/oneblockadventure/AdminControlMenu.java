package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Central read-safe administrator control panel. Destructive actions remain command-confirmed. */
public final class AdminControlMenu {
    private AdminControlMenu() {}

    public static void open(ServerPlayer player) {
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Administrator permission is required.").withStyle(ChatFormatting.RED));
            return;
        }
        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new HashMap<>();
        add(inventory, actions, 10, Items.COMPARATOR, "Diagnostics", "Run the full live diagnostics report.", p -> { p.closeContainer(); DiagnosticsSystem.run(p); });
        add(inventory, actions, 11, Items.COMMAND_BLOCK, "Command Reference", "Browse all player and administrator commands.", CommandReferenceMenu::open);
        add(inventory, actions, 12, Items.ENDER_PEARL, "World & Island Teleports", "Browse loaded worlds and all registered islands.", TeleportMenu::open);
        add(inventory, actions, 13, Items.MAP, "Structures", "Browse and teleport to generated structures.", ExpansionSystem::openStructures);
        add(inventory, actions, 14, Items.IRON_SWORD, "Competitive Systems", "PvP arena and Dragon Cup controls/status.", CompetitiveMenu::open);
        add(inventory, actions, 15, Items.EMERALD, "Shop & Economy", economyStatus(player), ShopSystem::openCategories);
        add(inventory, actions, 16, Items.PLAYER_HEAD, "Player Professions", "View your class menu. Use admin commands to reset others.", PlayerClassSystem::open);
        add(inventory, actions, 19, Items.GRASS_BLOCK, "Island Team System", "Review invitations, members, and permissions.", IslandTeamMenu::open);
        add(inventory, actions, 20, Items.BEACON, "Progression", "Inspect phase, prestige, rewards, and milestones.", ExpansionSystem::openProgress);
        add(inventory, actions, 21, Items.CHEST, "Rewards & Kits", "Review playtime rewards and premium kits.", TimeRewardSystem::openMenu);
        add(inventory, actions, 22, Items.CLOCK, "Server Events", "Review active world and seasonal events.", ExpansionSystem::openEvents);
        add(inventory, actions, 23, Items.WRITABLE_BOOK, "Data Configuration", "JSON-driven phase and shop templates are included in config-templates.", p -> p.sendSystemMessage(Component.literal("Edit the generated JSON files while the server is stopped, then restart to reload them.").withStyle(ChatFormatting.YELLOW)));
        add(inventory, actions, 31, Items.BARRIER, "Back", "Return to the main menu.", AdventureSystem::openMenu);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, inventory, actions), Component.literal("SOA Administrator Control")));
    }

    private static String economyStatus(ServerPlayer player) {
        ServerSystemsSavedData data = ServerSystemsSavedData.get(player.serverLevel());
        return "Server economy: buy " + data.economyBuyPercent() + "% / sell " + data.economySellPercent() + "%";
    }

    private static void add(SimpleContainer inventory, Map<Integer, java.util.function.Consumer<ServerPlayer>> actions,
                            int slot, net.minecraft.world.item.Item item, String name, String lore,
                            java.util.function.Consumer<ServerPlayer> action) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        stack.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY), Component.literal("Click").withStyle(ChatFormatting.GREEN))));
        inventory.setItem(slot, stack);
        actions.put(slot, action);
    }
}
