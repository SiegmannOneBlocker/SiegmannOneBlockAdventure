package com.siegmann.oneblockadventure;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class ServerSystemsCommands {
    private ServerSystemsCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        var dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("class")
                .executes(c -> {
                    PlayerClassSystem.open(c.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.literal("choose")
                        .then(Commands.argument("profession", StringArgumentType.word())
                                .executes(c -> PlayerClassSystem.choose(
                                        c.getSource().getPlayerOrException(),
                                        StringArgumentType.getString(c, "profession"), false)))));

        dispatcher.register(Commands.literal("adminmenu")
                .requires(s -> s.hasPermission(2))
                .executes(c -> {
                    AdminControlMenu.open(c.getSource().getPlayerOrException());
                    return 1;
                }));

        dispatcher.register(Commands.literal("soasystems")
                .requires(s -> s.hasPermission(2))
                .executes(c -> status(c.getSource().getPlayerOrException()))
                .then(Commands.literal("menu")
                        .executes(c -> {
                            AdminControlMenu.open(c.getSource().getPlayerOrException());
                            return 1;
                        }))
                .then(Commands.literal("class")
                        .then(Commands.literal("reset")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> PlayerClassSystem.reset(
                                                c.getSource().getPlayerOrException(),
                                                EntityArgument.getPlayer(c, "player")))))
                        .then(Commands.literal("set")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("profession", StringArgumentType.word())
                                                .executes(c -> PlayerClassSystem.choose(
                                                        EntityArgument.getPlayer(c, "player"),
                                                        StringArgumentType.getString(c, "profession"), true)))))
                        .then(Commands.literal("lock")
                                .then(Commands.argument("enabled", BoolArgumentType.bool())
                                        .executes(c -> setClassLock(
                                                c.getSource().getPlayerOrException(),
                                                BoolArgumentType.getBool(c, "enabled"))))))
                .then(Commands.literal("economy")
                        .then(Commands.literal("status")
                                .executes(c -> status(c.getSource().getPlayerOrException())))
                        .then(Commands.literal("buypercent")
                                .then(Commands.argument("percent", IntegerArgumentType.integer(10, 500))
                                        .executes(c -> setEconomy(
                                                c.getSource().getPlayerOrException(), true,
                                                IntegerArgumentType.getInteger(c, "percent")))))
                        .then(Commands.literal("sellpercent")
                                .then(Commands.argument("percent", IntegerArgumentType.integer(10, 500))
                                        .executes(c -> setEconomy(
                                                c.getSource().getPlayerOrException(), false,
                                                IntegerArgumentType.getInteger(c, "percent"))))))
                .then(Commands.literal("season")
                        .then(Commands.literal("next")
                                .executes(c -> nextSeason(c.getSource().getPlayerOrException())))));
    }

    private static int status(ServerPlayer player) {
        ServerSystemsSavedData data = ServerSystemsSavedData.get(player.serverLevel());
        player.sendSystemMessage(Component.literal("SOA systems: economy buy " + data.economyBuyPercent() + "% / sell " + data.economySellPercent() + "% | class lock " + data.classesLockedAfterSelection() + " | season #" + data.seasonNumber()).withStyle(ChatFormatting.GOLD));
        return 1;
    }

    private static int setClassLock(ServerPlayer admin, boolean enabled) {
        ServerSystemsSavedData.get(admin.serverLevel()).setClassesLockedAfterSelection(enabled);
        admin.sendSystemMessage(Component.literal("Profession selection lock set to " + enabled + ".").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int setEconomy(ServerPlayer admin, boolean buy, int percent) {
        ServerSystemsSavedData data = ServerSystemsSavedData.get(admin.serverLevel());
        if (buy) data.setEconomyBuyPercent(percent); else data.setEconomySellPercent(percent);
        admin.sendSystemMessage(Component.literal("Server economy " + (buy ? "buy" : "sell") + " percentage set to " + percent + "%.").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int nextSeason(ServerPlayer admin) {
        ServerSystemsSavedData data = ServerSystemsSavedData.get(admin.serverLevel());
        data.nextSeason();
        admin.getServer().getPlayerList().broadcastSystemMessage(Component.literal("A new SOA season has started: Season #" + data.seasonNumber()).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        return 1;
    }
}
