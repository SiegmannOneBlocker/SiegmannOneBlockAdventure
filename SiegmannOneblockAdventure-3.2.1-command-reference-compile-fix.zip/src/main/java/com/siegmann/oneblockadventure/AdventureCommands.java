package com.siegmann.oneblockadventure;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Locale;

@EventBusSubscriber(modid=SiegmannOneblockAdventure.MOD_ID)
public final class AdventureCommands {
 private AdventureCommands(){}
 @SubscribeEvent public static void register(RegisterCommandsEvent e){
  var d=e.getDispatcher();
  d.register(Commands.literal("menu").executes(c->{AdventureSystem.openMenu(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("spawn").executes(c->AdventureSystem.teleportSpawn(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("teleports").executes(c->{TeleportMenu.open(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("commands").executes(c->{CommandReferenceMenu.open(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("soadiagnose").requires(src->src.hasPermission(2)).executes(c->DiagnosticsSystem.run(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("warp").executes(c->{TeleportMenu.open(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("daily").executes(c->AdventureSystem.daily(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("quest").executes(c->{QuestSystem.open(c.getSource().getPlayerOrException());return 1;}).then(Commands.literal("claim").then(Commands.argument("number",IntegerArgumentType.integer(1)).executes(c->QuestSystem.claim(c.getSource().getPlayerOrException(),IntegerArgumentType.getInteger(c,"number"))))));
  d.register(Commands.literal("crates").executes(c->crates(c.getSource().getPlayerOrException())).then(Commands.literal("open").then(Commands.argument("tier",StringArgumentType.word()).executes(c->AdventureSystem.openCrate(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"tier"))))));
  d.register(Commands.literal("skills").executes(c->skills(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("kit").then(Commands.argument("skill",StringArgumentType.word()).executes(c->SkillKitSystem.claim(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"skill")))));
  d.register(Commands.literal("kits").executes(c->{PremiumKitSystem.openMenu(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("rewards").executes(c->TimeRewardSystem.show(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("stats").executes(c->stats(c.getSource().getPlayerOrException())));
  d.register(Commands.literal("island").executes(c->island(c.getSource().getPlayerOrException())).then(Commands.literal("upgrade").then(Commands.argument("type",StringArgumentType.word()).executes(c->buyUpgrade(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"type"))))));
  d.register(Commands.literal("cosmetics").executes(c->cosmetics(c.getSource().getPlayerOrException())).then(Commands.literal("title").then(Commands.argument("title",StringArgumentType.greedyString()).executes(c->setTitle(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"title"))))).then(Commands.literal("particles").then(Commands.argument("type",StringArgumentType.word()).executes(c->setParticles(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"type"))))).then(Commands.literal("breakeffects").executes(c->toggleBreakEffects(c.getSource().getPlayerOrException()))));
  d.register(Commands.literal("season").executes(c->{c.getSource().sendSuccess(()->Component.literal("Current event: "+AdventureSystem.season()).withStyle(ChatFormatting.GOLD),false);return 1;}));
  d.register(Commands.literal("market").executes(c->market(c.getSource().getPlayerOrException())).then(Commands.literal("sellhand").then(Commands.argument("price",LongArgumentType.longArg(1)).executes(c->marketSell(c.getSource().getPlayerOrException(),LongArgumentType.getLong(c,"price"))))).then(Commands.literal("buy").then(Commands.argument("id",LongArgumentType.longArg(1)).executes(c->marketBuy(c.getSource().getPlayerOrException(),LongArgumentType.getLong(c,"id"))))).then(Commands.literal("cancel").then(Commands.argument("id",LongArgumentType.longArg(1)).executes(c->marketCancel(c.getSource().getPlayerOrException(),LongArgumentType.getLong(c,"id"))))));
  d.register(Commands.literal("soa").executes(c->MultiOneCommands.help(c.getSource()))
   .then(Commands.literal("menu").executes(c->{AdventureSystem.openMenu(c.getSource().getPlayerOrException());return 1;}))
   .then(Commands.literal("spawn").executes(c->AdventureSystem.teleportSpawn(c.getSource().getPlayerOrException())))
   .then(Commands.literal("teleports").executes(c->{TeleportMenu.open(c.getSource().getPlayerOrException());return 1;}))
   .then(Commands.literal("commands").executes(c->{CommandReferenceMenu.open(c.getSource().getPlayerOrException());return 1;}))
   .then(Commands.literal("daily").executes(c->AdventureSystem.daily(c.getSource().getPlayerOrException())))
   .then(Commands.literal("kit").then(Commands.argument("skill",StringArgumentType.word()).executes(c->SkillKitSystem.claim(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"skill")))))
   .then(Commands.literal("kits").executes(c->{PremiumKitSystem.openMenu(c.getSource().getPlayerOrException());return 1;}))
   .then(Commands.literal("rewards").executes(c->TimeRewardSystem.show(c.getSource().getPlayerOrException())))
   .then(Commands.literal("progress").executes(c->MultiOneCommands.progress(c.getSource(),c.getSource().getPlayerOrException())))
   .then(Commands.literal("startnew")
    .executes(c->MultiOneCommands.startNew(c.getSource(),c.getSource().getPlayerOrException(),false))
    .then(Commands.argument("player",EntityArgument.player()).requires(s->s.hasPermission(2))
     .executes(c->MultiOneCommands.startNew(c.getSource(),EntityArgument.getPlayer(c,"player"),true))))
   .then(Commands.literal("create").executes(c->MultiOneCommands.create(c.getSource(),c.getSource().getPlayerOrException(),false)))
   .then(Commands.literal("set").executes(c->MultiOneCommands.set(c.getSource(),c.getSource().getPlayerOrException(),false)))
   .then(Commands.literal("tp").executes(c->MultiOneCommands.tp(c.getSource(),c.getSource().getPlayerOrException())))
   .then(Commands.literal("info").executes(c->MultiOneCommands.info(c.getSource(),c.getSource().getPlayerOrException())))
   .then(Commands.literal("shop").executes(c->MultiOneCommands.shop(c.getSource().getPlayerOrException())))
   .then(Commands.literal("quests").executes(c->MultiOneCommands.quests(c.getSource().getPlayerOrException())))
   .then(Commands.literal("endgame").executes(c->MultiOneCommands.endgame(c.getSource(),c.getSource().getPlayerOrException())))
   .then(Commands.literal("prestige").executes(c->MultiOneCommands.prestige(c.getSource(),c.getSource().getPlayerOrException())))
   .then(Commands.literal("admin").requires(src->src.hasPermission(2))
    .then(Commands.literal("cashmultiplier").then(Commands.argument("value",DoubleArgumentType.doubleArg(0)).executes(c->{AdventureSavedData.get(c.getSource().getLevel()).setGlobalCashMultiplier(DoubleArgumentType.getDouble(c,"value"));return 1;})))
    .then(Commands.literal("raremultiplier").then(Commands.argument("value",DoubleArgumentType.doubleArg(0)).executes(c->{AdventureSavedData.get(c.getSource().getLevel()).setGlobalRareMultiplier(DoubleArgumentType.getDouble(c,"value"));return 1;})))
    .then(Commands.literal("addcash").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("amount",LongArgumentType.longArg(1)).executes(c->adminAddCash(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player"),LongArgumentType.getLong(c,"amount"))))))
    .then(Commands.literal("setphase").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("phase",IntegerArgumentType.integer(1,250)).executes(c->adminSetPhase(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player"),IntegerArgumentType.getInteger(c,"phase"))))))
    .then(Commands.literal("setskillxp").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("skill",StringArgumentType.word()).then(Commands.argument("xp",IntegerArgumentType.integer(0)).executes(c->adminSetSkill(EntityArgument.getPlayer(c,"player"),StringArgumentType.getString(c,"skill"),IntegerArgumentType.getInteger(c,"xp")))))))
    .then(Commands.literal("givecrate").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("tier",StringArgumentType.word()).then(Commands.argument("amount",IntegerArgumentType.integer(1,1000)).executes(c->adminGiveCrate(EntityArgument.getPlayer(c,"player"),StringArgumentType.getString(c,"tier"),IntegerArgumentType.getInteger(c,"amount")))))))
    .then(Commands.literal("setplayhours").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("hours",IntegerArgumentType.integer(0,100000)).executes(c->{TimeRewardSystem.setPlayHours(EntityArgument.getPlayer(c,"player"),IntegerArgumentType.getInteger(c,"hours"));return 1;}))))
    .then(Commands.literal("updateranks").executes(c->{for(ServerPlayer pl:c.getSource().getServer().getPlayerList().getPlayers()){long g=MultiOneSavedData.get(pl.serverLevel()).byOwner(pl.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);ScoreboardSystem.update(pl,g);}return 1;}))
    .then(Commands.literal("shoppercent")
     .executes(c->shopPercentStatus(c.getSource()))
     .then(Commands.literal("global")
      .then(Commands.literal("buy").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setGlobalShopPercent(c.getSource(),"buy",IntegerArgumentType.getInteger(c,"percent")))))
      .then(Commands.literal("sell").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setGlobalShopPercent(c.getSource(),"sell",IntegerArgumentType.getInteger(c,"percent")))))
      .then(Commands.literal("both").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setGlobalShopPercent(c.getSource(),"both",IntegerArgumentType.getInteger(c,"percent"))))))
     .then(Commands.literal("item").then(Commands.argument("item",StringArgumentType.word())
      .then(Commands.literal("buy").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setItemShopPercent(c.getSource(),StringArgumentType.getString(c,"item"),"buy",IntegerArgumentType.getInteger(c,"percent")))))
      .then(Commands.literal("sell").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setItemShopPercent(c.getSource(),StringArgumentType.getString(c,"item"),"sell",IntegerArgumentType.getInteger(c,"percent")))))
      .then(Commands.literal("both").then(Commands.argument("percent",IntegerArgumentType.integer(0,10000)).executes(c->setItemShopPercent(c.getSource(),StringArgumentType.getString(c,"item"),"both",IntegerArgumentType.getInteger(c,"percent")))))))
     .then(Commands.literal("reset")
      .then(Commands.literal("global").executes(c->resetGlobalShopPercent(c.getSource())))
      .then(Commands.literal("item").then(Commands.argument("item",StringArgumentType.word()).executes(c->resetItemShopPercent(c.getSource(),StringArgumentType.getString(c,"item")))))))
    .then(Commands.literal("auditprogression").executes(c->auditProgression(c.getSource().getPlayerOrException())))
    .then(Commands.literal("diagnose").executes(c->DiagnosticsSystem.run(c.getSource().getPlayerOrException())))
    .then(Commands.literal("reload").executes(c->{ExternalContentConfig.load();c.getSource().sendSuccess(()->Component.literal("SiegmannOneblockAdventure configs reloaded. Shop offers: "+ShopSystem.offerCount()),true);return 1;}))));
 }
 public static int showCrates(ServerPlayer p){return crates(p);}
 public static int showSkills(ServerPlayer p){return skills(p);}
 public static int showStats(ServerPlayer p){return stats(p);}
 public static int showIsland(ServerPlayer p){return island(p);}
 public static int showCosmetics(ServerPlayer p){return cosmetics(p);}
 public static int showMarket(ServerPlayer p){return market(p);}

 private static int crates(ServerPlayer p){var d=AdventureSavedData.get(p.serverLevel());p.sendSystemMessage(Component.literal("Crates — common "+d.crateCount(p.getUUID(),"common")+", rare "+d.crateCount(p.getUUID(),"rare")+", epic "+d.crateCount(p.getUUID(),"epic")+", legendary "+d.crateCount(p.getUUID(),"legendary")+", mythic "+d.crateCount(p.getUUID(),"mythic")));return 1;}
 private static int skills(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());p.sendSystemMessage(Component.literal("Skills | Mining "+AdventureSystem.skillLevel(x.miningXp)+" | Engineering "+AdventureSystem.skillLevel(x.engineeringXp)+" | Farming "+AdventureSystem.skillLevel(x.farmingXp)+" | Combat "+AdventureSystem.skillLevel(x.combatXp)));return 1;}
 private static int stats(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());p.sendSystemMessage(Component.literal("Stats | OneBlocks "+x.blocksBroken+" | Cash earned $"+x.cashEarned+" | Crates "+x.cratesOpened+" | Lucky blocks "+x.luckyBlocks+" | Prestige "+PrestigeSavedData.get(p.serverLevel()).level(p.getUUID())));return 1;}
 private static int island(ServerPlayer p){long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());p.sendSystemMessage(Component.literal("Island level "+AdventureSystem.islandLevel(p,g)+" | upgrades: storage "+x.storageUpgrade+", luck "+x.luckUpgrade+", money "+x.moneyUpgrade+", rare "+x.rareUpgrade+", mobdrops "+x.mobDropUpgrade+", experience "+x.experienceUpgrade));return 1;}
 public static int buyUpgrade(ServerPlayer p,String type){var d=AdventureSavedData.get(p.serverLevel());var x=d.profile(p.getUUID());int current=switch(type.toLowerCase(Locale.ROOT)){case"storage"->x.storageUpgrade;case"luck"->x.luckUpgrade;case"money"->x.moneyUpgrade;case"rare"->x.rareUpgrade;case"mobdrops"->x.mobDropUpgrade;case"experience"->x.experienceUpgrade;default->{p.sendSystemMessage(Component.literal("Use storage, luck, money, rare, mobdrops, or experience."));yield -1;}};if(current<0)return 0;long cost=1000L*(current+1)*(current+1);if(!EconomySavedData.get(p.serverLevel()).take(p.getUUID(),cost)){p.sendSystemMessage(Component.literal("Need $"+cost));return 0;}switch(type.toLowerCase(Locale.ROOT)){case"storage"->x.storageUpgrade++;case"luck"->x.luckUpgrade++;case"money"->x.moneyUpgrade++;case"rare"->x.rareUpgrade++;case"mobdrops"->x.mobDropUpgrade++;case"experience"->x.experienceUpgrade++;}d.dirty();p.sendSystemMessage(Component.literal("Upgrade purchased for $"+cost).withStyle(ChatFormatting.GREEN));return 1;}
 private static int cosmetics(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());p.sendSystemMessage(Component.literal("Cosmetics | title: "+(x.title.isBlank()?"none":x.title)+" | particles: "+x.particle+" | break effects: "+x.breakEffects));return 1;}
 public static int setTitle(ServerPlayer p,String s){long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);if(!RankSystem.isTitleUnlocked(s,g)){p.sendSystemMessage(Component.literal("That title has not been unlocked yet.").withStyle(ChatFormatting.RED));return 0;}var d=AdventureSavedData.get(p.serverLevel());var x=d.profile(p.getUUID());x.title=s.equalsIgnoreCase("none")?"":s.substring(0,Math.min(32,s.length()));d.dirty();ScoreboardSystem.update(p,g);p.sendSystemMessage(Component.literal(x.title.isBlank()?"Custom title cleared.":"Title equipped: "+x.title).withStyle(ChatFormatting.GREEN));return 1;}
 public static int setParticles(ServerPlayer p,String s){var d=AdventureSavedData.get(p.serverLevel());var x=d.profile(p.getUUID());x.particle=s.toLowerCase(Locale.ROOT);d.dirty();return 1;}
 public static int toggleBreakEffects(ServerPlayer p){var d=AdventureSavedData.get(p.serverLevel());var x=d.profile(p.getUUID());x.breakEffects=!x.breakEffects;d.dirty();return 1;}
 private static int market(ServerPlayer p){var ls=AdventureSavedData.get(p.serverLevel()).listings();p.sendSystemMessage(Component.literal("Marketplace listings: "+ls.size()).withStyle(ChatFormatting.GOLD));ls.stream().limit(20).forEach(l->p.sendSystemMessage(Component.literal("#"+l.id()+" "+l.count()+"x "+l.itemId()+" — $"+l.price()+" — "+l.sellerName())));return 1;}
 private static int marketSell(ServerPlayer p,long price){ItemStack s=p.getMainHandItem();if(s.isEmpty()){p.sendSystemMessage(Component.literal("Hold the item stack you want to list."));return 0;}String id=BuiltInRegistries.ITEM.getKey(s.getItem()).toString();var l=AdventureSavedData.get(p.serverLevel()).addListing(p.getUUID(),p.getName().getString(),id,s.getCount(),price);s.setCount(0);p.sendSystemMessage(Component.literal("Listed as #"+l.id()));return 1;}
 private static int marketBuy(ServerPlayer p,long id){var d=AdventureSavedData.get(p.serverLevel());var l=d.listing(id);if(l==null){p.sendSystemMessage(Component.literal("Listing not found."));return 0;}if(l.seller().equals(p.getUUID()))return 0;if(!EconomySavedData.get(p.serverLevel()).take(p.getUUID(),l.price())){p.sendSystemMessage(Component.literal("Not enough cash."));return 0;}Item item=AdventureSystem.resolve(l.itemId());if(item==Items.AIR){EconomySavedData.get(p.serverLevel()).add(p.getUUID(),l.price());return 0;}EconomySavedData.get(p.serverLevel()).add(l.seller(),l.price());ItemStack s=new ItemStack(item,l.count());if(!p.getInventory().add(s))p.drop(s,false);d.removeListing(id);return 1;}
 private static int marketCancel(ServerPlayer p,long id){var d=AdventureSavedData.get(p.serverLevel());var l=d.listing(id);if(l==null||(!l.seller().equals(p.getUUID())&&!p.hasPermissions(2)))return 0;Item item=AdventureSystem.resolve(l.itemId());if(item!=Items.AIR){ItemStack s=new ItemStack(item,l.count());if(!p.getInventory().add(s))p.drop(s,false);}d.removeListing(id);return 1;}
 private static int auditProgression(ServerPlayer admin){
  java.util.List<String> problems=new java.util.ArrayList<>();
  for(int i=0;i<CreateProgression.STORY_PHASES;i++){
   var phase=CreateProgression.phaseByIndex(i);
   boolean hasBlock=false;
   for(var entry:phase.blocks()){
    var id=net.minecraft.resources.ResourceLocation.tryParse(entry.id());
    if(entry.weight()>0&&id!=null&&BuiltInRegistries.BLOCK.containsKey(id)){hasBlock=true;break;}
   }
   if(!hasBlock)problems.add("Phase "+phase.number()+" has no registered blocks.");
   for(var reward:phase.rewards()){
    var id=net.minecraft.resources.ResourceLocation.tryParse(reward.itemId());
    if(id==null||!BuiltInRegistries.ITEM.containsKey(id))problems.add("Phase "+phase.number()+" reward is missing: "+reward.itemId());
   }
  }
  if(problems.isEmpty()){admin.sendSystemMessage(Component.literal("Progression audit passed: all 250 phases have registered blocks and all guaranteed rewards exist.").withStyle(ChatFormatting.GREEN));return 1;}
  admin.sendSystemMessage(Component.literal("Progression audit found "+problems.size()+" issue(s):").withStyle(ChatFormatting.RED));
  problems.stream().limit(25).forEach(x->admin.sendSystemMessage(Component.literal("- "+x).withStyle(ChatFormatting.YELLOW)));
  if(problems.size()>25)admin.sendSystemMessage(Component.literal("Only the first 25 issues are shown.").withStyle(ChatFormatting.GRAY));
  return 0;
 }

 private static int shopPercentStatus(CommandSourceStack source){
  ShopPriceSavedData data=ShopPriceSavedData.get(source.getLevel());
  source.sendSuccess(()->Component.literal("Shop price percentages — Buy: "+data.globalBuyPercent()+"% | Sell: "+data.globalSellPercent()+"%").withStyle(ChatFormatting.GOLD),false);
  source.sendSuccess(()->Component.literal("100% = normal price. Example: 150% makes prices 1.5x; 50% makes them half."),false);
  return 1;
 }
 private static int setGlobalShopPercent(CommandSourceStack source,String side,int percent){
  ShopPriceSavedData data=ShopPriceSavedData.get(source.getLevel());
  if(side.equals("buy")||side.equals("both"))data.setGlobalBuyPercent(percent);
  if(side.equals("sell")||side.equals("both"))data.setGlobalSellPercent(percent);
  source.sendSuccess(()->Component.literal("Set global shop "+side+" percentage to "+percent+"%.").withStyle(ChatFormatting.GREEN),true);
  return 1;
 }
 private static int setItemShopPercent(CommandSourceStack source,String rawItem,String side,int percent){
  ResourceLocation id=ResourceLocation.tryParse(rawItem);
  if(id==null||!BuiltInRegistries.ITEM.containsKey(id)){source.sendFailure(Component.literal("Unknown item ID: "+rawItem));return 0;}
  String itemId=id.toString();
  ShopPriceSavedData data=ShopPriceSavedData.get(source.getLevel());
  if(side.equals("buy")||side.equals("both"))data.setItemBuyPercent(itemId,percent);
  if(side.equals("sell")||side.equals("both"))data.setItemSellPercent(itemId,percent);
  source.sendSuccess(()->Component.literal("Set "+itemId+" shop "+side+" percentage to "+percent+"%.").withStyle(ChatFormatting.GREEN),true);
  return 1;
 }
 private static int resetGlobalShopPercent(CommandSourceStack source){
  ShopPriceSavedData.get(source.getLevel()).resetGlobal();
  source.sendSuccess(()->Component.literal("Reset global shop buy and sell percentages to 100%.").withStyle(ChatFormatting.GREEN),true);
  return 1;
 }
 private static int resetItemShopPercent(CommandSourceStack source,String rawItem){
  ResourceLocation id=ResourceLocation.tryParse(rawItem);
  if(id==null){source.sendFailure(Component.literal("Invalid item ID: "+rawItem));return 0;}
  ShopPriceSavedData.get(source.getLevel()).resetItem(id.toString());
  source.sendSuccess(()->Component.literal("Reset shop percentages for "+id+" to 100%.").withStyle(ChatFormatting.GREEN),true);
  return 1;
 }

 private static int adminAddCash(ServerPlayer admin,ServerPlayer target,long amount){EconomySavedData.get(target.serverLevel()).add(target.getUUID(),amount);admin.sendSystemMessage(Component.literal("Added $"+amount+" to "+target.getName().getString()+"."));return 1;}
 private static int adminSetPhase(ServerPlayer admin,ServerPlayer target,int phase){var data=MultiOneSavedData.get(target.serverLevel());var island=data.byOwner(target.getUUID()).orElse(null);if(island==null){admin.sendSystemMessage(Component.literal("That player does not own an island."));return 0;}long generated=(long)(phase-1)*CreateProgression.BLOCKS_PER_PHASE;data.put(island.withGenerated(generated));target.serverLevel().setBlockAndUpdate(island.pos(),CreateProgression.nextBlock(target.serverLevel(),generated));ScoreboardSystem.update(target,generated);admin.sendSystemMessage(Component.literal("Set "+target.getName().getString()+" to phase "+phase+"."));return 1;}
 private static int adminSetSkill(ServerPlayer target,String skill,int xp){var d=AdventureSavedData.get(target.serverLevel());var p=d.profile(target.getUUID());switch(skill.toLowerCase(Locale.ROOT)){case"mining"->p.miningXp=xp;case"engineering"->p.engineeringXp=xp;case"farming"->p.farmingXp=xp;case"combat"->p.combatXp=xp;default->{return 0;}}d.dirty();return 1;}
 private static int adminGiveCrate(ServerPlayer target,String tier,int amount){if(!java.util.List.of("common","rare","epic","legendary","mythic").contains(tier.toLowerCase(Locale.ROOT)))return 0;AdventureSavedData.get(target.serverLevel()).addCrate(target.getUUID(),tier.toLowerCase(Locale.ROOT),amount);return 1;}

}
