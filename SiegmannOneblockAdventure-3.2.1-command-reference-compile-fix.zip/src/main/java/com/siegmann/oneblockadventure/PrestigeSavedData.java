package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PrestigeSavedData extends SavedData {
    private static final String NAME = "craftbound_multione_prestige";
    private static final Factory<PrestigeSavedData> FACTORY =
            new Factory<>(PrestigeSavedData::new, PrestigeSavedData::load, null);

    private final Map<UUID, Integer> prestige = new HashMap<>();

    public static PrestigeSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    public int level(UUID owner) {
        return Math.max(0, prestige.getOrDefault(owner, 0));
    }

    public void clear(UUID owner) { prestige.remove(owner); setDirty(); }

    public int add(UUID owner) {
        int value = level(owner) + 1;
        prestige.put(owner, value);
        setDirty();
        return value;
    }

    private static PrestigeSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        PrestigeSavedData data = new PrestigeSavedData();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            if (entry.hasUUID("Owner")) {
                data.prestige.put(entry.getUUID("Owner"), Math.max(0, entry.getInt("Level")));
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Integer> value : prestige.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Owner", value.getKey());
            entry.putInt("Level", value.getValue());
            list.add(entry);
        }
        tag.put("Players", list);
        return tag;
    }
}
