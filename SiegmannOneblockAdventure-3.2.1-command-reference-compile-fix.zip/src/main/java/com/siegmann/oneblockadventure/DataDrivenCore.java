package com.siegmann.oneblockadventure;

import com.google.gson.*;
import net.neoforged.fml.loading.FMLPaths;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Creates, loads and validates server-editable JSON. Invalid files never replace the last good snapshot. */
public final class DataDrivenCore {
    private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
    private static final String[] FOLDERS={"phases","shops","structures","loot","bosses","economy","professions","rewards","events","menus","language"};
    private static volatile Snapshot snapshot=new Snapshot(Map.of(),List.of("Configuration has not loaded yet."));
    public record Snapshot(Map<String,JsonElement> documents,List<String> errors){}
    private DataDrivenCore(){}
    public static Path root(){return FMLPaths.CONFIGDIR.get().resolve("siegmann_oneblock_adventure");}
    public static synchronized Snapshot reload(){
        List<String> errors=new ArrayList<>();Map<String,JsonElement> docs=new TreeMap<>();
        try{Files.createDirectories(root());for(String f:FOLDERS)Files.createDirectories(root().resolve(f));writeDefaults();
            try(var stream=Files.walk(root())){stream.filter(p->p.toString().endsWith(".json")).sorted().forEach(p->{try(Reader r=Files.newBufferedReader(p,StandardCharsets.UTF_8)){JsonElement e=JsonParser.parseReader(r);if(!e.isJsonObject()&&!e.isJsonArray())throw new JsonParseException("Root must be object or array");docs.put(root().relativize(p).toString().replace('\\','/'),e);}catch(Exception ex){errors.add(root().relativize(p)+": "+ex.getMessage());}});}
        }catch(IOException ex){errors.add("Cannot initialize config directory: "+ex.getMessage());}
        if(errors.isEmpty()||snapshot.documents().isEmpty())snapshot=new Snapshot(Collections.unmodifiableMap(docs),List.copyOf(errors));
        else snapshot=new Snapshot(snapshot.documents(),List.copyOf(errors));
        return snapshot;
    }
    public static Snapshot snapshot(){return snapshot;}
    public static List<String> validate(){return reload().errors();}
    private static void writeDefaults() throws IOException{
        defaultFile("economy/settings.json","{\n  \"buy_percent\": 100,\n  \"sell_percent\": 100,\n  \"dynamic_pricing\": false\n}\n");
        defaultFile("events/settings.json","{\n  \"dragon_cup_hours\": 72,\n  \"dragon_cup_slots\": 5,\n  \"warning_minutes\": 10\n}\n");
        defaultFile("menus/settings.json","{\n  \"show_locked_features\": true,\n  \"enable_admin_menu\": true\n}\n");
        defaultFile("structures/README.json","{\n  \"note\": \"Place structure definitions here. Unknown fields are ignored safely.\",\n  \"enabled\": true\n}\n");
        defaultFile("language/en_us.json","{\n  \"menu.main\": \"Siegmann OneBlock Adventure\",\n  \"error.permission\": \"You do not have permission.\"\n}\n");
    }
    private static void defaultFile(String rel,String text)throws IOException{Path p=root().resolve(rel);if(Files.notExists(p)){Files.createDirectories(p.getParent());Files.writeString(p,text,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);}}
}
