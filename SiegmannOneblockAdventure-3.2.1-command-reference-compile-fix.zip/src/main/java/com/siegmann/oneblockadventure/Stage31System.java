package com.siegmann.oneblockadventure;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

@EventBusSubscriber(modid=SiegmannOneblockAdventure.MOD_ID)
public final class Stage31System {
 private static long lastSecond;
 private Stage31System(){}
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){var d=e.getDispatcher();
  d.register(Commands.literal("guide").executes(c->{Stage31Menus.openGuide(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("events").executes(c->{Stage31Menus.openEvents(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("createprogress").executes(c->{Stage31Menus.openCreate(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("worldprofiles").requires(s->s.hasPermission(2)).executes(c->{Stage31Menus.openWorldProfiles(c.getSource().getPlayerOrException());return 1;}));
  d.register(Commands.literal("soastage31").requires(s->s.hasPermission(2))
   .then(Commands.literal("event").then(Commands.literal("start").then(Commands.argument("type",StringArgumentType.word()).then(Commands.argument("minutes",IntegerArgumentType.integer(1,10080)).executes(c->startEvent(c.getSource().getServer(),StringArgumentType.getString(c,"type"),IntegerArgumentType.getInteger(c,"minutes")))))).then(Commands.literal("stop").executes(c->stopEvent(c.getSource().getServer()))))
   .then(Commands.literal("worldprofile").then(Commands.argument("profile",StringArgumentType.word()).executes(c->setProfile(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"profile")))))
   .then(Commands.literal("hub").then(Commands.literal("generate").executes(c->generateHub(c.getSource().getPlayerOrException()))))
   .then(Commands.literal("backup").executes(c->backup(c.getSource().getPlayerOrException())))
   .then(Commands.literal("dashboard").then(Commands.literal("export").executes(c->exportDashboard(c.getSource().getPlayerOrException()))))
   .then(Commands.literal("compat").executes(c->compat(c.getSource().getPlayerOrException()))));
 }
 @SubscribeEvent public static void tick(ServerTickEvent.Post e){long now=System.currentTimeMillis();if(now-lastSecond<1000)return;lastSecond=now;Stage31SavedData data=Stage31SavedData.get(e.getServer().overworld());if(!"none".equals(data.activeEvent)&&data.eventEndsAt>0&&now>=data.eventEndsAt)stopEvent(e.getServer());}
 public static int startEvent(MinecraftServer s,String type,int minutes){Set<String> allowed=Set.of("double_cash","lucky_hour","rare_merchant","meteor_shower","factory_overload","boss_invasion","treasure_hunt");type=type.toLowerCase(Locale.ROOT);if(!allowed.contains(type))return 0;Stage31SavedData d=Stage31SavedData.get(s.overworld());d.activeEvent=type;d.eventEndsAt=System.currentTimeMillis()+minutes*60000L;d.dirty();s.getPlayerList().broadcastSystemMessage(Component.literal("Live event started: "+type.replace('_',' ')+" for "+minutes+" minutes.").withStyle(ChatFormatting.GOLD),false);return 1;}
 public static int stopEvent(MinecraftServer s){Stage31SavedData d=Stage31SavedData.get(s.overworld());String old=d.activeEvent;d.activeEvent="none";d.eventEndsAt=0;d.dirty();if(!"none".equals(old))s.getPlayerList().broadcastSystemMessage(Component.literal("Live event ended: "+old.replace('_',' ')).withStyle(ChatFormatting.YELLOW),false);return 1;}
 public static double cashMultiplier(ServerPlayer p){return "double_cash".equals(Stage31SavedData.get(p.serverLevel()).activeEvent)?2D:1D;}
 private static int setProfile(ServerPlayer p,String profile){Set<String> all=Set.of("classic_oneblock","shared_oneblock","skygrid","void","hardcore","creative","adventure");profile=profile.toLowerCase(Locale.ROOT);if(!all.contains(profile)){p.sendSystemMessage(Component.literal("Unknown profile. Use /worldprofiles."));return 0;}Stage31SavedData d=Stage31SavedData.get(p.serverLevel());d.worldProfile=profile;d.dirty();p.sendSystemMessage(Component.literal("World profile set to "+profile+". This changes SOA rules; it does not replace a loaded dimension save.").withStyle(ChatFormatting.GREEN));return 1;}
 private static int generateHub(ServerPlayer p){ServerLevel l=p.getServer().overworld();BlockPos s=l.getSharedSpawnPos();for(int x=-9;x<=9;x++)for(int z=-9;z<=9;z++){double dist=Math.sqrt(x*x+z*z);BlockPos q=s.offset(x,0,z);if(dist<=9)l.setBlock(q,dist>7?Blocks.POLISHED_ANDESITE.defaultBlockState():Blocks.SMOOTH_STONE.defaultBlockState(),3);}l.setBlock(s.above(),Blocks.BEACON.defaultBlockState(),3);p.sendSystemMessage(Component.literal("Spawn hub platform generated. NPC services are represented by protected menus to avoid entity compatibility problems.").withStyle(ChatFormatting.GREEN));return 1;}
 private static int backup(ServerPlayer p){try{p.getServer().saveEverything(true,true,true);Path root=p.getServer().getServerDirectory().resolve("soa-backups");Files.createDirectories(root);String stamp=String.valueOf(Instant.now().toEpochMilli());Path out=root.resolve("backup-"+stamp+".txt");Files.writeString(out,"SOA backup marker\nCreated: "+Instant.now()+"\nWorld profile: "+Stage31SavedData.get(p.serverLevel()).worldProfile+"\nConfig root: "+DataDrivenCore.root()+"\n",StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);p.sendSystemMessage(Component.literal("Server data saved and backup marker created: "+out.getFileName()+". Use host-level backups for full world rollback.").withStyle(ChatFormatting.GREEN));return 1;}catch(IOException ex){p.sendSystemMessage(Component.literal("Backup marker failed: "+ex.getMessage()).withStyle(ChatFormatting.RED));return 0;}}
 private static int exportDashboard(ServerPlayer p){try{Path dir=p.getServer().getServerDirectory().resolve("soa-dashboard");Files.createDirectories(dir);Stage31SavedData d=Stage31SavedData.get(p.serverLevel());String json="{\n  \"generatedAt\": \""+Instant.now()+"\",\n  \"onlinePlayers\": "+p.getServer().getPlayerCount()+",\n  \"worldProfile\": \""+d.worldProfile+"\",\n  \"activeEvent\": \""+d.activeEvent+"\",\n  \"dragonCupRegistered\": "+CompetitiveSavedData.get(p.serverLevel()).dragonRegistered.size()+"\n}\n";Files.writeString(dir.resolve("status.json"),json,StandardCharsets.UTF_8);p.sendSystemMessage(Component.literal("Dashboard JSON exported to soa-dashboard/status.json").withStyle(ChatFormatting.GREEN));return 1;}catch(IOException ex){p.sendSystemMessage(Component.literal("Dashboard export failed: "+ex.getMessage()).withStyle(ChatFormatting.RED));return 0;}}
 private static int compat(ServerPlayer p){String[] mods={"create","openpartiesandclaims","luckperms","voicechat","connector","craftbound_oneblock"};for(String id:mods)p.sendSystemMessage(Component.literal((ModList.get().isLoaded(id)?"✔ ":"✘ ")+id).withStyle(ModList.get().isLoaded(id)?ChatFormatting.GREEN:ChatFormatting.RED));return 1;}
}
