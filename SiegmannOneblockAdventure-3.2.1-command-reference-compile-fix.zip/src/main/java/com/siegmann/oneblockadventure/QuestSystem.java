package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public final class QuestSystem {
    public enum Type { BLOCKS, ITEM }
    public record Quest(String id, String title, String description, Type type, long target, String itemId, int itemCount, long cash) {}

    public static final List<Quest> QUESTS = List.of(
            qBlocks("first_breaks", "Getting Started", "Break 100 OneBlocks", 100, 100),
            qBlocks("phase_5", "Workshop Foundations", "Reach Phase 5", 1_000, 250),
            qItem("water_wheel", "Water Power", "Carry a Create Water Wheel", "create:water_wheel", 1, 300),
            qItem("andesite_alloy", "Andesite Engineer", "Carry 16 Andesite Alloy", "create:andesite_alloy", 16, 350),
            qBlocks("phase_10", "First Era Complete", "Reach Phase 10", 2_250, 500),
            qItem("mechanical_press", "Pressing Matters", "Carry a Mechanical Press", "create:mechanical_press", 1, 500),
            qItem("mechanical_mixer", "Mixing It Up", "Carry a Mechanical Mixer", "create:mechanical_mixer", 1, 550),
            qItem("depot", "Factory Floor", "Carry 4 Depots", "create:depot", 4, 450),
            qBlocks("phase_25", "Industrial Apprentice", "Reach Phase 25", 6_000, 900),
            qItem("blaze_burner", "Controlled Heat", "Carry a Blaze Burner", "create:blaze_burner", 1, 900),
            qItem("brass", "Brass Age", "Carry 16 Brass Ingots", "create:brass_ingot", 16, 600),
            qItem("precision", "Precision Engineering", "Carry 4 Precision Mechanisms", "create:precision_mechanism", 4, 1_250),
            qBlocks("phase_50", "Mechanical Expert", "Reach Phase 50", 12_250, 1_500),
            qItem("deployer", "Automated Hands", "Carry a Deployer", "create:deployer", 1, 1_200),
            qItem("mechanical_arm", "Factory Logistics", "Carry a Mechanical Arm", "create:mechanical_arm", 1, 1_500),
            qItem("crafter", "Complex Assembly", "Carry 9 Mechanical Crafters", "create:mechanical_crafter", 9, 1_800),
            qBlocks("phase_75", "Factory Owner", "Reach Phase 75", 18_500, 2_000),
            qItem("electric_motor", "Electric Expansion", "Carry an Electric Motor", "createaddition:electric_motor", 1, 2_000),
            qItem("portable_storage", "Portable Logistics", "Carry 2 Portable Storage Interfaces", "create:portable_storage_interface", 2, 1_800),
            qBlocks("phase_100", "Century Engineer", "Reach Phase 100", 24_750, 3_000),
            qItem("train_casing", "Railway Builder", "Carry 8 Railway Casings", "create:railway_casing", 8, 2_500),
            qItem("track", "On Track", "Carry 64 Train Tracks", "create:track", 64, 2_500),
            qBlocks("phase_150", "Industrial Titan", "Reach Phase 150", 37_250, 4_500),
            qItem("diamond", "Rare Resources", "Carry 16 Diamonds", "minecraft:diamond", 16, 3_000),
            qItem("shulker", "End Logistics", "Carry 4 Shulker Shells", "minecraft:shulker_shell", 4, 3_500),
            qBlocks("phase_200", "World Architect", "Reach Phase 200", 49_750, 6_000),
            qItem("netherite", "Ancient Engineering", "Carry a Netherite Ingot", "minecraft:netherite_ingot", 1, 5_000),
            qItem("elytra", "Master of the End", "Carry an Elytra", "minecraft:elytra", 1, 3_600),
            qBlocks("phase_250", "Legendary Engineer", "Complete Phase 250", 62_500, 12_500),
            qBlocks("endgame_10", "Endless Veteran", "Complete 10 endless cycles", 65_000, 15_000)
    );

    private QuestSystem() {}
    private static Quest qBlocks(String id, String title, String description, long target, long cash) { return new Quest(id,title,description,Type.BLOCKS,target,"",0,cash); }
    private static Quest qItem(String id, String title, String description, String item, int count, long cash) { return new Quest(id,title,description,Type.ITEM,0,item,count,cash); }

    public static void checkBlockQuests(ServerPlayer player, long generated) {
        for (Quest q : QUESTS) if (q.type() == Type.BLOCKS && generated >= q.target()) complete(player, q);
    }

    public static boolean claimItemQuest(ServerPlayer player, Quest q) {
        if (q.type() != Type.ITEM || QuestSavedData.get(player.serverLevel()).isCompleted(player.getUUID(), q.id())) return false;
        ResourceLocation id = ResourceLocation.tryParse(q.itemId());
        if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) return false;
        Item item = BuiltInRegistries.ITEM.get(id);
        int count = player.getInventory().countItem(item);
        if (count < q.itemCount()) {
            player.sendSystemMessage(Component.literal("You need " + q.itemCount() + "x " + new ItemStack(item).getHoverName().getString() + ". You currently have " + count + ".").withStyle(ChatFormatting.RED));
            return false;
        }
        return complete(player, q);
    }

    private static boolean complete(ServerPlayer player, Quest q) {
        QuestSavedData data = QuestSavedData.get(player.serverLevel());
        if (!data.complete(player.getUUID(), q.id())) return false;
        EconomySavedData.get(player.serverLevel()).add(player.getUUID(), q.cash());
        player.sendSystemMessage(Component.literal("QUEST COMPLETE: " + q.title()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        player.sendSystemMessage(Component.literal("+$" + q.cash() + " — " + q.description()).withStyle(ChatFormatting.GREEN));
        ScoreboardSystem.update(player, MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L));
        return true;
    }

    public static void open(ServerPlayer player) {
        SimpleContainer inventory = new SimpleContainer(54);
        java.util.Map<Integer, java.util.function.Consumer<ServerPlayer>> actions = new java.util.HashMap<>();
        QuestSavedData data = QuestSavedData.get(player.serverLevel());
        long generated = MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID())
                .map(MultiOneSavedData.Island::generated).orElse(0L);
        for (int i = 0; i < QUESTS.size() && i < 45; i++) {
            Quest q = QUESTS.get(i);
            boolean done = data.isCompleted(player.getUUID(), q.id());
            ItemStack icon = questIcon(q, done);
            java.util.List<Component> lore = new java.util.ArrayList<>();
            lore.add(Component.literal(q.description()).withStyle(ChatFormatting.GRAY));
            lore.add(Component.literal("Reward: $" + q.cash()).withStyle(ChatFormatting.GOLD));
            if (done) lore.add(Component.literal("Completed").withStyle(ChatFormatting.GREEN));
            else if (q.type() == Type.BLOCKS) lore.add(Component.literal("Progress: " + Math.min(generated, q.target()) + "/" + q.target()).withStyle(ChatFormatting.YELLOW));
            else lore.add(Component.literal("Click to claim when the items are in your inventory").withStyle(ChatFormatting.YELLOW));
            icon.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(lore));
            inventory.setItem(i, icon);
            final int questNumber = i + 1;
            if (!done) actions.put(i, p -> { claim(p, questNumber); open(p); });
        }
        ItemStack info = new ItemStack(Items.PAPER);
        info.set(DataComponents.CUSTOM_NAME, Component.literal("Click a quest to claim it").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD));
        inventory.setItem(49, info);
        ItemStack back = new ItemStack(Items.BARRIER);
        back.set(DataComponents.CUSTOM_NAME, Component.literal("Back to Main Menu").withStyle(ChatFormatting.RED));
        inventory.setItem(53, back);
        actions.put(53, AdventureSystem::openMenu);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(6, id, inv, inventory, actions),
                Component.literal("Siegmann Quests — " + data.completedCount(player.getUUID()) + "/" + QUESTS.size())));
    }

    public static int claim(ServerPlayer player, int number) {
        if (number < 1 || number > QUESTS.size()) return 0;
        Quest q = QUESTS.get(number - 1);
        if (q.type() == Type.BLOCKS) {
            long generated = MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);
            if (generated >= q.target()) return complete(player, q) ? 1 : 0;
            player.sendSystemMessage(Component.literal("That quest is not complete yet.").withStyle(ChatFormatting.RED));
            return 0;
        }
        return claimItemQuest(player, q) ? 1 : 0;
    }

    private static ItemStack questIcon(Quest q, boolean done) {
        ItemStack stack;
        if (q.type() == Type.ITEM) {
            ResourceLocation id = ResourceLocation.tryParse(q.itemId());
            stack = id != null && BuiltInRegistries.ITEM.containsKey(id) ? new ItemStack(BuiltInRegistries.ITEM.get(id)) : new ItemStack(Items.BARRIER);
        } else stack = new ItemStack(done ? Items.LIME_DYE : Items.CLOCK);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal((done ? "✓ " : "") + q.title() + " — $" + q.cash()).withStyle(done ? ChatFormatting.GREEN : ChatFormatting.GOLD));
        return stack;
    }
}
