package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** Read-only live diagnostics. It never changes worlds or player data. */
public final class DiagnosticsSystem {
    private DiagnosticsSystem() {}

    public static void openMenu(ServerPlayer player) {
        if (!player.hasPermissions(2)) return;
        SimpleContainer c = new SimpleContainer(27);
        Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
        button(c, a, 11, Items.COMPARATOR, "Run Full Diagnostics", "Print live system checks to chat.", p -> { p.closeContainer(); run(p); });
        button(c, a, 13, Items.WRITTEN_BOOK, "Command Guide", "Open the complete command reference.", CommandReferenceMenu::open);
        button(c, a, 15, Items.MAP, "Teleport Hub", "Inspect worlds, islands, structures, and destinations.", TeleportMenu::open);
        button(c, a, 22, Items.BARRIER, "Back", "Return to the main menu.", AdventureSystem::openMenu);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new ActionMenu(3, id, inv, c, a), Component.literal("Server Diagnostics")));
    }

    public static int run(ServerPlayer admin) {
        if (!admin.hasPermissions(2)) return 0;
        List<String> warnings = new ArrayList<>();
        var server = admin.getServer();
        var overworld = server.overworld();
        int worlds = 0;
        for (var ignored : server.getAllLevels()) worlds++;
        int islands = MultiOneSavedData.get(overworld).all().size();
        int structures = CommunitySavedData.get(overworld).structures().size();
        int offers = ShopSystem.offerCount();
        int badPhases = 0;
        for (int i = 0; i < CreateProgression.STORY_PHASES; i++) {
            var phase = CreateProgression.phaseByIndex(i);
            if (phase.blocks().isEmpty()) badPhases++;
        }
        if (badPhases > 0) warnings.add(badPhases + " phase(s) have no configured block entries");
        if (offers <= 0) warnings.add("shop has no active offers");
        if (islands > 0 && structures == 0) warnings.add("islands exist but no adventure structures are registered");
        var competition = CompetitiveSavedData.get(overworld);
        admin.sendSystemMessage(Component.literal("SOA 2.3 diagnostics").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        line(admin, "Loaded worlds", worlds);
        line(admin, "Registered islands", islands);
        line(admin, "Registered structures", structures);
        line(admin, "Shop offers", offers);
        line(admin, "Story phases", CreateProgression.STORY_PHASES);
        line(admin, "PvP arena", competition.arenaCenter == null ? "not generated" : competition.arenaCenter.toShortString());
        line(admin, "Dragon Cup registrations", competition.dragonRegistered.size() + "/5");
        if (warnings.isEmpty()) admin.sendSystemMessage(Component.literal("No live diagnostic warnings found.").withStyle(ChatFormatting.GREEN));
        else for (String warning : warnings) admin.sendSystemMessage(Component.literal("Warning: " + warning).withStyle(ChatFormatting.YELLOW));
        return warnings.isEmpty() ? 1 : 0;
    }

    private static void line(ServerPlayer p, String name, Object value) {
        p.sendSystemMessage(Component.literal(name + ": " + value).withStyle(ChatFormatting.GRAY));
    }

    private static void button(SimpleContainer c, Map<Integer, Consumer<ServerPlayer>> a, int slot, Item icon,
                               String name, String lore, Consumer<ServerPlayer> action) {
        ItemStack s = new ItemStack(icon);
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        s.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY))));
        c.setItem(slot, s);
        a.put(slot, action);
    }
}
