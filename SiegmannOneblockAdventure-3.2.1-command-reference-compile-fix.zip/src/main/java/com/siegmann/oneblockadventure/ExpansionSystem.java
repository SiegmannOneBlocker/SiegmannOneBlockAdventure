package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

public final class ExpansionSystem {
    private ExpansionSystem(){}

    public static void openHub(ServerPlayer p){
        SimpleContainer c=new SimpleContainer(54);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();
        button(c,a,10,Items.COMPASS,"Progress & Phase Counter","Current phase, blocks remaining, era, rank, and next unlock.",ExpansionSystem::openProgress);
        button(c,a,11,Items.GOLDEN_HELMET,"Leaderboards","Phase, money, prestige, playtime, island level, ratings, and bosses.",ExpansionSystem::openLeaderboards);
        button(c,a,12,Items.MAP,"Adventure Structures","Locate floating ruins, camps, towers, factories, ships, and castles.",ExpansionSystem::openStructures);
        button(c,a,13,Items.BOOK,"Encyclopedia","See obtainable systems and discovered content.",ExpansionSystem::openEncyclopedia);
        button(c,a,14,Items.CHEST,"Collection Log","Track structures, crates, rewards, bosses, and discoveries.",ExpansionSystem::openCollection);
        button(c,a,15,Items.TOTEM_OF_UNDYING,"Achievements","Claim milestone rewards and unlock titles.",ExpansionSystem::openAchievements);
        button(c,a,16,Items.WRITABLE_BOOK,"Daily Challenge","A rotating daily objective with cash and crate rewards.",ExpansionSystem::openDailyChallenge);
        button(c,a,19,Items.NETHER_STAR,"Artifacts","Rare permanent bonus items and equipped artifact.",ExpansionSystem::openArtifacts);
        button(c,a,20,Items.EMERALD,"Traveling Merchant","Limited high-value offers that refresh over time.",ExpansionSystem::openMerchant);
        button(c,a,21,Items.LIGHTNING_ROD,"World Events","Server-wide bonuses such as Lucky Hour and Double Cash.",ExpansionSystem::openEvents);
        button(c,a,22,Items.FIREWORK_ROCKET,"Seasonal Events","Season, exclusive objectives, and event rewards.",AdventureSystem::openSeasonMenu);
        button(c,a,23,Items.PLAYER_HEAD,"Island Ratings","Rate visited islands and view the top-rated builders.",ExpansionSystem::openRatings);
        button(c,a,24,Items.IRON_SWORD,"Weekly Boss","Boss status, participation, kills, and reward information.",ExpansionSystem::openWeeklyBoss);
        button(c,a,28,Items.GRASS_BLOCK,"Island","Island upgrades and teleportation.",AdventureSystem::openIslandMenu);
        button(c,a,29,Items.GOLD_INGOT,"Shop","Browse unlocked items and kits.",ShopSystem::openCategories);
        button(c,a,30,Items.BOOKSHELF,"Quests","Story and progression quests.",QuestSystem::open);
        button(c,a,31,Items.DIAMOND_PICKAXE,"Skills","Skill levels and claimable skill kits.",AdventureSystem::openSkillsMenu);
        button(c,a,32,Items.FIREWORK_STAR,"Cosmetics","Ranks, titles, particles, and effects.",AdventureSystem::openCosmeticsMenu);
        button(c,a,33,Items.CLOCK,"Rewards","Playtime, milestone, crate, and kit rewards.",TimeRewardSystem::openMenu);
        button(c,a,40,Items.BARRIER,"Back","Return to the main menu.",AdventureSystem::openMenu);
        open(p,c,a,6,"Adventure & Community");
    }

    public static void openProgress(ServerPlayer p){
        long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);
        var phase=CreateProgression.phase(g);int within=(int)(g%CreateProgression.BLOCKS_PER_PHASE);if(CreateProgression.isEndgame(g))within=(int)(EndgameSystem.endgameBlocks(g)%CreateProgression.BLOCKS_PER_PHASE);
        SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();
        label(c,4,Items.COMPASS,"Phase "+phase.number()+" / 250",phase.name());
        label(c,10,Items.STONE,"Phase Progress",within+" / "+CreateProgression.BLOCKS_PER_PHASE+" blocks");
        label(c,11,Items.REDSTONE_TORCH,"Blocks Remaining",String.valueOf(Math.max(0,CreateProgression.BLOCKS_PER_PHASE-within)));
        label(c,12,Items.CLOCK,"Total Broken",String.valueOf(g));
        label(c,13,Items.GOLD_INGOT,"Balance","$"+EconomySavedData.get(p.serverLevel()).balance(p.getUUID()));
        label(c,14,Items.NAME_TAG,"Current Rank",RankSystem.rankName(g));
        label(c,15,Items.BEACON,"Prestige",String.valueOf(PrestigeSavedData.get(p.serverLevel()).level(p.getUUID())));
        label(c,16,Items.CHEST,"Next Milestone",nextMilestone(g));
        button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Progress & Phase Counter");
    }

    private static String nextMilestone(long g){int phase=CreateProgression.phase(g).number();if(phase>=250)return "Endless Tier "+EndgameSystem.tier(g);int next=((phase/10)+1)*10;return "Phase "+Math.min(250,next)+" reward and rank unlock";}

    public static void openLeaderboards(ServerPlayer p){
        SimpleContainer c=new SimpleContainer(54);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();
        List<MultiOneSavedData.Island> islands=new ArrayList<>(MultiOneSavedData.get(p.serverLevel()).all());
        islands.sort(Comparator.comparingLong(MultiOneSavedData.Island::generated).reversed());
        int slot=0;for(var island:islands){if(slot>=18)break;String name=CommunitySavedData.get(p.serverLevel()).name(island.owner());int phase=CreateProgression.phase(island.generated()).number();label(c,slot++,Items.COMPASS,"#"+slot+" "+name,"Phase "+phase+" | "+island.generated()+" blocks");}
        List<UUID> ids=new ArrayList<>(CommunitySavedData.get(p.serverLevel()).playerIds());ids.sort(Comparator.comparingLong((UUID id)->EconomySavedData.get(p.serverLevel()).balance(id)).reversed());
        slot=27;for(UUID id:ids){if(slot>=45)break;label(c,slot++,Items.GOLD_INGOT,"#"+(slot-26)+" "+CommunitySavedData.get(p.serverLevel()).name(id),"$"+EconomySavedData.get(p.serverLevel()).balance(id)+" | Prestige "+PrestigeSavedData.get(p.serverLevel()).level(id));}
        button(c,a,49,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,6,"Leaderboards: Phase & Money");
    }

    public static void openStructures(ServerPlayer p){SimpleContainer c=new SimpleContainer(27);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.MAP,"Generated Structures",String.valueOf(CommunitySavedData.get(p.serverLevel()).structures().size()));button(c,a,13,Items.COMPASS,"Locate Nearest","Shows coordinates of the nearest generated structure.",pl->{pl.closeContainer();StructureSystem.locateNearest(pl);});label(c,16,Items.CHEST,"Possible Loot","Emeralds, iron, XP bottles, diamonds, keys, and rare materials.");button(c,a,22,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,3,"Adventure Structures");}
    public static void openEncyclopedia(ServerPlayer p){SimpleContainer c=new SimpleContainer(45);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.GRASS_BLOCK,"OneBlock Progression","250 phases, 250 blocks each, then Endless Mode.");label(c,11,Items.CHEST,"Rewards","Phase rewards, random rewards, utility chests, crates, kits, and playtime rewards.");label(c,12,Items.COW_SPAWN_EGG,"Animals","Animal eggs and live arrivals unlock through progression.");label(c,13,Items.EMERALD,"Villagers","Villager eggs at 4 and 10 active play hours.");label(c,14,Items.NETHER_STAR,"Endgame","Spawner shop, events, bosses, selling, prestige, and artifacts.");label(c,15,Items.MAP,"Exploration","Floating structures generate around new islands and through admin commands.");label(c,16,Items.NAME_TAG,"Ranks & Titles","25 progression ranks plus unlockable titles.");button(c,a,40,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,5,"OneBlock Encyclopedia");}
    public static void openCollection(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());var q=QuestSavedData.get(p.serverLevel());var cp=CommunitySavedData.get(p.serverLevel()).profile(p.getUUID());SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.MAP,"Structures Found",String.valueOf(cp.structuresFound));label(c,11,Items.CHEST,"Crates Opened",String.valueOf(x.cratesOpened));label(c,12,Items.BOOK,"Quests Completed",String.valueOf(q.completedCount(p.getUUID())));label(c,13,Items.NETHER_STAR,"Lucky Rewards",String.valueOf(x.luckyBlocks));label(c,14,Items.IRON_SWORD,"Bosses Defeated",String.valueOf(x.bossesDefeated));label(c,15,Items.CLOCK,"Playtime",formatTicks(x.playTicks));button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Collection Log");}
    public static void openAchievements(ServerPlayer p){long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();int[] goals={250,2500,12500,31250,62500};for(int i=0;i<goals.length;i++)label(c,10+i,goals[i]<=g?Items.LIME_DYE:Items.GRAY_DYE,"Break "+goals[i]+" OneBlocks",goals[i]<=g?"Completed":"Progress: "+g+" / "+goals[i]);label(c,16,Items.TOTEM_OF_UNDYING,"Rewards","Milestones grant cash, crates, titles, and rare items through progression rewards.");button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Achievements");}
    public static void openDailyChallenge(ServerPlayer p){int day=(int)LocalDate.now().toEpochDay();String[] names={"Break 500 OneBlocks","Earn $50,000","Open 3 crates","Complete a quest","Find a structure"};String challenge=names[Math.floorMod(day,names.length)];SimpleContainer c=new SimpleContainer(27);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,11,Items.WRITABLE_BOOK,"Today's Challenge",challenge);label(c,13,Items.GOLD_INGOT,"Reward","$25,000 and 1 rare crate");label(c,15,Items.CLOCK,"Resets","At the next server calendar day");button(c,a,22,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,3,"Daily Challenge");}
    public static void openArtifacts(ServerPlayer p){SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.RABBIT_FOOT,"Fortune Core","Rare artifact: improves lucky reward chance.");label(c,12,Items.GOLD_INGOT,"Merchant's Seal","Rare artifact: improves money rewards.");label(c,14,Items.IRON_SWORD,"Boss Sigil","Rare artifact: bonus boss rewards.");label(c,16,Items.NETHER_STAR,"Void Compass","Legendary artifact: improves structure loot.");label(c,22,Items.BOOK,"How to obtain","Legendary crates, weekly bosses, structures, and prestige milestones.");button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Artifacts");}
    public static void openMerchant(ServerPlayer p){SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.NAME_TAG,"Exclusive Title Token","$2,500,000");label(c,12,Items.SHULKER_SHELL,"Shulker Supply","$5,000,000");label(c,14,Items.NETHER_STAR,"Artifact Cache","$25,000,000");label(c,16,Items.VILLAGER_SPAWN_EGG,"Villager Contract","$50,000,000");label(c,22,Items.CLOCK,"Refresh","Merchant inventory rotates every 24 hours.");button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Traveling Merchant");}
    public static void openEvents(ServerPlayer p){var d=CommunitySavedData.get(p.serverLevel());SimpleContainer c=new SimpleContainer(27);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,11,Items.LIGHTNING_ROD,"Active Event",d.activeEvent());label(c,13,Items.CLOCK,"Time Remaining",d.eventEndsAt()>System.currentTimeMillis()?((d.eventEndsAt()-System.currentTimeMillis())/60000)+" minutes":"No active event");label(c,15,Items.NETHER_STAR,"Possible Events","Double Cash, Double XP, Lucky Hour, Treasure Rain, and Boss Rush.");button(c,a,22,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,3,"World Events");}
    public static void openRatings(ServerPlayer p){SimpleContainer c=new SimpleContainer(36);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();List<UUID> ids=new ArrayList<>(CommunitySavedData.get(p.serverLevel()).playerIds());ids.sort(Comparator.comparingDouble((UUID id)->CommunitySavedData.get(p.serverLevel()).rating(id)).reversed());int slot=10;for(UUID id:ids){if(slot>16)break;label(c,slot++,Items.PLAYER_HEAD,CommunitySavedData.get(p.serverLevel()).name(id),String.format(Locale.US,"%.1f / 5 stars",CommunitySavedData.get(p.serverLevel()).rating(id)));}label(c,22,Items.NAME_TAG,"Rate command","Use /soa rate <player> <1-5> while visiting.");button(c,a,31,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,4,"Island Ratings");}
    public static void openWeeklyBoss(ServerPlayer p){SimpleContainer c=new SimpleContainer(27);Map<Integer,Consumer<ServerPlayer>>a=new HashMap<>();label(c,11,Items.RAVAGER_SPAWN_EGG,"Weekly Factory Breaker","A server-wide boss for players in Endless Mode.");label(c,13,Items.NETHER_STAR,"Participation Rewards","Cash, crates, artifacts, cosmetics, and boss collection progress.");label(c,15,Items.CLOCK,"Admin summon","/soa admin weeklyboss");button(c,a,22,Items.BARRIER,"Back","Return to Adventure & Community.",ExpansionSystem::openHub);open(p,c,a,3,"Weekly Boss");}

    private static String formatTicks(long ticks){long seconds=Math.max(0,ticks)/20L;return (seconds/3600)+"h "+((seconds%3600)/60)+"m";}
    private static void open(ServerPlayer p,SimpleContainer c,Map<Integer,Consumer<ServerPlayer>>a,int rows,String title){p.openMenu(new SimpleMenuProvider((id,inv,pl)->new ActionMenu(rows,id,inv,c,a),Component.literal(title)));}
    private static void button(SimpleContainer c,Map<Integer,Consumer<ServerPlayer>>a,int slot,Item item,String name,String lore,Consumer<ServerPlayer>action){ItemStack s=new ItemStack(item);s.set(DataComponents.CUSTOM_NAME,Component.literal(name).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));s.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY),Component.literal("Click").withStyle(ChatFormatting.GREEN))));c.setItem(slot,s);a.put(slot,action);}
    private static void label(SimpleContainer c,int slot,Item item,String name,String lore){ItemStack s=new ItemStack(item);s.set(DataComponents.CUSTOM_NAME,Component.literal(name).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));s.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY))));c.setItem(slot,s);}
}
