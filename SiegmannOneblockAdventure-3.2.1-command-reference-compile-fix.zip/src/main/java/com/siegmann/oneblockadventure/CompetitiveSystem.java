package com.siegmann.oneblockadventure;
import com.mojang.brigadier.arguments.IntegerArgumentType;import net.minecraft.ChatFormatting;import net.minecraft.commands.Commands;import net.minecraft.core.BlockPos;import net.minecraft.network.chat.Component;import net.minecraft.server.MinecraftServer;import net.minecraft.server.level.ServerLevel;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.entity.EntityType;import net.minecraft.world.entity.boss.enderdragon.EnderDragon;import net.minecraft.world.level.Level;import net.minecraft.world.level.block.Blocks;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.neoforge.event.RegisterCommandsEvent;import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;import net.neoforged.neoforge.event.tick.ServerTickEvent;import java.util.*;
@EventBusSubscriber(modid=SiegmannOneblockAdventure.MOD_ID)
public final class CompetitiveSystem{
 private static final long PERIOD=72L*60L*60L*1000L,WARNING=10L*60L*1000L,DURATION=45L*60L*1000L;private static long lastTick;
 private CompetitiveSystem(){}
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){
  var d=e.getDispatcher();
  d.register(Commands.literal("dragoncup")
   .executes(c->status(c.getSource().getPlayerOrException()))
   .then(Commands.literal("register").executes(c->register(c.getSource().getPlayerOrException())))
   .then(Commands.literal("leave").executes(c->unregister(c.getSource().getPlayerOrException()))));
  d.register(Commands.literal("pvp")
   .executes(c->{CompetitiveMenu.open(c.getSource().getPlayerOrException());return 1;})
   .then(Commands.literal("join").executes(c->joinPvp(c.getSource().getPlayerOrException())))
   .then(Commands.literal("leave").executes(c->leavePvp(c.getSource().getPlayerOrException())))
   .then(Commands.literal("leaderboard").executes(c->leaderboard(c.getSource().getPlayerOrException()))));
  d.register(Commands.literal("soacompetitive").requires(source->source.hasPermission(2))
   .then(Commands.literal("arena")
    .then(Commands.literal("generate").executes(c->generateArena(c.getSource().getPlayerOrException()))))
   .then(Commands.literal("dragon")
    .then(Commands.literal("start").executes(c->{startDragon(c.getSource().getServer());return 1;}))
    .then(Commands.literal("stop").executes(c->{finishDragon(c.getSource().getServer(),"stopped by an administrator");return 1;}))
    .then(Commands.literal("schedulehours")
     .then(Commands.argument("hours",IntegerArgumentType.integer(1,10000))
      .executes(c->{
       var data=CompetitiveSavedData.get(c.getSource().getServer().overworld());
       data.nextDragonEvent=System.currentTimeMillis()+IntegerArgumentType.getInteger(c,"hours")*3600000L;
       data.dirty();
       return 1;
      })))));
 }
 @SubscribeEvent public static void tick(ServerTickEvent.Post e){long now=System.currentTimeMillis();if(now-lastTick<1000)return;lastTick=now;MinecraftServer s=e.getServer();var d=CompetitiveSavedData.get(s.overworld());if(d.nextDragonEvent<=0){d.nextDragonEvent=now+PERIOD;d.dirty();}long left=d.nextDragonEvent-now;if(!d.dragonActive&&left<=WARNING&&left>WARNING-2000)broadcast(s,"Dragon Cup begins in 10 minutes. Phase 150+ players: /dragoncup register");if(!d.dragonActive&&left<=0)startDragon(s);if(d.dragonActive&&now>=d.dragonEnd)finishDragon(s,"time expired");}
 private static int register(ServerPlayer p){long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);if(CreateProgression.phaseNumber(g)<150){p.sendSystemMessage(Component.literal("Phase 150 is required."));return 0;}var d=CompetitiveSavedData.get(p.serverLevel());if(d.dragonRegistered.size()>=5&&!d.dragonRegistered.contains(p.getUUID())){p.sendSystemMessage(Component.literal("The five competitor slots are full."));return 0;}d.dragonRegistered.add(p.getUUID());d.dirty();p.sendSystemMessage(Component.literal("Registered for the next Dragon Cup."));return 1;}
 private static int unregister(ServerPlayer p){var d=CompetitiveSavedData.get(p.serverLevel());boolean r=d.dragonRegistered.remove(p.getUUID());d.dirty();return r?1:0;}
 private static int status(ServerPlayer p){var d=CompetitiveSavedData.get(p.serverLevel());long mins=Math.max(0,(d.nextDragonEvent-System.currentTimeMillis())/60000L);p.sendSystemMessage(Component.literal("Dragon Cup: "+(d.dragonActive?"ACTIVE":mins+" minutes")+" | registered "+d.dragonRegistered.size()+"/5"));return 1;}
 private static void startDragon(MinecraftServer s){var d=CompetitiveSavedData.get(s.overworld());if(d.dragonActive)return;ServerLevel end=s.getLevel(Level.END);if(end==null){broadcast(s,"Dragon Cup could not start: End dimension unavailable.");d.nextDragonEvent=System.currentTimeMillis()+PERIOD;d.dirty();return;}d.dragonActive=true;d.dragonEnd=System.currentTimeMillis()+DURATION;d.nextDragonEvent=System.currentTimeMillis()+PERIOD;List<UUID> players=new ArrayList<>(d.dragonRegistered);while(players.size()>5)players.remove(players.size()-1);for(UUID id:players){ServerPlayer p=s.getPlayerList().getPlayer(id);if(p!=null)p.teleportTo(end,100.5,50,0.5,p.getYRot(),p.getXRot());}EnderDragon dragon=EntityType.ENDER_DRAGON.create(end);if(dragon!=null){dragon.moveTo(0,80,0,0,0);end.addFreshEntity(dragon);}broadcast(s,"Dragon Cup started with "+players.size()+" competitor(s).");d.dirty();}
 private static void finishDragon(MinecraftServer s,String reason){var d=CompetitiveSavedData.get(s.overworld());if(!d.dragonActive)return;for(UUID id:d.dragonRegistered){ServerPlayer p=s.getPlayerList().getPlayer(id);if(p!=null)MultiOneCommands.tp(p.createCommandSourceStack(),p);}d.dragonRegistered.clear();d.dragonActive=false;d.dragonEnd=0;d.dirty();broadcast(s,"Dragon Cup ended: "+reason+". Competitors returned to their islands.");}
 @SubscribeEvent public static void death(LivingDeathEvent e){if(e.getEntity() instanceof EnderDragon dragon){MinecraftServer s=dragon.getServer();if(s!=null&&CompetitiveSavedData.get(s.overworld()).dragonActive)finishDragon(s,"the Ender Dragon was defeated");}if(e.getEntity() instanceof ServerPlayer victim&&e.getSource().getEntity() instanceof ServerPlayer killer){var d=CompetitiveSavedData.get(victim.serverLevel());if(d.arenaCenter!=null&&victim.blockPosition().closerThan(d.arenaCenter,35)){d.pvpDeaths.merge(victim.getUUID(),1L,Long::sum);d.pvpKills.merge(killer.getUUID(),1L,Long::sum);d.dirty();AdventureSystem.addCash(killer,250);killer.sendSystemMessage(Component.literal("PvP kill: +$250").withStyle(ChatFormatting.GREEN));}}}
 private static int generateArena(ServerPlayer a){ServerLevel l=a.serverLevel();BlockPos c=a.blockPosition();for(int x=-15;x<=15;x++)for(int z=-15;z<=15;z++){double dist=Math.sqrt(x*x+z*z);l.setBlockAndUpdate(c.offset(x,-1,z),dist>13?Blocks.STONE_BRICKS.defaultBlockState():Blocks.SMOOTH_STONE.defaultBlockState());if(dist>13&&dist<15)for(int y=0;y<4;y++)l.setBlockAndUpdate(c.offset(x,y,z),Blocks.IRON_BARS.defaultBlockState());}var d=CompetitiveSavedData.get(l);d.arenaCenter=c;d.dirty();a.sendSystemMessage(Component.literal("PvP arena generated at "+c.toShortString()));return 1;}
 private static int joinPvp(ServerPlayer p){var d=CompetitiveSavedData.get(p.serverLevel());if(d.arenaCenter==null){p.sendSystemMessage(Component.literal("PvP arena has not been generated."));return 0;}p.teleportTo(p.serverLevel(),d.arenaCenter.getX()+.5,d.arenaCenter.getY()+1,d.arenaCenter.getZ()+.5,p.getYRot(),p.getXRot());return 1;}
 private static int leavePvp(ServerPlayer p){return MultiOneCommands.tp(p.createCommandSourceStack(),p);}private static int leaderboard(ServerPlayer p){var d=CompetitiveSavedData.get(p.serverLevel());p.sendSystemMessage(Component.literal("PvP leaderboard").withStyle(ChatFormatting.GOLD));d.pvpKills.entrySet().stream().sorted(Map.Entry.<UUID,Long>comparingByValue().reversed()).limit(10).forEach(x->p.sendSystemMessage(Component.literal(p.getServer().getProfileCache().get(x.getKey()).map(y->y.getName()).orElse(x.getKey().toString().substring(0,8))+" - "+x.getValue()+" kills")));return 1;}private static void broadcast(MinecraftServer s,String m){s.getPlayerList().broadcastSystemMessage(Component.literal(m).withStyle(ChatFormatting.LIGHT_PURPLE,ChatFormatting.BOLD),false);}
}
