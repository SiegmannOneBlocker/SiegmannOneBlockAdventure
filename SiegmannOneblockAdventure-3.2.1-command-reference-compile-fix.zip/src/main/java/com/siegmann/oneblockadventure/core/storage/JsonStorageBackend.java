package com.siegmann.oneblockadventure.core.storage;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Optional;

public final class JsonStorageBackend implements StorageBackend {
    private final Path root;
    public JsonStorageBackend(Path root) { this.root = root.toAbsolutePath().normalize(); }
    public String id() { return "json"; }
    public void initialize() throws IOException { Files.createDirectories(root); }
    public Optional<String> read(String namespace, String key) throws IOException { Path p = safe(namespace, key); return Files.exists(p) ? Optional.of(Files.readString(p, StandardCharsets.UTF_8)) : Optional.empty(); }
    public void write(String namespace, String key, String json) throws IOException { Path p = safe(namespace, key); Files.createDirectories(p.getParent()); Path temp = p.resolveSibling(p.getFileName()+".tmp"); Files.writeString(temp, json, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING); try { Files.move(temp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); } catch (AtomicMoveNotSupportedException ex) { Files.move(temp, p, StandardCopyOption.REPLACE_EXISTING); } }
    public void delete(String namespace, String key) throws IOException { Files.deleteIfExists(safe(namespace, key)); }
    private Path safe(String namespace, String key) { String cleanNs = namespace.replaceAll("[^a-zA-Z0-9._-]", "_"); String cleanKey = key.replaceAll("[^a-zA-Z0-9._-]", "_"); Path p = root.resolve(cleanNs).resolve(cleanKey + ".json").normalize(); if (!p.startsWith(root)) throw new IllegalArgumentException("Unsafe storage path"); return p; }
}
