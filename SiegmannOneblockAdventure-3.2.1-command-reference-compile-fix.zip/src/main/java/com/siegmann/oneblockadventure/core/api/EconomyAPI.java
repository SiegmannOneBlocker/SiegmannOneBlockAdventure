package com.siegmann.oneblockadventure.core.api;

import com.siegmann.oneblockadventure.EconomySavedData;
import com.siegmann.oneblockadventure.core.event.GameplayEvents;
import com.siegmann.oneblockadventure.core.event.SoaEventBus;
import net.minecraft.server.level.ServerLevel;
import java.util.UUID;

public final class EconomyAPI {
    private EconomyAPI() {}
    public static long balance(ServerLevel level, UUID playerId) { return EconomySavedData.get(level).balance(playerId); }
    public static void deposit(ServerLevel level, UUID playerId, long amount, String reason) { if (amount <= 0) return; EconomySavedData.get(level).add(playerId, amount); SoaEventBus.post(new GameplayEvents.EconomyTransaction(playerId, amount, reason)); }
    public static boolean withdraw(ServerLevel level, UUID playerId, long amount, String reason) { if (amount < 0) return false; boolean ok = EconomySavedData.get(level).take(playerId, amount); if (ok) SoaEventBus.post(new GameplayEvents.EconomyTransaction(playerId, -amount, reason)); return ok; }
}
