package com.siegmann.oneblockadventure.core.module;

import com.siegmann.oneblockadventure.core.storage.StorageManager;import com.siegmann.oneblockadventure.core.task.AsyncTaskService;
public final class CoreModules {private static boolean done;private CoreModules(){}public static synchronized void registerAll(){if(done)return;done=true;ModuleRegistry.register(new SoaModule(){public String id(){return "storage";}public int order(){return 0;}public void initialize(){StorageManager.initialize();}public void serverStopping(net.minecraft.server.MinecraftServer s){StorageManager.shutdown();}});ModuleRegistry.register(new SoaModule(){public String id(){return "async";}public int order(){return 10;}public void initialize(){AsyncTaskService.start();}public void serverStopping(net.minecraft.server.MinecraftServer s){AsyncTaskService.stop();}});for(String id:new String[]{"economy","shops","islands","create","adventure","pvp","dragon_cup","quests","structures","admin","api"})ModuleRegistry.register(new NamedModule(id));}
private record NamedModule(String id) implements SoaModule{}
}
