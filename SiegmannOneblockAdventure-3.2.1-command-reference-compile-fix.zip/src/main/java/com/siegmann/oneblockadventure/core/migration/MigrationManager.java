package com.siegmann.oneblockadventure.core.migration;

import com.google.gson.*;import net.neoforged.fml.loading.FMLPaths;import java.io.*;import java.nio.charset.StandardCharsets;import java.nio.file.*;
public final class MigrationManager {
 public static final int CURRENT_SCHEMA=3; private MigrationManager(){}
 public static Result migrate(){Path dir=FMLPaths.CONFIGDIR.get().resolve("siegmann_oneblock_adventure");Path file=dir.resolve("schema.json");try{Files.createDirectories(dir);int old=0;if(Files.exists(file)){JsonObject o=JsonParser.parseString(Files.readString(file)).getAsJsonObject();old=o.has("schema")?o.get("schema").getAsInt():0;}if(old>CURRENT_SCHEMA)return new Result(false,old,"Configuration is newer than this mod");JsonObject out=new JsonObject();out.addProperty("schema",CURRENT_SCHEMA);out.addProperty("lastMigrationEpochMillis",System.currentTimeMillis());Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(out),StandardCharsets.UTF_8);return new Result(old!=CURRENT_SCHEMA,old,"Migrated schema "+old+" -> "+CURRENT_SCHEMA);}catch(Exception ex){return new Result(false,-1,"Migration failed: "+ex.getMessage());}}
 public record Result(boolean changed,int previousSchema,String message){}
}
