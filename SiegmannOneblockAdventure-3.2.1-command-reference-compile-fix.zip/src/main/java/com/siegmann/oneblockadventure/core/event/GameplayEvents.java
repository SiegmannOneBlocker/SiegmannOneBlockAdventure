package com.siegmann.oneblockadventure.core.event;

import java.util.UUID;

public final class GameplayEvents {
    private GameplayEvents() {}
    public record PlayerBreakOneBlock(UUID playerId, long generatedBefore, long generatedAfter) implements SoaEvent {}
    public record IslandCreated(UUID ownerId) implements SoaEvent {}
    public record QuestCompleted(UUID playerId, String questId) implements SoaEvent {}
    public record BossDefeated(UUID playerId, String bossId) implements SoaEvent {}
    public record EconomyTransaction(UUID playerId, long amount, String reason) implements SoaEvent {}
    public record AuctionPurchased(UUID buyerId, UUID sellerId, long price) implements SoaEvent {}
    public record DragonCupStarted(long startedAtEpochMillis) implements SoaEvent {}
}
