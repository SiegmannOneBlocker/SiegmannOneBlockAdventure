package com.siegmann.oneblockadventure.core.module;

import net.minecraft.server.MinecraftServer;

/** Independent lifecycle unit for a SiegmannOneblockAdventure subsystem. */
public interface SoaModule {
    String id();
    default int order() { return 100; }
    default boolean enabled() { return true; }
    default void initialize() {}
    default void serverStarted(MinecraftServer server) {}
    default void serverStopping(MinecraftServer server) {}
}
