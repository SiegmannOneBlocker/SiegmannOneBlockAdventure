package com.siegmann.oneblockadventure.core.storage;

import com.siegmann.oneblockadventure.SiegmannOneblockAdventure;
import net.neoforged.fml.loading.FMLPaths;
import java.nio.file.Path;

public final class StorageManager {
    private static StorageBackend backend;
    private StorageManager() {}
    public static synchronized void initialize() { if (backend != null) return; Path root=FMLPaths.CONFIGDIR.get().resolve("siegmann_oneblock_adventure").resolve("data"); backend=new JsonStorageBackend(root); try { backend.initialize(); } catch(Exception ex){ backend=null; throw new IllegalStateException("Unable to initialize SOA storage", ex); } SiegmannOneblockAdventure.LOGGER.info("SOA storage backend: {}", backend.id()); }
    public static StorageBackend backend() { if(backend==null) initialize(); return backend; }
    public static synchronized void shutdown() { if(backend==null) return; try { backend.close(); } catch(Exception ex){ SiegmannOneblockAdventure.LOGGER.error("Failed to close SOA storage",ex); } finally { backend=null; } }
}
