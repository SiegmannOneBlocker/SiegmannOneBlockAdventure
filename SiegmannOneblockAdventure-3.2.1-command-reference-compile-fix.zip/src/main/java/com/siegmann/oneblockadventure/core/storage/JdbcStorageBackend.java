package com.siegmann.oneblockadventure.core.storage;

import java.sql.*;
import java.util.Optional;

/** JDBC backend usable with SQLite, MySQL, or MariaDB when the corresponding driver is installed. */
public final class JdbcStorageBackend implements StorageBackend {
    private final String id, url, user, password; private Connection connection;
    public JdbcStorageBackend(String id, String url, String user, String password) { this.id=id; this.url=url; this.user=user; this.password=password; }
    public String id() { return id; }
    public void initialize() throws SQLException { connection = DriverManager.getConnection(url, user, password); try (Statement s=connection.createStatement()) { s.executeUpdate("CREATE TABLE IF NOT EXISTS soa_data (namespace VARCHAR(128) NOT NULL, data_key VARCHAR(191) NOT NULL, json_data TEXT NOT NULL, PRIMARY KEY(namespace, data_key))"); } }
    public Optional<String> read(String namespace, String key) throws SQLException { try (PreparedStatement p=connection.prepareStatement("SELECT json_data FROM soa_data WHERE namespace=? AND data_key=?")) { p.setString(1,namespace);p.setString(2,key);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(r.getString(1)):Optional.empty();}} }
    public void write(String namespace, String key, String json) throws SQLException { delete(namespace,key);try(PreparedStatement p=connection.prepareStatement("INSERT INTO soa_data(namespace,data_key,json_data) VALUES(?,?,?)")){p.setString(1,namespace);p.setString(2,key);p.setString(3,json);p.executeUpdate();} }
    public void delete(String namespace, String key) throws SQLException { try(PreparedStatement p=connection.prepareStatement("DELETE FROM soa_data WHERE namespace=? AND data_key=?")){p.setString(1,namespace);p.setString(2,key);p.executeUpdate();} }
    public void close() throws SQLException { if(connection!=null) connection.close(); }
}
