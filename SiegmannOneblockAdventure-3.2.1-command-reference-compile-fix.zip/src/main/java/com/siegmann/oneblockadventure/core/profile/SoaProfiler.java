package com.siegmann.oneblockadventure.core.profile;

import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public final class SoaProfiler {
 private record Metric(LongAdder calls,LongAdder nanos){}
 private static final Map<String,Metric> M=new ConcurrentHashMap<>(); private SoaProfiler(){}
 public static Scope start(String name){return new Scope(name,System.nanoTime());}
 public static List<String> report(){return M.entrySet().stream().sorted((a,b)->Long.compare(b.getValue().nanos.sum(),a.getValue().nanos.sum())).map(e->{long c=e.getValue().calls.sum(),n=e.getValue().nanos.sum();return e.getKey()+": calls="+c+", total="+String.format(Locale.ROOT,"%.3f",n/1_000_000.0)+"ms, avg="+String.format(Locale.ROOT,"%.3f",c==0?0:(n/1_000_000.0/c))+"ms";}).toList();}
 public static void reset(){M.clear();}
 public static final class Scope implements AutoCloseable{private final String n;private final long s;private boolean closed;private Scope(String n,long s){this.n=n;this.s=s;}public void close(){if(closed)return;closed=true;Metric m=M.computeIfAbsent(n,k->new Metric(new LongAdder(),new LongAdder()));m.calls.increment();m.nanos.add(System.nanoTime()-s);}}
}
