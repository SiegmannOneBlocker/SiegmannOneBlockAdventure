package com.siegmann.oneblockadventure.core.event;
public interface SoaEvent {}
