package com.siegmann.oneblockadventure.core;
import com.siegmann.oneblockadventure.core.module.*;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.neoforge.event.server.*;
@EventBusSubscriber(modid="siegmann_oneblock_adventure") public final class CoreLifecycle {private CoreLifecycle(){}@SubscribeEvent public static void started(ServerStartedEvent e){ModuleRegistry.serverStarted(e.getServer());}@SubscribeEvent public static void stopping(ServerStoppingEvent e){ModuleRegistry.serverStopping(e.getServer());}}
