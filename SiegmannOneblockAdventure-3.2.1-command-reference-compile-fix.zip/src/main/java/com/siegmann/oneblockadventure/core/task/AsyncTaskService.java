package com.siegmann.oneblockadventure.core.task;

import com.siegmann.oneblockadventure.SiegmannOneblockAdventure;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class AsyncTaskService {
    private static final AtomicInteger IDS=new AtomicInteger();
    private static ExecutorService executor;
    private AsyncTaskService() {}
    public static synchronized void start(){ if(executor!=null&&!executor.isShutdown())return; executor=Executors.newFixedThreadPool(2,r->{Thread t=new Thread(r,"SOA-Worker-"+IDS.incrementAndGet());t.setDaemon(true);return t;}); }
    public static CompletableFuture<Void> run(Runnable task){ start(); return CompletableFuture.runAsync(task,executor).exceptionally(ex->{SiegmannOneblockAdventure.LOGGER.error("Async SOA task failed",ex);return null;}); }
    public static synchronized void stop(){ if(executor==null)return; executor.shutdown();try{if(!executor.awaitTermination(5,TimeUnit.SECONDS))executor.shutdownNow();}catch(InterruptedException ex){Thread.currentThread().interrupt();executor.shutdownNow();}finally{executor=null;} }
    public static int queuedTasks(){ return executor instanceof ThreadPoolExecutor p ? p.getQueue().size() : 0; }
}
