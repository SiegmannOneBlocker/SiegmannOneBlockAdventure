package com.siegmann.oneblockadventure.core.module;

import com.siegmann.oneblockadventure.SiegmannOneblockAdventure;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ModuleRegistry {
    private static final Map<String, SoaModule> MODULES = new ConcurrentHashMap<>();
    private ModuleRegistry() {}
    public static void register(SoaModule module) {
        Objects.requireNonNull(module, "module");
        if (MODULES.putIfAbsent(module.id(), module) != null) throw new IllegalStateException("Duplicate SOA module: " + module.id());
    }
    public static List<SoaModule> modules() { return MODULES.values().stream().sorted(Comparator.comparingInt(SoaModule::order).thenComparing(SoaModule::id)).toList(); }
    public static void initializeAll() { for (SoaModule module : modules()) if (module.enabled()) safely(module.id(), module::initialize); }
    public static void serverStarted(MinecraftServer server) { for (SoaModule module : modules()) if (module.enabled()) safely(module.id(), () -> module.serverStarted(server)); }
    public static void serverStopping(MinecraftServer server) { List<SoaModule> copy = new ArrayList<>(modules()); Collections.reverse(copy); for (SoaModule module : copy) if (module.enabled()) safely(module.id(), () -> module.serverStopping(server)); }
    private static void safely(String id, Runnable action) { try { action.run(); } catch (RuntimeException ex) { SiegmannOneblockAdventure.LOGGER.error("SOA module {} failed", id, ex); } }
}
