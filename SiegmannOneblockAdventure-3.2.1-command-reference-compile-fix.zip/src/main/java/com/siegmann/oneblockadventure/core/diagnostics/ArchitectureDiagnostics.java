package com.siegmann.oneblockadventure.core.diagnostics;

import com.siegmann.oneblockadventure.*;import com.siegmann.oneblockadventure.core.event.SoaEventBus;import com.siegmann.oneblockadventure.core.module.ModuleRegistry;import com.siegmann.oneblockadventure.core.storage.StorageManager;import com.siegmann.oneblockadventure.core.task.AsyncTaskService;import net.minecraft.server.MinecraftServer;import java.util.*;
public final class ArchitectureDiagnostics {
 private ArchitectureDiagnostics(){}
 public static List<String> run(MinecraftServer server){List<String> r=new ArrayList<>();r.add("Modules: "+ModuleRegistry.modules().size());r.add("Internal event listeners: "+SoaEventBus.listenerCount());r.add("Storage: "+StorageManager.backend().id());r.add("Async queue: "+AsyncTaskService.queuedTasks());r.add("Loaded worlds: "+server.getAllLevels().spliterator().getExactSizeIfKnown());r.add("Islands: "+MultiOneSavedData.get(server.overworld()).all().size());r.add("Config generation: "+DataDrivenCore.snapshot().documents().size());r.add("Java: "+System.getProperty("java.version"));r.add("Memory MB used/max: "+((Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1048576)+"/"+(Runtime.getRuntime().maxMemory()/1048576));return r;}
}
