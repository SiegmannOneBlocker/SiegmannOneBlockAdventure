package com.siegmann.oneblockadventure.core.event;

import com.siegmann.oneblockadventure.SiegmannOneblockAdventure;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

public final class SoaEventBus {
    private static final Map<Class<?>, CopyOnWriteArrayList<Consumer<?>>> LISTENERS = new ConcurrentHashMap<>();
    private SoaEventBus() {}
    public static <T extends SoaEvent> AutoCloseable subscribe(Class<T> type, Consumer<T> listener) {
        LISTENERS.computeIfAbsent(type, ignored -> new CopyOnWriteArrayList<>()).add(listener);
        return () -> LISTENERS.getOrDefault(type, new CopyOnWriteArrayList<>()).remove(listener);
    }
    @SuppressWarnings("unchecked") public static <T extends SoaEvent> T post(T event) {
        for (Consumer<?> raw : LISTENERS.getOrDefault(event.getClass(), new CopyOnWriteArrayList<>())) {
            try { ((Consumer<T>) raw).accept(event); } catch (RuntimeException ex) { SiegmannOneblockAdventure.LOGGER.error("SOA event listener failed for {}", event.getClass().getSimpleName(), ex); }
        }
        return event;
    }
    public static int listenerCount() { return LISTENERS.values().stream().mapToInt(List::size).sum(); }
}
