package com.siegmann.oneblockadventure.core.storage;

import java.util.Optional;

public interface StorageBackend extends AutoCloseable {
    String id();
    void initialize() throws Exception;
    Optional<String> read(String namespace, String key) throws Exception;
    void write(String namespace, String key, String json) throws Exception;
    void delete(String namespace, String key) throws Exception;
    default void flush() throws Exception {}
    @Override default void close() throws Exception { flush(); }
}
