package com.siegmann.oneblockadventure.core.api;

import com.siegmann.oneblockadventure.MultiOneSavedData;
import net.minecraft.server.level.ServerLevel;
import java.util.*;

public final class IslandAPI {
    private IslandAPI() {}
    public static Optional<MultiOneSavedData.Island> getIsland(ServerLevel level, UUID owner) { return MultiOneSavedData.get(level).byOwner(owner); }
    public static Collection<MultiOneSavedData.Island> allIslands(ServerLevel level) { return MultiOneSavedData.get(level).all(); }
    public static boolean removeIsland(ServerLevel level, UUID owner) { return MultiOneSavedData.get(level).remove(owner); }
}
