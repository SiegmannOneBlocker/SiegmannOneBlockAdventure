package com.siegmann.oneblockadventure;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

/** Persistent data for expansion systems added in 2.0.0. */
public final class CommunitySavedData extends SavedData {
    private static final String NAME = "siegmann_oneblock_community";
    private static final Factory<CommunitySavedData> FACTORY = new Factory<>(CommunitySavedData::new, CommunitySavedData::load, null);

    public record StructureSite(String type, BlockPos pos) {}
    public static final class Profile {
        String name = "Unknown";
        int ratingTotal;
        int ratingCount;
        int structuresFound;
        int achievementsClaimed;
        int dailyChallengeDay = Integer.MIN_VALUE;
        int dailyChallengeProgress;
        boolean dailyChallengeClaimed;
        String equippedArtifact = "none";
        final Set<String> discovered = new HashSet<>();
        final Set<String> achievements = new HashSet<>();
    }

    private final Map<UUID, Profile> profiles = new HashMap<>();
    private final List<StructureSite> structures = new ArrayList<>();
    private String activeEvent = "None";
    private long eventEndsAt;
    private long merchantRefreshAt;

    public static CommunitySavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }
    public Profile profile(UUID id) { return profiles.computeIfAbsent(id, ignored -> new Profile()); }
    public Set<UUID> playerIds() { return Collections.unmodifiableSet(profiles.keySet()); }
    public boolean hasProfile(UUID id) { return profiles.containsKey(id); }
    public List<StructureSite> structures() { return Collections.unmodifiableList(structures); }
    public void remember(UUID id, String name) { profile(id).name = name; setDirty(); }
    public String name(UUID id) { return profile(id).name; }
    public void addStructure(String type, BlockPos pos) { structures.add(new StructureSite(type, pos)); setDirty(); }
    public void discover(UUID id, String key) { if (profile(id).discovered.add(key)) setDirty(); }
    public void foundStructure(UUID id) { profile(id).structuresFound++; setDirty(); }
    public void rate(UUID target, int stars) { Profile p=profile(target); p.ratingTotal+=stars; p.ratingCount++; setDirty(); }
    public double rating(UUID id) { Profile p=profile(id); return p.ratingCount==0?0D:(double)p.ratingTotal/p.ratingCount; }
    public void clearPlayer(UUID id) { profiles.remove(id); setDirty(); }
    public String activeEvent() { return activeEvent; }
    public long eventEndsAt() { return eventEndsAt; }
    public void setEvent(String event,long endsAt){activeEvent=event;eventEndsAt=endsAt;setDirty();}
    public long merchantRefreshAt(){return merchantRefreshAt;}
    public void setMerchantRefreshAt(long value){merchantRefreshAt=value;setDirty();}

    private static CommunitySavedData load(CompoundTag tag, HolderLookup.Provider provider) {
        CommunitySavedData data=new CommunitySavedData();
        data.activeEvent=tag.getString("ActiveEvent"); if(data.activeEvent.isBlank())data.activeEvent="None";
        data.eventEndsAt=tag.getLong("EventEndsAt"); data.merchantRefreshAt=tag.getLong("MerchantRefreshAt");
        ListTag ps=tag.getList("Profiles",Tag.TAG_COMPOUND);
        for(int i=0;i<ps.size();i++){CompoundTag e=ps.getCompound(i);if(!e.hasUUID("Player"))continue;Profile p=new Profile();p.name=e.getString("Name");p.ratingTotal=e.getInt("RatingTotal");p.ratingCount=e.getInt("RatingCount");p.structuresFound=e.getInt("StructuresFound");p.achievementsClaimed=e.getInt("AchievementsClaimed");p.dailyChallengeDay=e.getInt("ChallengeDay");p.dailyChallengeProgress=e.getInt("ChallengeProgress");p.dailyChallengeClaimed=e.getBoolean("ChallengeClaimed");p.equippedArtifact=e.getString("Artifact");ListTag d=e.getList("Discovered",Tag.TAG_STRING);for(int j=0;j<d.size();j++)p.discovered.add(d.getString(j));ListTag a=e.getList("Achievements",Tag.TAG_STRING);for(int j=0;j<a.size();j++)p.achievements.add(a.getString(j));data.profiles.put(e.getUUID("Player"),p);}
        ListTag ss=tag.getList("Structures",Tag.TAG_COMPOUND);for(int i=0;i<ss.size();i++){CompoundTag e=ss.getCompound(i);data.structures.add(new StructureSite(e.getString("Type"),new BlockPos(e.getInt("X"),e.getInt("Y"),e.getInt("Z"))));}
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putString("ActiveEvent",activeEvent);tag.putLong("EventEndsAt",eventEndsAt);tag.putLong("MerchantRefreshAt",merchantRefreshAt);
        ListTag ps=new ListTag();profiles.forEach((id,p)->{CompoundTag e=new CompoundTag();e.putUUID("Player",id);e.putString("Name",p.name);e.putInt("RatingTotal",p.ratingTotal);e.putInt("RatingCount",p.ratingCount);e.putInt("StructuresFound",p.structuresFound);e.putInt("AchievementsClaimed",p.achievementsClaimed);e.putInt("ChallengeDay",p.dailyChallengeDay);e.putInt("ChallengeProgress",p.dailyChallengeProgress);e.putBoolean("ChallengeClaimed",p.dailyChallengeClaimed);e.putString("Artifact",p.equippedArtifact);ListTag d=new ListTag();p.discovered.stream().sorted().forEach(v->d.add(net.minecraft.nbt.StringTag.valueOf(v)));e.put("Discovered",d);ListTag a=new ListTag();p.achievements.stream().sorted().forEach(v->a.add(net.minecraft.nbt.StringTag.valueOf(v)));e.put("Achievements",a);ps.add(e);});tag.put("Profiles",ps);
        ListTag ss=new ListTag();for(StructureSite s:structures){CompoundTag e=new CompoundTag();e.putString("Type",s.type());e.putInt("X",s.pos().getX());e.putInt("Y",s.pos().getY());e.putInt("Z",s.pos().getZ());ss.add(e);}tag.put("Structures",ss);return tag;
    }
}
