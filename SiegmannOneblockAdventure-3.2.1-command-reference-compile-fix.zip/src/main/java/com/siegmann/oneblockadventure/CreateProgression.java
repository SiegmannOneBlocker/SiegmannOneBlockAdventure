package com.siegmann.oneblockadventure;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** 250 finite phases followed by an endless, difficulty-tiered endgame. */
public final class CreateProgression {
    public static final long BLOCKS_PER_PHASE = 250L;
    public static final int STORY_PHASES = 250;
    public static final long ENDGAME_START = BLOCKS_PER_PHASE * STORY_PHASES;

    public record WeightedBlock(String id, int weight) {}
    public record Reward(String itemId, int count, String label) {}
    private record RandomReward(String itemId, int minCount, int maxCount, int weight, String label) {}
    public record Phase(int number, String name, String subtitle, List<WeightedBlock> blocks, List<Reward> rewards, int cashReward) {}

    private record Era(String name, String subtitle, List<WeightedBlock> blocks) {}
    private static WeightedBlock b(String id, int weight) { return new WeightedBlock(id, weight); }
    private static Reward r(String id, int count, String label) { return new Reward(id, count, label); }
    private static RandomReward rr(String id, int min, int max, int weight, String label) { return new RandomReward(id, min, max, weight, label); }

    /* Each era lasts ten phases. Pools intentionally exclude bedrock, barriers, portals,
       command blocks, liquids, budding amethyst, reinforced deepslate and other soft-lock blocks. */
    private static final List<Era> ERAS = List.of(
        new Era("New Beginnings", "Wood, soil and safe starter materials.", List.of(b("minecraft:grass_block",20),b("minecraft:dirt",22),b("minecraft:stone",18),b("minecraft:oak_log",12),b("minecraft:oak_leaves",8),b("minecraft:gravel",8),b("minecraft:clay",6),b("minecraft:coal_ore",4),b("minecraft:moss_block",2),b("minecraft:hay_block",8),b("minecraft:pumpkin",4),b("minecraft:melon",4))),
        new Era("Stoneworker", "Stone varieties and reliable fuel.", List.of(b("minecraft:stone",22),b("minecraft:cobblestone",15),b("minecraft:andesite",14),b("minecraft:diorite",8),b("minecraft:granite",8),b("minecraft:coal_ore",12),b("minecraft:oak_log",8),b("minecraft:gravel",8),b("minecraft:calcite",5))),
        new Era("First Metals", "Iron and copper establish your workshop.", List.of(b("minecraft:stone",18),b("minecraft:iron_ore",14),b("minecraft:copper_ore",14),b("minecraft:coal_ore",12),b("minecraft:andesite",14),b("minecraft:tuff",10),b("minecraft:gravel",8),b("minecraft:oak_log",6),b("minecraft:clay",4))),
        new Era("Zinc Discovery", "Create's core alloy is now obtainable.", List.of(b("minecraft:andesite",20),b("create:zinc_ore",15),b("minecraft:iron_ore",13),b("minecraft:copper_ore",13),b("minecraft:coal_ore",9),b("minecraft:tuff",10),b("minecraft:deepslate",8),b("minecraft:redstone_ore",5),b("minecraft:oak_log",7))),
        new Era("Andesite Engineering", "Shafts, cogwheels and water power.", List.of(b("minecraft:andesite",19),b("create:zinc_ore",13),b("minecraft:iron_ore",13),b("minecraft:copper_ore",13),b("minecraft:redstone_ore",9),b("minecraft:dried_kelp_block",7),b("minecraft:clay",5),b("create:andesite_casing",4),b("minecraft:deepslate",10),b("minecraft:tuff",7))),
        new Era("Mechanical Processing", "Pressing, milling, crushing and washing.", List.of(b("minecraft:iron_ore",14),b("minecraft:copper_ore",13),b("create:zinc_ore",12),b("minecraft:redstone_ore",12),b("minecraft:andesite",12),b("minecraft:gravel",10),b("minecraft:sand",8),b("minecraft:clay",7),b("create:andesite_casing",5),b("minecraft:deepslate",7))),
        new Era("Redstone Control", "Logic and controlled machinery.", List.of(b("minecraft:redstone_ore",20),b("minecraft:iron_ore",12),b("minecraft:copper_ore",11),b("create:zinc_ore",10),b("minecraft:gold_ore",7),b("minecraft:quartz_block",3),b("minecraft:deepslate",14),b("minecraft:tuff",8),b("create:andesite_casing",5),b("minecraft:lapis_ore",5),b("minecraft:amethyst_block",5))),
        new Era("Golden Components", "Gold prepares precision engineering.", List.of(b("minecraft:gold_ore",15),b("minecraft:redstone_ore",15),b("minecraft:iron_ore",11),b("minecraft:copper_ore",11),b("create:zinc_ore",10),b("minecraft:lapis_ore",8),b("minecraft:deepslate",12),b("minecraft:amethyst_block",7),b("minecraft:calcite",6),b("create:copper_casing",5))),
        new Era("Nether Foothold", "Heat-resistant resources without unbreakable traps.", List.of(b("minecraft:netherrack",24),b("minecraft:nether_quartz_ore",15),b("minecraft:soul_sand",10),b("minecraft:basalt",10),b("minecraft:blackstone",10),b("minecraft:gold_ore",8),b("minecraft:magma_block",5),b("minecraft:gravel",8),b("minecraft:redstone_ore",5),b("minecraft:copper_ore",5))),
        new Era("Blaze Heat", "Heated processing and brass production.", List.of(b("minecraft:netherrack",17),b("minecraft:nether_quartz_ore",14),b("minecraft:soul_soil",8),b("minecraft:basalt",8),b("minecraft:blackstone",8),b("minecraft:gold_ore",9),b("minecraft:copper_ore",9),b("create:zinc_ore",9),b("create:brass_casing",3),b("create:copper_casing",5),b("minecraft:redstone_ore",10))),
        new Era("Brass Age", "Precision mechanisms and advanced machines.", List.of(b("create:brass_casing",8),b("create:andesite_casing",9),b("create:copper_casing",8),b("minecraft:gold_ore",10),b("minecraft:nether_quartz_ore",10),b("minecraft:redstone_ore",11),b("minecraft:copper_ore",10),b("create:zinc_ore",10),b("minecraft:iron_ore",10),b("minecraft:deepslate",8),b("minecraft:diamond_ore",1),b("minecraft:amethyst_block",5))),
        new Era("Automated Factory", "Deployers, arms and assembly lines.", List.of(b("create:brass_casing",10),b("create:andesite_casing",10),b("create:copper_casing",9),b("minecraft:redstone_ore",11),b("minecraft:iron_ore",9),b("minecraft:copper_ore",9),b("create:zinc_ore",8),b("minecraft:gold_ore",8),b("minecraft:quartz_block",6),b("minecraft:diamond_ore",2),b("minecraft:deepslate",8),b("minecraft:tuff",10))),
        new Era("Farming Industry", "Food production and processing.", List.of(b("minecraft:dirt",13),b("minecraft:clay",10),b("minecraft:hay_block",8),b("minecraft:pumpkin",7),b("minecraft:melon",7),b("minecraft:oak_log",8),b("farmersdelight:rich_soil",7),b("farmersdelight:rice_bale",5),b("farmersdelight:straw_bale",5),b("create:andesite_casing",7),b("minecraft:iron_ore",7),b("minecraft:copper_ore",7),b("minecraft:redstone_ore",7),b("minecraft:emerald_ore",2))),
        new Era("Storage Network", "Organized items and portable logistics.", List.of(b("minecraft:oak_log",10),b("minecraft:iron_ore",12),b("minecraft:copper_ore",10),b("minecraft:redstone_ore",10),b("minecraft:gold_ore",7),b("create:andesite_casing",9),b("create:brass_casing",7),b("create:copper_casing",7),b("sophisticatedstorage:barrel",4),b("minecraft:quartz_block",6),b("minecraft:deepslate",10),b("minecraft:emerald_ore",4),b("minecraft:diamond_ore",2))),
        new Era("Electrical Expansion", "Motors, alternators and electrical parts.", List.of(b("minecraft:copper_ore",16),b("minecraft:redstone_ore",15),b("minecraft:iron_ore",10),b("minecraft:gold_ore",9),b("create:zinc_ore",8),b("minecraft:quartz_block",8),b("createaddition:electrum_block",3),b("createaddition:zinc_sheet_metal",4),b("create:brass_casing",6),b("minecraft:diamond_ore",3),b("minecraft:deepslate",10),b("minecraft:amethyst_block",8))),
        new Era("Industrial Decoration", "Factory architecture and durable finishes.", List.of(b("createdeco:industrial_iron_block",10),b("createdeco:cast_iron_block",8),b("create:industrial_iron_block",8),b("create:metal_girder",8),b("minecraft:stone_bricks",10),b("minecraft:polished_deepslate",10),b("minecraft:smooth_stone",10),b("minecraft:iron_ore",10),b("minecraft:copper_ore",8),b("create:zinc_ore",7),b("minecraft:redstone_ore",7),b("minecraft:gold_ore",4))),
        new Era("Connected Construction", "Copycats and connected factory designs.", List.of(b("create_connected:copycat_block",10),b("create:andesite_casing",9),b("create:copper_casing",9),b("create:brass_casing",8),b("minecraft:stone_bricks",9),b("minecraft:polished_deepslate",9),b("minecraft:iron_ore",10),b("minecraft:copper_ore",9),b("create:zinc_ore",8),b("minecraft:redstone_ore",8),b("minecraft:gold_ore",7),b("minecraft:diamond_ore",4))),
        new Era("Railway Materials", "Tracks, stations and train construction.", List.of(b("create:railway_casing",10),b("create:metal_girder",10),b("minecraft:iron_ore",13),b("minecraft:copper_ore",9),b("minecraft:gold_ore",8),b("create:zinc_ore",8),b("minecraft:redstone_ore",9),b("minecraft:stone_bricks",8),b("minecraft:smooth_stone",7),b("createdeco:industrial_iron_block",5),b("createdeco:cast_iron_block",5),b("minecraft:diamond_ore",3),b("minecraft:emerald_ore",3))),
        new Era("Railway Empire", "Large-scale transportation and logistics.", List.of(b("create:railway_casing",14),b("create:metal_girder",11),b("create:brass_casing",9),b("minecraft:iron_ore",11),b("minecraft:copper_ore",8),b("minecraft:gold_ore",8),b("minecraft:redstone_ore",8),b("createdeco:industrial_iron_block",7),b("minecraft:polished_deepslate",7),b("minecraft:diamond_ore",4),b("minecraft:emerald_ore",5),b("minecraft:quartz_block",8))),
        new Era("Deep Earth", "Valuable ores and tougher stone.", List.of(b("minecraft:deepslate",20),b("minecraft:tuff",12),b("minecraft:iron_ore",10),b("minecraft:copper_ore",9),b("minecraft:redstone_ore",11),b("minecraft:gold_ore",9),b("minecraft:lapis_ore",7),b("minecraft:diamond_ore",6),b("minecraft:emerald_ore",4),b("create:zinc_ore",8),b("minecraft:amethyst_block",4))),
        new Era("Ancient Nether", "Late-game Nether materials; obsidian finally becomes safe.", List.of(b("minecraft:netherrack",15),b("minecraft:blackstone",12),b("minecraft:basalt",10),b("minecraft:nether_quartz_ore",10),b("minecraft:gold_ore",8),b("minecraft:obsidian",5),b("minecraft:crying_obsidian",3),b("minecraft:ancient_debris",1),b("create:brass_casing",8),b("create:railway_casing",6),b("minecraft:diamond_ore",4),b("minecraft:redstone_ore",8),b("minecraft:magma_block",10))),
        new Era("End Frontier", "End stone, chorus and advanced resources.", List.of(b("minecraft:end_stone",24),b("minecraft:purpur_block",10),b("minecraft:end_stone_bricks",6),b("minecraft:obsidian",6),b("minecraft:diamond_ore",6),b("minecraft:emerald_ore",5),b("minecraft:amethyst_block",8),b("create:brass_casing",8),b("create:railway_casing",6),b("minecraft:sculk",5),b("minecraft:crying_obsidian",3),b("minecraft:ancient_debris",1),b("minecraft:deepslate",12))),
        new Era("Master Automation", "The full Create toolset is supported.", List.of(b("create:brass_casing",12),b("create:railway_casing",10),b("create:industrial_iron_block",9),b("createdeco:cast_iron_block",7),b("createaddition:electrum_block",5),b("minecraft:diamond_ore",7),b("minecraft:emerald_ore",6),b("minecraft:ancient_debris",2),b("minecraft:obsidian",7),b("minecraft:crying_obsidian",4),b("minecraft:redstone_ore",9),b("minecraft:gold_ore",8),b("minecraft:deepslate",14))),
        new Era("World Architect", "Rare blocks for ambitious builds.", List.of(b("minecraft:diamond_ore",8),b("minecraft:emerald_ore",7),b("minecraft:ancient_debris",2),b("minecraft:obsidian",8),b("minecraft:crying_obsidian",5),b("create:brass_casing",10),b("create:railway_casing",9),b("createdeco:cast_iron_block",8),b("createaddition:electrum_block",5),b("minecraft:amethyst_block",8),b("minecraft:end_stone",10),b("minecraft:purpur_block",8),b("minecraft:deepslate",12))),
        new Era("Legendary Engineer", "The final ten story phases before endless mode.", List.of(b("minecraft:diamond_ore",9),b("minecraft:emerald_ore",8),b("minecraft:ancient_debris",3),b("minecraft:obsidian",7),b("minecraft:crying_obsidian",5),b("create:brass_casing",11),b("create:railway_casing",10),b("create:industrial_iron_block",8),b("createdeco:cast_iron_block",7),b("createaddition:electrum_block",5),b("minecraft:end_stone",9),b("minecraft:deepslate",12),b("minecraft:nether_quartz_ore",6)))
    );

    private CreateProgression() {}

    public static int phaseNumber(long generated) { return Math.min(STORY_PHASES, (int)(Math.max(0L, generated) / BLOCKS_PER_PHASE) + 1); }
    public static boolean isEndgame(long generated) { return generated >= ENDGAME_START; }
    public static long endgameCycle(long generated) { return isEndgame(generated) ? ((generated - ENDGAME_START) / BLOCKS_PER_PHASE) + 1 : 0; }
    public static int phaseIndex(long generated) { return Math.min(STORY_PHASES - 1, (int)(Math.max(0L, generated) / BLOCKS_PER_PHASE)); }

    public static Phase phase(long generated) {
        if (isEndgame(generated)) return endgamePhase(generated);
        return phaseByIndex(phaseIndex(generated));
    }

    public static Phase phaseByIndex(int index) {
        int safe = Math.max(0, Math.min(STORY_PHASES - 1, index));
        Era era = ERAS.get(safe / 10);
        int step = safe % 10 + 1;
        int number = safe + 1;
        int cash = 25 + number * 3 + (step == 10 ? 250 + number * 2 : 0);
        List<Reward> rewards = new ArrayList<>();
        if (number <= 20) {
            switch ((number - 1) % 8) {
                case 0 -> rewards.add(r("minecraft:wheat_seeds", 6, "wheat seeds"));
                case 1 -> rewards.add(r("minecraft:birch_sapling", 2, "birch saplings"));
                case 2 -> rewards.add(r("minecraft:carrot", 4, "carrots"));
                case 3 -> rewards.add(r("minecraft:spruce_sapling", 2, "spruce saplings"));
                case 4 -> rewards.add(r("minecraft:potato", 4, "potatoes"));
                case 5 -> rewards.add(r("minecraft:pumpkin_seeds", 4, "pumpkin seeds"));
                case 6 -> rewards.add(r("minecraft:melon_seeds", 4, "melon seeds"));
                case 7 -> rewards.add(r("minecraft:beetroot_seeds", 4, "beetroot seeds"));
                default -> { }
            }
        }
        if (step == 1) {
            rewards.add(r("minecraft:bread", 8, "food supplies"));
            if (number <= 20) {
                rewards.add(r("minecraft:wheat_seeds", 8, "wheat seeds"));
                rewards.add(r("minecraft:oak_sapling", 2, "oak saplings"));
                rewards.add(r("minecraft:carrot", 4, "carrots"));
                rewards.add(r("minecraft:potato", 4, "potatoes"));
            }
        }
        if (step == 5) rewards.add(r(number < 50 ? "minecraft:iron_ingot" : "create:andesite_alloy", 8, "engineering materials"));
        if (step == 10) rewards.add(majorReward(number));
        List<WeightedBlock> blocks = new ArrayList<>(era.blocks());
        addPhaseVariety(blocks, number, step);
        blocks.addAll(ExternalContentConfig.blocksForPhase(number));
        return new Phase(number, era.name() + " " + step, era.subtitle(), List.copyOf(blocks), rewards, cash);
    }


    /** Adds phase-specific variety so all ten phases in an era have noticeably different pools. */
    private static void addPhaseVariety(List<WeightedBlock> blocks, int number, int step) {
        int era = (number - 1) / 10;

        // Tree progression: stable logs and leaves enter the block pool; saplings are awarded as items.
        blocks.add(b("minecraft:oak_log", number <= 20 ? 6 : 2));
        blocks.add(b("minecraft:oak_leaves", number <= 20 ? 4 : 1));
        if (number >= 6) { blocks.add(b("minecraft:birch_log", 4)); blocks.add(b("minecraft:birch_leaves", 2)); }
        if (number >= 16) { blocks.add(b("minecraft:spruce_log", 4)); blocks.add(b("minecraft:spruce_leaves", 2)); }
        if (number >= 26) { blocks.add(b("minecraft:jungle_log", 3)); blocks.add(b("minecraft:jungle_leaves", 2)); }
        if (number >= 36) { blocks.add(b("minecraft:acacia_log", 3)); blocks.add(b("minecraft:acacia_leaves", 2)); }
        if (number >= 46) { blocks.add(b("minecraft:dark_oak_log", 3)); blocks.add(b("minecraft:dark_oak_leaves", 2)); }
        if (number >= 56) { blocks.add(b("minecraft:mangrove_log", 3)); blocks.add(b("minecraft:mangrove_leaves", 2)); }
        if (number >= 66) { blocks.add(b("minecraft:cherry_log", 3)); blocks.add(b("minecraft:cherry_leaves", 2)); }

        // Rotating natural/building materials keep consecutive phases from feeling identical.
        switch (step) {
            case 1 -> { blocks.add(b("minecraft:coarse_dirt", 7)); blocks.add(b("minecraft:rooted_dirt", 4)); blocks.add(b("minecraft:mud", 5)); }
            case 2 -> { blocks.add(b("minecraft:sand", 7)); blocks.add(b("minecraft:sandstone", 5)); blocks.add(b("minecraft:red_sand", 3)); }
            case 3 -> { blocks.add(b("minecraft:mossy_cobblestone", 5)); blocks.add(b("minecraft:mossy_stone_bricks", 4)); blocks.add(b("minecraft:moss_block", 3)); }
            case 4 -> { blocks.add(b("minecraft:dripstone_block", 6)); blocks.add(b("minecraft:smooth_basalt", 3)); blocks.add(b("minecraft:calcite", 4)); }
            case 5 -> { blocks.add(b("minecraft:terracotta", 6)); blocks.add(b("minecraft:white_terracotta", 3)); blocks.add(b("minecraft:red_terracotta", 3)); }
            case 6 -> { blocks.add(b("minecraft:snow_block", 4)); blocks.add(b("minecraft:ice", 3)); blocks.add(b("minecraft:packed_ice", number >= 80 ? 2 : 1)); }
            case 7 -> { blocks.add(b("minecraft:prismarine", number >= 70 ? 4 : 1)); blocks.add(b("minecraft:dark_prismarine", number >= 100 ? 2 : 1)); blocks.add(b("minecraft:sea_lantern", number >= 120 ? 1 : 0)); }
            case 8 -> { blocks.add(b("minecraft:bricks", 5)); blocks.add(b("minecraft:mud_bricks", 4)); blocks.add(b("minecraft:packed_mud", 4)); }
            case 9 -> { blocks.add(b("minecraft:bone_block", 3)); blocks.add(b("minecraft:hay_block", 4)); blocks.add(b("minecraft:honeycomb_block", number >= 60 ? 2 : 1)); }
            case 10 -> { blocks.add(b("minecraft:amethyst_block", number >= 50 ? 4 : 1)); blocks.add(b("minecraft:glowstone", number >= 90 ? 3 : 0)); blocks.add(b("minecraft:quartz_block", number >= 70 ? 3 : 1)); }
            default -> { }
        }

        // Extra biome and dimension materials become available as progression advances.
        if (era >= 2) { blocks.add(b("minecraft:podzol", 2)); blocks.add(b("minecraft:mycelium", era >= 8 ? 2 : 0)); }
        if (era >= 4) { blocks.add(b("minecraft:moss_block", 3)); blocks.add(b("minecraft:clay", 2)); blocks.add(b("minecraft:rooted_dirt", 2)); }
        if (era >= 7) { blocks.add(b("minecraft:nether_wart_block", 2)); blocks.add(b("minecraft:warped_wart_block", 2)); blocks.add(b("minecraft:crimson_nylium", 2)); blocks.add(b("minecraft:warped_nylium", 2)); }
        if (era >= 10) { blocks.add(b("minecraft:ochre_froglight", 1)); blocks.add(b("minecraft:verdant_froglight", 1)); blocks.add(b("minecraft:pearlescent_froglight", 1)); }
        if (era >= 14) { blocks.add(b("minecraft:sculk", 3)); blocks.add(b("minecraft:sculk_catalyst", 1)); }
        if (era >= 20) { blocks.add(b("minecraft:purpur_pillar", 3)); blocks.add(b("minecraft:end_stone_bricks", 4)); blocks.add(b("minecraft:purpur_block", 2)); }
    }

    private static Reward majorReward(int number) {
        return switch (number) {
            case 10 -> r("minecraft:sugar_cane", 8, "sugar cane");
            case 20 -> r("minecraft:cactus", 8, "cactus");
            case 30 -> r("minecraft:obsidian", 4, "obsidian");
            case 40 -> r("create:wrench", 1, "a Create wrench");
            case 50 -> r("create:water_wheel", 1, "a water wheel");
            case 60 -> r("minecraft:slime_ball", 16, "slime balls");
            case 70 -> r("create:mechanical_press", 1, "a Mechanical Press");
            case 80 -> r("create:mechanical_mixer", 1, "a Mechanical Mixer");
            case 90 -> r("minecraft:blaze_rod", 6, "blaze rods");
            case 100 -> r("minecraft:nether_wart", 16, "Nether wart");
            case 110 -> r("create:brass_ingot", 16, "brass ingots");
            case 120 -> r("create:precision_mechanism", 4, "precision mechanisms");
            case 130 -> r("create:deployer", 1, "a Deployer");
            case 140 -> r("create:mechanical_arm", 1, "a Mechanical Arm");
            case 150 -> r("createaddition:electric_motor", 1, "an electric motor");
            case 160 -> r("create:portable_storage_interface", 2, "portable storage interfaces");
            case 170 -> r("create:railway_casing", 8, "railway casings");
            case 180 -> r("create:track", 64, "train tracks");
            case 190 -> r("create:mechanical_crafter", 9, "Mechanical Crafters");
            case 200 -> r("minecraft:shulker_shell", 4, "shulker shells");
            case 210 -> r("minecraft:diamond", 16, "diamonds");
            case 220 -> r("minecraft:netherite_upgrade_smithing_template", 1, "a Netherite upgrade template");
            case 230 -> r("minecraft:ancient_debris", 4, "ancient debris");
            case 240 -> r("minecraft:totem_of_undying", 1, "a Totem of Undying");
            case 250 -> r("minecraft:elytra", 1, "an Elytra");
            default -> r("minecraft:iron_ingot", 8, "engineering materials");
        };
    }

    private static Phase endgamePhase(long generated) {
        long cycle = endgameCycle(generated);
        int tier = (int)Math.min(10, 1 + cycle / 10);
        List<WeightedBlock> pool = new ArrayList<>(ERAS.get(24).blocks());
        pool.add(b("minecraft:diamond_ore", 4 + tier));
        pool.add(b("minecraft:emerald_ore", 3 + tier));
        pool.add(b("minecraft:ancient_debris", 1 + tier / 3));
        pool.add(b("create:brass_casing", 5 + tier));
        pool.add(b("create:railway_casing", 4 + tier));
        return new Phase(STORY_PHASES + (int)Math.min(Integer.MAX_VALUE - STORY_PHASES, cycle),
                "Endless Engineering " + cycle, "Endgame cycle " + cycle + " — selling is unlocked.", pool,
                cycle % 10 == 0 ? List.of(r("create:precision_mechanism", Math.min(16, 2 + tier), "endgame precision mechanisms")) : List.of(),
                500 + tier * 100);
    }

    public static long nextPhaseAt(long generated) { return ((Math.max(0L, generated) / BLOCKS_PER_PHASE) + 1) * BLOCKS_PER_PHASE; }

    public static BlockState nextBlock(ServerLevel level, long generated) {
        List<WeightedBlock> available = new ArrayList<>(); int total = 0;
        for (WeightedBlock entry : phase(generated).blocks()) {
            if (entry.weight() <= 0) continue;
            ResourceLocation id = ResourceLocation.tryParse(entry.id());
            if (id == null || !BuiltInRegistries.BLOCK.containsKey(id)) continue;
            Block block = BuiltInRegistries.BLOCK.get(id);
            BlockState state = block.defaultBlockState();
            if (!isAllowedOneBlock(level, id, block, state)) continue;
            available.add(entry); total += entry.weight();
        }
        if (available.isEmpty() || total <= 0) return Blocks.STONE.defaultBlockState();
        int roll = level.random.nextInt(total);
        for (WeightedBlock entry : available) {
            roll -= entry.weight();
            if (roll < 0) return BuiltInRegistries.BLOCK.get(ResourceLocation.parse(entry.id())).defaultBlockState();
        }
        return Blocks.STONE.defaultBlockState();
    }


    /**
     * Final safety gate for built-in and externally configured phase blocks.
     * Fluids are never valid OneBlocks; water and lava are supplied through
     * reward chests and kits instead.
     */
    private static boolean isAllowedOneBlock(ServerLevel level, ResourceLocation id, Block block, BlockState state) {
        if (block == Blocks.AIR || state.isAir()) return false;
        if (!state.getFluidState().isEmpty()) return false;

        String path = id.getPath();
        if (path.equals("water") || path.equals("flowing_water")
                || path.equals("lava") || path.equals("flowing_lava")
                || path.equals("wheat") || path.equals("carrots") || path.equals("potatoes")
                || path.equals("kelp") || path.equals("kelp_plant")
                || path.equals("chorus_plant") || path.equals("chorus_flower")) {
            return false;
        }

        return state.getDestroySpeed(level, net.minecraft.core.BlockPos.ZERO) >= 0;
    }

    public static void givePhaseRewards(ServerPlayer player, Phase phase) {
        for (Reward reward : phase.rewards()) giveReward(player, reward);

        // Every phase grants one useful surprise. Milestone phases get a second roll.
        giveRandomReward(player, phase.number(), false);
        if (phase.number() <= STORY_PHASES && phase.number() % 10 == 0) {
            giveRandomReward(player, phase.number(), true);
        }
    }

    private static void giveReward(ServerPlayer player, Reward reward) {
        ResourceLocation id = ResourceLocation.tryParse(reward.itemId());
        if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) return;
        Item item = BuiltInRegistries.ITEM.get(id);
        ItemStack stack = new ItemStack(item, reward.count());
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        player.sendSystemMessage(Component.literal("Reward: " + reward.label() + " x" + reward.count()));
    }

    private static void giveRandomReward(ServerPlayer player, int phaseNumber, boolean milestoneRoll) {
        List<RandomReward> pool = randomRewardPool(phaseNumber, milestoneRoll);
        int totalWeight = 0;
        List<RandomReward> valid = new ArrayList<>();
        for (RandomReward reward : pool) {
            ResourceLocation id = ResourceLocation.tryParse(reward.itemId());
            if (reward.weight() <= 0 || id == null || !BuiltInRegistries.ITEM.containsKey(id)) continue;
            valid.add(reward);
            totalWeight += reward.weight();
        }
        if (valid.isEmpty() || totalWeight <= 0) return;

        int roll = player.getRandom().nextInt(totalWeight);
        RandomReward selected = valid.get(0);
        for (RandomReward reward : valid) {
            roll -= reward.weight();
            if (roll < 0) { selected = reward; break; }
        }
        int count = selected.minCount() + player.getRandom().nextInt(Math.max(1, selected.maxCount() - selected.minCount() + 1));
        giveReward(player, r(selected.itemId(), count, (milestoneRoll ? "milestone surprise: " : "phase surprise: ") + selected.label()));
    }

    /** Weighted rewards: progression essentials are common, powerful items remain genuinely rare. */
    private static List<RandomReward> randomRewardPool(int phase, boolean milestone) {
        List<RandomReward> pool = new ArrayList<>();
        int bonus = milestone ? 2 : 1;

        pool.add(rr("minecraft:bread", 4, 12, 22, "food supplies"));
        pool.add(rr("minecraft:coal", 6, 18, 18, "fuel"));
        pool.add(rr("minecraft:iron_ingot", 3, 10, 16, "iron ingots"));
        pool.add(rr("minecraft:copper_ingot", 4, 12, 15, "copper ingots"));
        pool.add(rr("minecraft:wheat_seeds", 4, 12, phase <= 40 ? 16 : 4, "wheat seeds"));
        pool.add(rr("minecraft:beetroot_seeds", 3, 8, phase <= 60 ? 10 : 3, "beetroot seeds"));
        pool.add(rr("minecraft:pumpkin_seeds", 2, 6, phase <= 70 ? 9 : 3, "pumpkin seeds"));
        pool.add(rr("minecraft:melon_seeds", 2, 6, phase <= 80 ? 8 : 3, "melon seeds"));
        pool.add(rr("minecraft:oak_sapling", 1, 3, 8, "oak saplings"));
        pool.add(rr("minecraft:birch_sapling", 1, 3, phase >= 5 ? 7 : 0, "birch saplings"));
        pool.add(rr("minecraft:spruce_sapling", 1, 3, phase >= 15 ? 6 : 0, "spruce saplings"));
        pool.add(rr("minecraft:jungle_sapling", 1, 2, phase >= 25 ? 5 : 0, "jungle saplings"));
        pool.add(rr("minecraft:acacia_sapling", 1, 2, phase >= 35 ? 5 : 0, "acacia saplings"));
        pool.add(rr("minecraft:dark_oak_sapling", 2, 4, phase >= 45 ? 4 : 0, "dark oak saplings"));
        pool.add(rr("minecraft:mangrove_propagule", 1, 3, phase >= 55 ? 4 : 0, "mangrove propagules"));
        pool.add(rr("minecraft:cherry_sapling", 1, 2, phase >= 65 ? 4 : 0, "cherry saplings"));

        if (phase >= 20) {
            pool.add(rr("minecraft:redstone", 6, 18, 14, "redstone dust"));
            pool.add(rr("minecraft:lapis_lazuli", 4, 12, 9, "lapis lazuli"));
            pool.add(rr("create:andesite_alloy", 3, 10, 13, "andesite alloy"));
            pool.add(rr("create:cogwheel", 2, 8, 8, "cogwheels"));
            pool.add(rr("create:shaft", 4, 12, 8, "shafts"));
        }
        if (phase >= 50) {
            pool.add(rr("minecraft:gold_ingot", 3, 9, 11, "gold ingots"));
            pool.add(rr("minecraft:slime_ball", 3, 10, 8, "slime balls"));
            pool.add(rr("create:electron_tube", 2, 6, 7, "electron tubes"));
            pool.add(rr("minecraft:diamond", 1, 2, milestone ? 4 : 1, "diamonds"));
        }
        if (phase >= 90) {
            pool.add(rr("minecraft:blaze_rod", 2, 6, 8, "blaze rods"));
            pool.add(rr("minecraft:quartz", 6, 18, 10, "Nether quartz"));
            pool.add(rr("create:brass_ingot", 3, 9, 10, "brass ingots"));
            pool.add(rr("create:precision_mechanism", 1, 2, milestone ? 5 : 2, "precision mechanisms"));
        }
        if (phase >= 140) {
            pool.add(rr("minecraft:emerald", 2, 7, 8, "emeralds"));
            pool.add(rr("minecraft:ender_pearl", 2, 6, 7, "ender pearls"));
            pool.add(rr("minecraft:experience_bottle", 4, 12, 7, "experience bottles"));
            pool.add(rr("minecraft:diamond", 1, 3, milestone ? 7 : 3, "diamonds"));
        }
        if (phase >= 190) {
            pool.add(rr("minecraft:shulker_shell", 1, 2, milestone ? 4 : 1, "shulker shells"));
            pool.add(rr("minecraft:ancient_debris", 1, 2, milestone ? 3 : 1, "ancient debris"));
            pool.add(rr("minecraft:netherite_scrap", 1, 2, milestone ? 2 : 1, "netherite scrap"));
        }
        if (phase >= 225) {
            pool.add(rr("minecraft:totem_of_undying", 1, 1, milestone ? 2 : 0, "a Totem of Undying"));
            pool.add(rr("minecraft:nether_star", 1, 1, milestone ? 1 : 0, "a Nether Star"));
            pool.add(rr("minecraft:enchanted_golden_apple", 1, 1, milestone ? 1 : 0, "an enchanted golden apple"));
        }
        return pool;
    }

    public static int totalPhases() { return STORY_PHASES; }
}
