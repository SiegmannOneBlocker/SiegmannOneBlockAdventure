package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Builds the first-join welcome and returning-player dashboard messages. */
public final class JoinMessageService {
    private static final Component RULE = Component.literal("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━").withStyle(ChatFormatting.DARK_AQUA);

    private JoinMessageService() {}

    public static void sendFirstJoin(ServerPlayer player) {
        player.sendSystemMessage(RULE);
        player.sendSystemMessage(Component.literal("Welcome to").withStyle(ChatFormatting.GRAY));
        player.sendSystemMessage(Component.literal("Siegmann OneBlock Adventure").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        player.sendSystemMessage(Component.empty());
        player.sendSystemMessage(Component.literal("Your adventure begins with one block.").withStyle(ChatFormatting.AQUA));
        player.sendSystemMessage(Component.literal("• Complete 250 unique phases").withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("• Build powerful Create factories").withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("• Explore floating structures and events").withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("• Master professions, quests, and rewards").withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("• Compete in PvP and Dragon Cup").withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.empty());
        player.sendSystemMessage(Component.literal("Use ").append(Component.literal("/soa menu").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)).append(" to begin."));
        player.sendSystemMessage(RULE);
    }

    public static void sendReturningJoin(ServerPlayer player, long generated, int mail) {
        long balance = EconomySavedData.get(player.serverLevel()).balance(player.getUUID());
        Stage31SavedData stage = Stage31SavedData.get(player.serverLevel());
        Stage31SavedData.Metrics metrics = stage.metrics(player.getUUID());
        long score = metrics.machines * 10L + metrics.belts + metrics.deployers * 25L + metrics.automated / 100L;
        String tier = score >= 10000 ? "Planetary Factory" : score >= 5000 ? "Mega Factory" : score >= 2000 ? "Industrial" : score >= 500 ? "Fully Automated" : score >= 100 ? "Semi Automated" : "Manual";

        player.sendSystemMessage(RULE);
        player.sendSystemMessage(Component.literal("Welcome back, ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(player.getGameProfile().getName()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)));
        player.sendSystemMessage(Component.literal("OneBlocks generated: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(String.valueOf(generated)).withStyle(ChatFormatting.AQUA)));
        player.sendSystemMessage(Component.literal("Balance: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal("$" + balance).withStyle(ChatFormatting.GREEN)));
        player.sendSystemMessage(Component.literal("Factory tier: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(tier).withStyle(ChatFormatting.LIGHT_PURPLE)));
        if (!"none".equals(stage.activeEvent)) {
            long minutes = Math.max(0L, stage.eventEndsAt - System.currentTimeMillis()) / 60000L;
            player.sendSystemMessage(Component.literal("Live event: ").withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(stage.activeEvent.replace('_', ' ') + " (about " + minutes + "m left)").withStyle(ChatFormatting.YELLOW)));
        }
        if (mail > 0) {
            player.sendSystemMessage(Component.literal("Mail waiting: ").withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(String.valueOf(mail)).withStyle(ChatFormatting.GOLD)));
        }
        player.sendSystemMessage(Component.literal("Open your dashboard with ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal("/soa menu").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)));
        player.sendSystemMessage(RULE);
    }
}
