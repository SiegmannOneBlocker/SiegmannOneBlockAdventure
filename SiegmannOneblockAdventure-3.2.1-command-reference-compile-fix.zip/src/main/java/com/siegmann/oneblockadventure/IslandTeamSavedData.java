package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

public final class IslandTeamSavedData extends SavedData {
    private static final String NAME="soa_island_teams";
    private static final Factory<IslandTeamSavedData> FACTORY=new Factory<>(IslandTeamSavedData::new,IslandTeamSavedData::load,null);
    public record Permissions(boolean build,boolean breakBlocks,boolean containers,boolean machines,boolean invite){
        public static Permissions member(){return new Permissions(true,true,true,true,false);} }
    private final Map<UUID,UUID> memberOwner=new HashMap<>();
    private final Map<UUID,Permissions> permissions=new HashMap<>();
    private final Map<UUID,Set<UUID>> invites=new HashMap<>();
    public static IslandTeamSavedData get(ServerLevel level){return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY,NAME);}    
    public UUID ownerOf(UUID player){return memberOwner.getOrDefault(player,player);}    
    public boolean isMember(UUID owner,UUID player){return owner.equals(player)||owner.equals(memberOwner.get(player));}
    public Set<UUID> members(UUID owner){Set<UUID>s=new HashSet<>();s.add(owner);memberOwner.forEach((p,o)->{if(o.equals(owner))s.add(p);});return s;}
    public Permissions permissions(UUID player){return permissions.getOrDefault(player,Permissions.member());}
    public void invite(UUID owner,UUID target){invites.computeIfAbsent(target,k->new HashSet<>()).add(owner);setDirty();}
    public boolean hasInvite(UUID target,UUID owner){return invites.getOrDefault(target,Set.of()).contains(owner);}
    public boolean accept(UUID target,UUID owner){if(!hasInvite(target,owner))return false;removeInvite(target,owner);memberOwner.put(target,owner);permissions.put(target,Permissions.member());setDirty();return true;}
    public void removeInvite(UUID target,UUID owner){Set<UUID>s=invites.get(target);if(s!=null){s.remove(owner);if(s.isEmpty())invites.remove(target);}setDirty();}
    public void removeMember(UUID player){memberOwner.remove(player);permissions.remove(player);setDirty();}
    public void setPermissions(UUID player,Permissions p){permissions.put(player,p);setDirty();}
    public void clearPlayer(UUID id){removeMember(id);invites.remove(id);invites.values().forEach(s->s.remove(id));setDirty();}
    private static IslandTeamSavedData load(CompoundTag tag, HolderLookup.Provider r){IslandTeamSavedData d=new IslandTeamSavedData();ListTag ms=tag.getList("Members",Tag.TAG_COMPOUND);for(int i=0;i<ms.size();i++){CompoundTag e=ms.getCompound(i);if(e.hasUUID("Player")&&e.hasUUID("Owner")){UUID p=e.getUUID("Player");d.memberOwner.put(p,e.getUUID("Owner"));d.permissions.put(p,new Permissions(e.getBoolean("Build"),e.getBoolean("Break"),e.getBoolean("Containers"),e.getBoolean("Machines"),e.getBoolean("Invite")));}}ListTag is=tag.getList("Invites",Tag.TAG_COMPOUND);for(int i=0;i<is.size();i++){CompoundTag e=is.getCompound(i);if(e.hasUUID("Target")&&e.hasUUID("Owner"))d.invites.computeIfAbsent(e.getUUID("Target"),k->new HashSet<>()).add(e.getUUID("Owner"));}return d;}
    @Override public CompoundTag save(CompoundTag tag,HolderLookup.Provider r){ListTag ms=new ListTag();memberOwner.forEach((p,o)->{Permissions x=permissions(p);CompoundTag e=new CompoundTag();e.putUUID("Player",p);e.putUUID("Owner",o);e.putBoolean("Build",x.build());e.putBoolean("Break",x.breakBlocks());e.putBoolean("Containers",x.containers());e.putBoolean("Machines",x.machines());e.putBoolean("Invite",x.invite());ms.add(e);});tag.put("Members",ms);ListTag is=new ListTag();invites.forEach((t,os)->os.forEach(o->{CompoundTag e=new CompoundTag();e.putUUID("Target",t);e.putUUID("Owner",o);is.add(e);}));tag.put("Invites",is);return tag;}
}
