package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

public final class AdventureSavedData extends SavedData {
    private static final String NAME = "siegmann_oneblock_adventure_features";
    private static final Factory<AdventureSavedData> FACTORY = new Factory<>(AdventureSavedData::new, AdventureSavedData::load, null);

    public record Listing(long id, UUID seller, String sellerName, String itemId, int count, long price) {}
    public static final class Profile {
        long lastDailyDay = Long.MIN_VALUE;
        int dailyStreak;
        long playTicks;
        long timeRewardMask;
        long blocksBroken;
        long cashEarned;
        long bossesDefeated;
        long cratesOpened;
        long luckyBlocks;
        int miningXp;
        int engineeringXp;
        int farmingXp;
        int combatXp;
        int miningKitTier;
        int engineeringKitTier;
        int farmingKitTier;
        int combatKitTier;
        int luckUpgrade;
        int moneyUpgrade;
        int rareUpgrade;
        int mobDropUpgrade;
        int storageUpgrade;
        int experienceUpgrade;
        String title = "";
        String particle = "none";
        boolean breakEffects = true;
    }

    private final Map<UUID, Profile> profiles = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> crates = new HashMap<>();
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private long nextListingId = 1L;
    private double globalCashMultiplier = 1.0D;
    private double globalRareMultiplier = 1.0D;

    public static AdventureSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }
    public Profile profile(UUID id) { return profiles.computeIfAbsent(id, ignored -> new Profile()); }
    public int crateCount(UUID id, String tier) { return crates.getOrDefault(id, Map.of()).getOrDefault(tier, 0); }
    public void addCrate(UUID id, String tier, int amount) { crates.computeIfAbsent(id, ignored -> new HashMap<>()).merge(tier, amount, Integer::sum); setDirty(); }
    public boolean takeCrate(UUID id, String tier) { int count=crateCount(id,tier); if(count<1)return false; crates.get(id).put(tier,count-1); setDirty(); return true; }
    public Collection<Listing> listings() { return Collections.unmodifiableCollection(listings.values()); }
    public Listing listing(long id) { return listings.get(id); }
    public Listing addListing(UUID seller, String sellerName, String itemId, int count, long price) { Listing l=new Listing(nextListingId++,seller,sellerName,itemId,count,price); listings.put(l.id(),l); setDirty(); return l; }
    public Listing removeListing(long id) { Listing l=listings.remove(id); if(l!=null)setDirty(); return l; }
    public double globalCashMultiplier(){ return globalCashMultiplier; }
    public double globalRareMultiplier(){ return globalRareMultiplier; }
    public void setGlobalCashMultiplier(double value){ globalCashMultiplier=Math.max(0.0D,value); setDirty(); }
    public void setGlobalRareMultiplier(double value){ globalRareMultiplier=Math.max(0.0D,value); setDirty(); }
    public void dirty(){ setDirty(); }
    public void clearPlayer(UUID id){ profiles.remove(id); crates.remove(id); listings.entrySet().removeIf(e -> e.getValue().seller().equals(id)); setDirty(); }

    private static AdventureSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        AdventureSavedData data = new AdventureSavedData();
        data.nextListingId=Math.max(1L,tag.getLong("NextListingId"));
        data.globalCashMultiplier=tag.contains("GlobalCashMultiplier")?Math.max(0D,tag.getDouble("GlobalCashMultiplier")):1D;
        data.globalRareMultiplier=tag.contains("GlobalRareMultiplier")?Math.max(0D,tag.getDouble("GlobalRareMultiplier")):1D;
        ListTag profiles=tag.getList("Profiles",Tag.TAG_COMPOUND);
        for(int i=0;i<profiles.size();i++){
            CompoundTag e=profiles.getCompound(i); if(!e.hasUUID("Player"))continue; Profile p=new Profile();
            p.lastDailyDay=e.getLong("LastDailyDay"); p.dailyStreak=e.getInt("DailyStreak"); p.playTicks=e.getLong("PlayTicks"); p.timeRewardMask=e.getLong("TimeRewardMask"); p.blocksBroken=e.getLong("BlocksBroken"); p.cashEarned=e.getLong("CashEarned"); p.bossesDefeated=e.getLong("BossesDefeated"); p.cratesOpened=e.getLong("CratesOpened"); p.luckyBlocks=e.getLong("LuckyBlocks");
            p.miningXp=e.getInt("MiningXp"); p.engineeringXp=e.getInt("EngineeringXp"); p.farmingXp=e.getInt("FarmingXp"); p.combatXp=e.getInt("CombatXp");
            p.miningKitTier=e.getInt("MiningKitTier"); p.engineeringKitTier=e.getInt("EngineeringKitTier"); p.farmingKitTier=e.getInt("FarmingKitTier"); p.combatKitTier=e.getInt("CombatKitTier");
            p.luckUpgrade=e.getInt("LuckUpgrade"); p.moneyUpgrade=e.getInt("MoneyUpgrade"); p.rareUpgrade=e.getInt("RareUpgrade"); p.mobDropUpgrade=e.getInt("MobDropUpgrade"); p.storageUpgrade=e.getInt("StorageUpgrade"); p.experienceUpgrade=e.getInt("ExperienceUpgrade");
            p.title=e.getString("Title"); p.particle=e.getString("Particle"); p.breakEffects=!e.contains("BreakEffects")||e.getBoolean("BreakEffects"); data.profiles.put(e.getUUID("Player"),p);
        }
        ListTag cratePlayers=tag.getList("Crates",Tag.TAG_COMPOUND);
        for(int i=0;i<cratePlayers.size();i++){ CompoundTag e=cratePlayers.getCompound(i); if(!e.hasUUID("Player"))continue; Map<String,Integer> map=new HashMap<>(); for(String tier:List.of("common","rare","epic","legendary","mythic"))map.put(tier,Math.max(0,e.getInt(tier))); data.crates.put(e.getUUID("Player"),map); }
        ListTag listings=tag.getList("Listings",Tag.TAG_COMPOUND);
        for(int i=0;i<listings.size();i++){ CompoundTag e=listings.getCompound(i); try{ Listing l=new Listing(e.getLong("Id"),e.getUUID("Seller"),e.getString("SellerName"),e.getString("ItemId"),Math.max(1,e.getInt("Count")),Math.max(1,e.getLong("Price"))); data.listings.put(l.id(),l);}catch(RuntimeException ignored){} }
        return data;
    }

    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLong("NextListingId",nextListingId); tag.putDouble("GlobalCashMultiplier",globalCashMultiplier); tag.putDouble("GlobalRareMultiplier",globalRareMultiplier);
        ListTag ps=new ListTag(); profiles.forEach((id,p)->{ CompoundTag e=new CompoundTag(); e.putUUID("Player",id); e.putLong("LastDailyDay",p.lastDailyDay); e.putInt("DailyStreak",p.dailyStreak); e.putLong("PlayTicks",p.playTicks); e.putLong("TimeRewardMask",p.timeRewardMask); e.putLong("BlocksBroken",p.blocksBroken); e.putLong("CashEarned",p.cashEarned); e.putLong("BossesDefeated",p.bossesDefeated); e.putLong("CratesOpened",p.cratesOpened); e.putLong("LuckyBlocks",p.luckyBlocks); e.putInt("MiningXp",p.miningXp); e.putInt("EngineeringXp",p.engineeringXp); e.putInt("FarmingXp",p.farmingXp); e.putInt("CombatXp",p.combatXp); e.putInt("MiningKitTier",p.miningKitTier); e.putInt("EngineeringKitTier",p.engineeringKitTier); e.putInt("FarmingKitTier",p.farmingKitTier); e.putInt("CombatKitTier",p.combatKitTier); e.putInt("LuckUpgrade",p.luckUpgrade); e.putInt("MoneyUpgrade",p.moneyUpgrade); e.putInt("RareUpgrade",p.rareUpgrade); e.putInt("MobDropUpgrade",p.mobDropUpgrade); e.putInt("StorageUpgrade",p.storageUpgrade); e.putInt("ExperienceUpgrade",p.experienceUpgrade); e.putString("Title",p.title); e.putString("Particle",p.particle); e.putBoolean("BreakEffects",p.breakEffects); ps.add(e); }); tag.put("Profiles",ps);
        ListTag cs=new ListTag(); crates.forEach((id,map)->{ CompoundTag e=new CompoundTag(); e.putUUID("Player",id); for(String tier:List.of("common","rare","epic","legendary","mythic"))e.putInt(tier,map.getOrDefault(tier,0)); cs.add(e);}); tag.put("Crates",cs);
        ListTag ls=new ListTag(); listings.values().forEach(l->{CompoundTag e=new CompoundTag();e.putLong("Id",l.id());e.putUUID("Seller",l.seller());e.putString("SellerName",l.sellerName());e.putString("ItemId",l.itemId());e.putInt("Count",l.count());e.putLong("Price",l.price());ls.add(e);}); tag.put("Listings",ls);
        return tag;
    }
}
