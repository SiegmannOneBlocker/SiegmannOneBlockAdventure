package com.siegmann.oneblockadventure;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class PlayerEvents {
    private PlayerEvents() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            long generated = MultiOneSavedData.get(player.serverLevel()).byOwner(player.getUUID())
                    .map(MultiOneSavedData.Island::generated).orElse(0L);
            CommunitySavedData community = CommunitySavedData.get(player.serverLevel());
            boolean firstJoin = !community.hasProfile(player.getUUID());
            community.remember(player.getUUID(), player.getGameProfile().getName());
            ScoreboardSystem.update(player, generated);
            int mail = MailSavedData.get(player.serverLevel()).box(player.getUUID()).size();
            if (firstJoin) JoinMessageService.sendFirstJoin(player);
            else JoinMessageService.sendReturningJoin(player, generated, mail);
        }
    }
}
