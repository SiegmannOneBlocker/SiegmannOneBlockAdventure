package com.siegmann.oneblockadventure;

import com.craftbound.oneblock.OneBlockSavedData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;

@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class MultiOneEvents {
    private MultiOneEvents() {}

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)
                || !(event.getPlayer() instanceof ServerPlayer player)) {
            return;
        }

        // CraftBound continues controlling its original global block.
        if (OneBlockSavedData.get(level).isOneBlock(event.getPos())) return;

        MultiOneSavedData storage = MultiOneSavedData.get(level);
        storage.at(level.dimension(), event.getPos()).ifPresent(island -> {
            event.setCanceled(true);
            advanceIsland(level, island, player, event.getState(), true);
        });
    }

    /**
     * Advances an island by exactly one OneBlock break.
     *
     * <p>The normal player-break event calls this with {@code preserveDrops=true}.
     * Create contraptions such as Mechanical Drills can remove blocks without a
     * normal player break event, so the recovery event calls this with
     * {@code preserveDrops=false}; Create has already handled the mined item.</p>
     */
    static void advanceIsland(ServerLevel level,
                              MultiOneSavedData.Island island,
                              ServerPlayer rewardPlayer,
                              BlockState oldState,
                              boolean preserveDrops) {
        BlockPos pos = island.pos();

        if (preserveDrops && oldState != null && rewardPlayer != null) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            ItemStack tool = rewardPlayer.getMainHandItem();
            for (ItemStack drop : Block.getDrops(oldState, level, pos, blockEntity, rewardPlayer, tool)) {
                Block.popResource(level, pos, drop);
            }
        }

        long oldCount = island.generated();
        long newCount = oldCount + 1L;
        long oldStage = oldCount / CreateProgression.BLOCKS_PER_PHASE;
        long newStage = newCount / CreateProgression.BLOCKS_PER_PHASE;

        level.setBlockAndUpdate(pos, CreateProgression.nextBlock(level, newCount));
        MultiOneSavedData.get(level).put(island.withGenerated(newCount));

        if (rewardPlayer == null) {
            return;
        }

        QuestSystem.checkBlockQuests(rewardPlayer, newCount);
        AdventureSystem.onOneBlockBreak(rewardPlayer, newCount);
        EndgameSystem.handleMilestones(rewardPlayer, oldCount, newCount);

        if (CreateProgression.isEndgame(newCount)
                && EndgameSystem.rareBlockChance(rewardPlayer) > 0.0D
                && level.random.nextDouble() < EndgameSystem.rareBlockChance(rewardPlayer)) {
            ItemStack jackpot = new ItemStack(net.minecraft.world.item.Items.DIAMOND, 1);
            if (!rewardPlayer.getInventory().add(jackpot)) rewardPlayer.drop(jackpot, false);
            rewardPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal("✦ Prestige jackpot block: +1 Diamond!")
                    .withStyle(net.minecraft.ChatFormatting.AQUA, net.minecraft.ChatFormatting.BOLD));
        }

        if (newStage > oldStage) {
            CreateProgression.Phase unlocked = CreateProgression.phase(newCount);
            SpecialMessages.phaseUnlocked(level.getServer(), rewardPlayer, unlocked.number() - 1, unlocked);
            CreateProgression.givePhaseRewards(rewardPlayer, unlocked);
            RewardChestSystem.phaseChest(rewardPlayer, island, unlocked.number());
            AnimalProgressionSystem.onPhaseComplete(rewardPlayer, island, unlocked.number());
            long phaseCash = EndgameSystem.applyPrestigeCashBonus(rewardPlayer, unlocked.cashReward());
            AdventureSystem.addCash(rewardPlayer, phaseCash);
            rewardPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal("+$" + phaseCash
                    + " phase reward. Balance: $" + ShopSystem.balance(rewardPlayer)));
            ScoreboardSystem.update(rewardPlayer, newCount);
        } else if (newCount % 100L == 0L) {
            SpecialMessages.milestone(rewardPlayer, newCount);
        } else if (newCount % 25L == 0L) {
            SpecialMessages.progress(rewardPlayer, newCount);
        }
    }
}
