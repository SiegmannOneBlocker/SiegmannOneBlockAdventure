package com.siegmann.oneblockadventure;

import com.craftbound.oneblock.OneBlockCore;
import com.craftbound.oneblock.OneBlockSavedData;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class MultiOneCommands {
    private static final long SET_COOLDOWN_MILLIS = 48L * 60L * 60L * 1000L;
    private static final int RANDOM_ISLAND_MIN = -1_000_000;
    private static final int RANDOM_ISLAND_MAX = 1_000_000;
    private static final int RANDOM_ISLAND_SPACING = 5_000;
    private static final int RANDOM_ISLAND_Y = 100;
    private static final int RANDOM_ISLAND_ATTEMPTS = 500;
    private MultiOneCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("multione")
                .executes(c -> help(c.getSource()))
                .then(Commands.literal("help").executes(c -> help(c.getSource())))
                .then(Commands.literal("progress").executes(c -> progress(c.getSource(), c.getSource().getPlayerOrException())))
                .then(Commands.literal("shop").executes(c -> shop(c.getSource().getPlayerOrException())))
                .then(Commands.literal("balance").executes(c -> balance(c.getSource().getPlayerOrException())))
                .then(Commands.literal("quests").executes(c -> quests(c.getSource().getPlayerOrException())))
                .then(Commands.literal("endgame").executes(c -> endgame(c.getSource(), c.getSource().getPlayerOrException())))
                .then(Commands.literal("prestige").executes(c -> prestige(c.getSource(), c.getSource().getPlayerOrException())))
                .then(Commands.literal("startnew")
                        .executes(c -> startNew(c.getSource(), c.getSource().getPlayerOrException(), false))
                        .then(Commands.argument("player", EntityArgument.player()).requires(s -> s.hasPermission(2))
                                .executes(c -> startNew(c.getSource(), EntityArgument.getPlayer(c, "player"), true))))
                .then(Commands.literal("create")
                        .executes(c -> create(c.getSource(), c.getSource().getPlayerOrException(), false))
                        .then(Commands.argument("player", EntityArgument.player()).requires(s -> s.hasPermission(2))
                                .executes(c -> create(c.getSource(), EntityArgument.getPlayer(c, "player"), true))))
                .then(Commands.literal("set")
                        .executes(c -> set(c.getSource(), c.getSource().getPlayerOrException(), false))
                        .then(Commands.argument("player", EntityArgument.player()).requires(s -> s.hasPermission(2))
                                .executes(c -> set(c.getSource(), EntityArgument.getPlayer(c, "player"), true))))
                .then(Commands.literal("remove").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> remove(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> reset(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("count").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", LongArgumentType.longArg(0))
                                        .executes(c -> count(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                LongArgumentType.getLong(c, "amount"))))))
                .then(Commands.literal("tp")
                        .executes(c -> tp(c.getSource(), c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player()).requires(s -> s.hasPermission(2))
                                .executes(c -> tp(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("info")
                        .executes(c -> info(c.getSource(), c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player()).requires(s -> s.hasPermission(2))
                                .executes(c -> info(c.getSource(), EntityArgument.getPlayer(c, "player"))))));
        dispatcher.register(Commands.literal("shop")
                .executes(c -> shop(c.getSource().getPlayerOrException()))
                .then(Commands.literal("page").then(Commands.argument("page", IntegerArgumentType.integer(1))
                        .executes(c -> { ShopSystem.open(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "page")); return 1; })))
                .then(Commands.literal("search").then(Commands.argument("text", StringArgumentType.greedyString())
                        .executes(c -> { ShopSystem.search(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "text"), 1); return 1; })))
                .then(Commands.literal("buy").then(Commands.argument("slot", IntegerArgumentType.integer(1))
                        .executes(c -> ShopSystem.buy(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "slot")))))
                .then(Commands.literal("sellhand").executes(c -> ShopSystem.sellHand(c.getSource().getPlayerOrException())))
                .then(Commands.literal("sellall").executes(c -> ShopSystem.sellAll(c.getSource().getPlayerOrException()))));
        dispatcher.register(Commands.literal("quests")
                .executes(c -> quests(c.getSource().getPlayerOrException()))
                .then(Commands.literal("claim")
                        .then(Commands.argument("number", IntegerArgumentType.integer(1, QuestSystem.QUESTS.size()))
                                .executes(c -> QuestSystem.claim(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "number"))))));
        dispatcher.register(Commands.literal("balance").executes(c -> balance(c.getSource().getPlayerOrException())));
        dispatcher.register(Commands.literal("endgame").executes(c -> endgame(c.getSource(), c.getSource().getPlayerOrException())));
        dispatcher.register(Commands.literal("prestige").executes(c -> prestige(c.getSource(), c.getSource().getPlayerOrException())));
    }

    static int help(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("SiegmannOneblockAdventure Commands").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        source.sendSuccess(() -> Component.literal("/soa progress - phase and next unlock"), false);
        source.sendSuccess(() -> Component.literal("/soa startnew - create your first island at a random location"), false);
        source.sendSuccess(() -> Component.literal("/soa create - create your OneBlock at your current claimed location"), false);
        source.sendSuccess(() -> Component.literal("/soa set - move it once every 48 hours"), false);
        source.sendSuccess(() -> Component.literal("/soa tp - teleport home"), false);
        source.sendSuccess(() -> Component.literal("/shop - all installed items; page <number>; search <text>; buy <number>; sellhand; sellall"), false);
        source.sendSuccess(() -> Component.literal("/quests - quest window; /quests claim <number>"), false);
        source.sendSuccess(() -> Component.literal("/balance - show cash"), false);
        source.sendSuccess(() -> Component.literal("/endgame - endless tier, events and next boss"), false);
        source.sendSuccess(() -> Component.literal("/prestige - claim earned prestige ranks"), false);
        source.sendSuccess(() -> Component.literal("The block must be inside a claim you own."), false);
        source.sendSuccess(() -> Component.literal("Admin: create <player>, set <player>, info, reset, remove, count"), false);
        return 1;
    }

    private static BlockPos targetPos(CommandSourceStack source) {
        ServerPlayer executor = source.getPlayer();
        return executor != null ? executor.blockPosition().below() : BlockPos.containing(source.getPosition()).below();
    }


    static int startNew(CommandSourceStack source, ServerPlayer owner, boolean adminBypass) {
        ServerLevel level = source.getServer().overworld();
        if (level == null) {
            source.sendFailure(Component.literal("The Overworld is unavailable."));
            return 0;
        }

        MultiOneSavedData data = MultiOneSavedData.get(level);
        if (!adminBypass && data.hasEverCreated(owner.getUUID())) {
            source.sendFailure(Component.literal("You already own an island. Use /soa tp to return to it."));
            return 0;
        }
        if (data.byOwner(owner.getUUID()).isPresent()) {
            source.sendFailure(Component.literal("That player already owns an island. Use /soa tp to return to it."));
            return 0;
        }

        BlockPos pos = findRandomIslandPosition(level, data);
        if (pos == null) {
            source.sendFailure(Component.literal("Could not find a safe unused island location. Try again."));
            return 0;
        }

        level.getChunk(pos);
        prepareRandomStarterIsland(level, pos);
        data.put(new MultiOneSavedData.Island(owner.getUUID(), level.dimension(), pos, 0L));
        data.markCreated(owner.getUUID());
        data.markSetNow(owner.getUUID(), System.currentTimeMillis());

        owner.teleportTo(level, pos.getX() + 0.5D, pos.getY() + 2.0D, pos.getZ() + 0.5D,
                owner.getYRot(), owner.getXRot());
        giveStarterKit(owner);

        source.sendSuccess(() -> Component.literal("Created " + owner.getName().getString()
                + "'s island at " + pos.toShortString()).withStyle(ChatFormatting.GREEN), true);
        owner.sendSystemMessage(Component.literal("Your island is ready. Use /soa tp whenever you want to return.")
                .withStyle(ChatFormatting.GOLD));
        SpecialMessages.created(level.getServer(), owner);
        SpecialMessages.phaseUnlocked(level.getServer(), owner, 0, CreateProgression.phaseByIndex(0));
        CreateProgression.givePhaseRewards(owner, CreateProgression.phaseByIndex(0));
        EconomySavedData.get(level).add(owner.getUUID(), CreateProgression.phaseByIndex(0).cashReward());
        ScoreboardSystem.update(owner, 0L);
        StructureSystem.generateAroundNewIsland(level, pos);
        return 1;
    }

    private static BlockPos findRandomIslandPosition(ServerLevel level, MultiOneSavedData data) {
        RandomSource random = level.getRandom();
        long minimumDistanceSquared = (long) RANDOM_ISLAND_SPACING * RANDOM_ISLAND_SPACING;
        int range = RANDOM_ISLAND_MAX - RANDOM_ISLAND_MIN + 1;

        for (int attempt = 0; attempt < RANDOM_ISLAND_ATTEMPTS; attempt++) {
            int x = RANDOM_ISLAND_MIN + random.nextInt(range);
            int z = RANDOM_ISLAND_MIN + random.nextInt(range);
            x = Math.floorDiv(x, 16) * 16 + 8;
            z = Math.floorDiv(z, 16) * 16 + 8;
            BlockPos candidate = new BlockPos(x, RANDOM_ISLAND_Y, z);
            if (!level.getWorldBorder().isWithinBounds(candidate)) continue;

            boolean tooClose = data.all().stream()
                    .filter(island -> island.dimension().equals(level.dimension()))
                    .anyMatch(island -> {
                        long dx = (long) island.pos().getX() - candidate.getX();
                        long dz = (long) island.pos().getZ() - candidate.getZ();
                        return dx * dx + dz * dz < minimumDistanceSquared;
                    });
            if (!tooClose && data.at(level.dimension(), candidate).isEmpty()
                    && !OneBlockSavedData.get(level).isOneBlock(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private static void prepareRandomStarterIsland(ServerLevel level, BlockPos pos) {
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                for (int y = 0; y <= 5; y++) {
                    level.setBlockAndUpdate(pos.offset(x, y, z), Blocks.AIR.defaultBlockState());
                }
                level.setBlockAndUpdate(pos.offset(x, -1, z), Blocks.GRASS_BLOCK.defaultBlockState());
                level.setBlockAndUpdate(pos.offset(x, -2, z), Blocks.DIRT.defaultBlockState());
            }
        }
        level.setBlockAndUpdate(pos, Blocks.GRASS_BLOCK.defaultBlockState());
        OneBlockCore.ensureSafeActiveBlock(level, pos);
        level.setBlockAndUpdate(pos.below(), Blocks.BEDROCK.defaultBlockState());
        level.setBlockAndUpdate(pos.offset(2, 0, 2), Blocks.OAK_SAPLING.defaultBlockState());
        level.setBlockAndUpdate(pos.offset(-3, 0, -3), Blocks.TORCH.defaultBlockState());
        level.setBlockAndUpdate(pos.offset(3, 0, -3), Blocks.TORCH.defaultBlockState());
    }

    private static void giveStarterKit(ServerPlayer owner) {
        ItemStack[] kit = {
                new ItemStack(Items.WATER_BUCKET),
                new ItemStack(Items.LAVA_BUCKET),
                new ItemStack(Items.OAK_SAPLING),
                new ItemStack(Items.WHEAT_SEEDS, 3),
                new ItemStack(Items.STONE_PICKAXE),
                new ItemStack(Items.STONE_AXE),
                new ItemStack(Items.STONE_SHOVEL),
                new ItemStack(Items.STONE_HOE),
                new ItemStack(Items.STONE_SWORD),
                new ItemStack(Items.BREAD, 8),
                new ItemStack(Items.TORCH, 16),
                new ItemStack(Items.COBBLESTONE, 16),
                new ItemStack(Items.OAK_LOG, 8),
                new ItemStack(Items.BONE_MEAL, 8),
                new ItemStack(Items.CRAFTING_TABLE),
                new ItemStack(Items.CHEST)
        };
        for (ItemStack stack : kit) {
            if (!owner.getInventory().add(stack)) owner.drop(stack, false);
        }
    }

    static int create(CommandSourceStack source, ServerPlayer owner, boolean adminBypass) {
        ServerLevel level = source.getLevel();
        BlockPos pos = targetPos(source);
        MultiOneSavedData data = MultiOneSavedData.get(level);

        if (!adminBypass && data.hasEverCreated(owner.getUUID())) {
            source.sendFailure(Component.literal("You have already used your one-time /soa create. Use /soa set after its cooldown."));
            return 0;
        }
        if (data.byOwner(owner.getUUID()).isPresent()) {
            source.sendFailure(Component.literal("That player already has a MultiOne block. Use /soa set to move it."));
            return 0;
        }
        if (!ClaimIntegration.isOwnedClaim(level, pos, owner)) {
            source.sendFailure(Component.literal("The OneBlock must be placed inside a chunk claimed by that player."));
            return 0;
        }
        if (data.at(level.dimension(), pos).isPresent()) {
            source.sendFailure(Component.literal("That position already belongs to another MultiOne block."));
            return 0;
        }
        if (OneBlockSavedData.get(level).isOneBlock(pos)) {
            source.sendFailure(Component.literal("That position is CraftBound's original OneBlock. Pick a different location."));
            return 0;
        }

        prepareStarterArea(level, pos);
        data.put(new MultiOneSavedData.Island(owner.getUUID(), level.dimension(), pos, 0L));
        data.markCreated(owner.getUUID());
        data.markSetNow(owner.getUUID(), System.currentTimeMillis());
        owner.teleportTo(level, pos.getX() + 0.5D, pos.getY() + 2.0D, pos.getZ() + 0.5D, owner.getYRot(), owner.getXRot());
        giveStarterKit(owner);
        source.sendSuccess(() -> Component.literal("Created a MultiOne block for " + owner.getName().getString()
                + " at " + pos.toShortString()), true);
        SpecialMessages.created(level.getServer(), owner);
        SpecialMessages.phaseUnlocked(level.getServer(), owner, 0, CreateProgression.phaseByIndex(0));
        CreateProgression.givePhaseRewards(owner, CreateProgression.phaseByIndex(0));
        EconomySavedData.get(level).add(owner.getUUID(), CreateProgression.phaseByIndex(0).cashReward());
        ScoreboardSystem.update(owner, 0L);
        return 1;
    }

    private static void prepareStarterArea(ServerLevel level, BlockPos pos) {
        for (int x = -3; x <= 3; x++) {
            for (int y = -1; y <= 3; y++) {
                for (int z = -3; z <= 3; z++) {
                    level.setBlockAndUpdate(pos.offset(x, y, z), Blocks.AIR.defaultBlockState());
                }
            }
        }
        level.setBlockAndUpdate(pos, Blocks.GRASS_BLOCK.defaultBlockState());
        OneBlockCore.ensureSafeActiveBlock(level, pos);
        level.setBlockAndUpdate(pos.below(), Blocks.BEDROCK.defaultBlockState());
    }

    static int set(CommandSourceStack source, ServerPlayer owner, boolean adminBypass) {
        ServerLevel level = source.getLevel();
        BlockPos pos = targetPos(source);
        MultiOneSavedData data = MultiOneSavedData.get(level);

        var existing = data.byOwner(owner.getUUID());
        if (existing.isEmpty()) {
            source.sendFailure(Component.literal("You do not have a MultiOne block yet. Use /soa create first."));
            return 0;
        }
        long now = System.currentTimeMillis();
        long remaining = SET_COOLDOWN_MILLIS - (now - data.lastSetTime(owner.getUUID()));
        if (!adminBypass && remaining > 0L) {
            long hours = (remaining + 3_599_999L) / 3_600_000L;
            source.sendFailure(Component.literal("You can move your OneBlock again in about " + hours + " hour(s)."));
            return 0;
        }
        if (!ClaimIntegration.isOwnedClaim(level, pos, owner)) {
            source.sendFailure(Component.literal("The OneBlock must be placed inside a chunk claimed by that player."));
            return 0;
        }

        if (data.at(level.dimension(), pos).filter(i -> !i.owner().equals(owner.getUUID())).isPresent()) {
            source.sendFailure(Component.literal("That position is already used by another MultiOne block."));
            return 0;
        }
        if (OneBlockSavedData.get(level).isOneBlock(pos)) {
            source.sendFailure(Component.literal("That position is CraftBound's original OneBlock. Pick a different location."));
            return 0;
        }

        long count = existing.get().generated();
        ServerLevel oldLevel = source.getServer().getLevel(existing.get().dimension());
        if (oldLevel != null) {
            oldLevel.setBlockAndUpdate(existing.get().pos(), Blocks.AIR.defaultBlockState());
            oldLevel.setBlockAndUpdate(existing.get().pos().below(), Blocks.AIR.defaultBlockState());
        }
        prepareStarterArea(level, pos);
        data.put(new MultiOneSavedData.Island(owner.getUUID(), level.dimension(), pos, count));
        data.markSetNow(owner.getUUID(), now);
        ScoreboardSystem.update(owner, count);
        source.sendSuccess(() -> Component.literal("Moved " + owner.getName().getString()
                + "'s MultiOne block to " + pos.toShortString()), true);
        return 1;
    }

    static int remove(CommandSourceStack source, ServerPlayer owner) {
        boolean removed = MultiOneSavedData.get(source.getLevel()).remove(owner.getUUID());
        if (!removed) {
            source.sendFailure(Component.literal("That player has no MultiOne block."));
            return 0;
        }
        source.sendSuccess(() -> Component.literal("Removed " + owner.getName().getString() + "'s MultiOne registration."), true);
        return 1;
    }

    static int reset(CommandSourceStack source, ServerPlayer owner) {
        MultiOneSavedData data = MultiOneSavedData.get(source.getLevel());
        var island = data.byOwner(owner.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("That player has no MultiOne block."));
            return 0;
        }
        data.put(island.get().withGenerated(0L));
        ServerLevel level = source.getServer().getLevel(island.get().dimension());
        if (level != null) {
            level.setBlockAndUpdate(island.get().pos(), Blocks.GRASS_BLOCK.defaultBlockState());
        }
        source.sendSuccess(() -> Component.literal("Reset progression for " + owner.getName().getString()), true);
        return 1;
    }

    static int count(CommandSourceStack source, ServerPlayer owner, long amount) {
        MultiOneSavedData data = MultiOneSavedData.get(source.getLevel());
        var island = data.byOwner(owner.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("That player has no MultiOne block."));
            return 0;
        }
        data.put(island.get().withGenerated(amount));
        source.sendSuccess(() -> Component.literal("Set generated count to " + amount), true);
        return 1;
    }

    static int tp(CommandSourceStack source, ServerPlayer target) {
        var island = MultiOneSavedData.get(source.getLevel()).byOwner(target.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("That player has no MultiOne block."));
            return 0;
        }
        ServerLevel destination = source.getServer().getLevel(island.get().dimension());
        if (destination == null) {
            source.sendFailure(Component.literal("The island dimension is unavailable."));
            return 0;
        }
        BlockPos p = island.get().pos();
        target.teleportTo(destination, p.getX() + 0.5D, p.getY() + 2.0D, p.getZ() + 0.5D, 0.0F, 0.0F);
        return 1;
    }

    static int progress(CommandSourceStack source, ServerPlayer target) {
        var island = MultiOneSavedData.get(source.getLevel()).byOwner(target.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("You do not have a MultiOne block."));
            return 0;
        }
        SpecialMessages.progress(target, island.get().generated());
        return 1;
    }

    static int info(CommandSourceStack source, ServerPlayer target) {
        var island = MultiOneSavedData.get(source.getLevel()).byOwner(target.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("That player has no MultiOne block."));
            return 0;
        }
        var i = island.get();
        source.sendSuccess(() -> Component.literal(target.getName().getString() + ": "
                + i.dimension().location() + " " + i.pos().toShortString() + ", generated=" + i.generated()), false);
        return 1;
    }

    static int endgame(CommandSourceStack source, ServerPlayer player) {
        var island = MultiOneSavedData.get(source.getLevel()).byOwner(player.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("You do not have a MultiOne block."));
            return 0;
        }
        long generated = island.get().generated();
        if (!CreateProgression.isEndgame(generated)) {
            long remaining = CreateProgression.ENDGAME_START - generated;
            source.sendFailure(Component.literal("Endgame begins after Phase 250. " + remaining + " blocks remaining."));
            return 0;
        }
        long endBlocks = EndgameSystem.endgameBlocks(generated);
        long nextEvent = ((endBlocks / EndgameSystem.EVENT_INTERVAL) + 1L) * EndgameSystem.EVENT_INTERVAL;
        long nextBoss = ((endBlocks / EndgameSystem.BOSS_INTERVAL) + 1L) * EndgameSystem.BOSS_INTERVAL;
        source.sendSuccess(() -> Component.literal("Endgame Tier " + EndgameSystem.tier(generated)).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        source.sendSuccess(() -> Component.literal("Endgame blocks: " + endBlocks + " | Next event in " + (nextEvent - endBlocks) + " | Next boss in " + (nextBoss - endBlocks)), false);
        source.sendSuccess(() -> Component.literal("Selling is unlocked. Use /shop sellhand or /shop sellall."), false);
        return 1;
    }

    static int prestige(CommandSourceStack source, ServerPlayer player) {
        var island = MultiOneSavedData.get(source.getLevel()).byOwner(player.getUUID());
        if (island.isEmpty()) {
            source.sendFailure(Component.literal("You do not have a MultiOne block."));
            return 0;
        }
        long generated = island.get().generated();
        PrestigeSavedData saved = PrestigeSavedData.get(player.serverLevel());
        int current = saved.level(player.getUUID());
        long needed = EndgameSystem.nextPrestigeAt(current);
        if (generated < needed) {
            source.sendFailure(Component.literal("Prestige " + (current + 1) + " requires " + (needed - generated) + " more blocks."));
            return 0;
        }
        int rank = saved.add(player.getUUID());
        long reward = 10_000L * Math.max(1L, rank);
        EconomySavedData.get(player.serverLevel()).add(player.getUUID(), reward);
        givePrestigeCrate(player, rank);
        String title = EndgameSystem.prestigeTitle(rank);
        String message = "✦ " + player.getName().getString() + " reached PRESTIGE " + rank
                + " — " + title + " — and earned $" + reward + "!";
        player.getServer().getPlayerList().broadcastSystemMessage(Component.literal(message).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        if (rank % 10 == 0 || rank == 100 || rank == 250 || rank == 500 || rank == 1000) {
            player.getServer().getPlayerList().broadcastSystemMessage(
                    Component.literal("★ LEGENDARY MILESTONE: " + player.getName().getString() + " is now Prestige " + rank + "!")
                            .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        }
        player.sendSystemMessage(Component.literal("Permanent bonuses: "
                + String.format("%.0f%% cash, %.1f%% rare-block chance",
                (EndgameSystem.cashMultiplier(player) - 1.0D) * 100.0D,
                EndgameSystem.rareBlockChance(player) * 100.0D)).withStyle(ChatFormatting.AQUA));
        ScoreboardSystem.update(player, generated);
        return 1;
    }

    private static void givePrestigeCrate(ServerPlayer player, int rank) {
        int diamonds = Math.min(64, 4 + rank / 5);
        int emeralds = Math.min(64, 8 + rank / 3);
        int gold = Math.min(64, 16 + rank / 2);
        net.minecraft.world.item.ItemStack[] rewards = {
                new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DIAMOND, diamonds),
                new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.EMERALD, emeralds),
                new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GOLD_INGOT, gold)
        };
        for (net.minecraft.world.item.ItemStack stack : rewards) {
            if (!player.getInventory().add(stack)) player.drop(stack, false);
        }
        player.sendSystemMessage(Component.literal("Prestige crate delivered!").withStyle(ChatFormatting.GOLD));
    }

    static int shop(ServerPlayer player) { ShopSystem.open(player); return 1; }
    static int quests(ServerPlayer player) { QuestSystem.open(player); return 1; }
    static int balance(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("Cash balance: $" + ShopSystem.balance(player)).withStyle(ChatFormatting.GREEN));
        return 1;
    }
}
