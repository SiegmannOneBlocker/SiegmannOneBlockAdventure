package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class EndgameSystem {
    public static final long EVENT_INTERVAL = 500L;
    public static final long BOSS_INTERVAL = 5_000L;
    public static final long PRESTIGE_INTERVAL = 25_000L;

    private EndgameSystem() {}

    public static long endgameBlocks(long generated) {
        return Math.max(0L, generated - CreateProgression.ENDGAME_START);
    }

    public static int tier(long generated) {
        return (int) (endgameBlocks(generated) / 2_500L) + 1;
    }

    public static long nextPrestigeAt(int currentPrestige) {
        return CreateProgression.ENDGAME_START + (long) (currentPrestige + 1) * PRESTIGE_INTERVAL;
    }

    public static void handleMilestones(ServerPlayer player, long oldCount, long newCount) {
        if (!CreateProgression.isEndgame(newCount)) return;
        long oldEnd = endgameBlocks(oldCount);
        long newEnd = endgameBlocks(newCount);

        if (newEnd > 0L && newEnd / BOSS_INTERVAL > oldEnd / BOSS_INTERVAL) {
            bossEvent(player, newCount);
        } else if (newEnd > 0L && newEnd / EVENT_INTERVAL > oldEnd / EVENT_INTERVAL) {
            randomEvent(player, newCount);
        }
    }

    public static double cashMultiplier(ServerPlayer player) {
        int prestige = PrestigeSavedData.get(player.serverLevel()).level(player.getUUID());
        return 1.0D + Math.min(10.0D, prestige * 0.02D);
    }

    public static double rareBlockChance(ServerPlayer player) {
        int prestige = PrestigeSavedData.get(player.serverLevel()).level(player.getUUID());
        return Math.min(0.20D, prestige * 0.001D);
    }

    public static long applyPrestigeCashBonus(ServerPlayer player, long base) {
        return Math.max(base, Math.round(base * cashMultiplier(player)));
    }

    public static String prestigeTitle(int prestige) {
        if (prestige >= 1000) return "Omega Factory";
        if (prestige >= 500) return "Eternal Architect";
        if (prestige >= 250) return "Mythic Industrialist";
        if (prestige >= 100) return "Factory Sovereign";
        if (prestige >= 50) return "Master Engineer";
        if (prestige >= 10) return "Industrial Legend";
        if (prestige >= 1) return "Prestiged Engineer";
        return "Factory Builder";
    }

    private static void randomEvent(ServerPlayer player, long generated) {
        ServerLevel level = player.serverLevel();
        int roll = level.random.nextInt(4);
        int tier = tier(generated);
        switch (roll) {
            case 0 -> {
                long reward = applyPrestigeCashBonus(player, 500L + tier * 75L);
                EconomySavedData.get(level).add(player.getUUID(), reward);
                announce(player, "☀ CASH SURGE! +$" + reward, ChatFormatting.GREEN);
            }
            case 1 -> {
                ItemStack reward = new ItemStack(Items.DIAMOND, Math.min(16, 2 + tier / 2));
                give(player, reward);
                announce(player, "◆ ORE JACKPOT! Diamonds dropped into your inventory.", ChatFormatting.AQUA);
            }
            case 2 -> {
                give(player, new ItemStack(Items.IRON_INGOT, Math.min(64, 16 + tier * 2)));
                give(player, new ItemStack(Items.COPPER_INGOT, Math.min(64, 16 + tier * 2)));
                give(player, new ItemStack(Items.GOLD_INGOT, Math.min(32, 4 + tier)));
                announce(player, "⚙ FACTORY SUPPLY CRATE!", ChatFormatting.GOLD);
            }
            default -> {
                spawnWave(level, player, Math.min(8, 2 + tier / 2));
                announce(player, "☠ HOSTILE ASSAULT! Defend your factory.", ChatFormatting.RED);
            }
        }
        ScoreboardSystem.update(player, generated);
    }

    private static void bossEvent(ServerPlayer player, long generated) {
        ServerLevel level = player.serverLevel();
        BlockPos origin = player.blockPosition().offset(4, 1, 4);
        Mob boss = EntityType.RAVAGER.create(level);
        if (boss != null) {
            boss.moveTo(origin.getX() + 0.5D, origin.getY(), origin.getZ() + 0.5D, 0.0F, 0.0F);
            boss.setCustomName(Component.literal("Endgame Factory Breaker").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
            boss.setCustomNameVisible(true);
            level.addFreshEntity(boss);
        }
        spawnWave(level, player, 4);
        long reward = applyPrestigeCashBonus(player, 2_500L + tier(generated) * 250L);
        EconomySavedData.get(level).add(player.getUUID(), reward);
        announce(player, "☠ BOSS EVENT: Factory Breaker! Survival bonus +$" + reward, ChatFormatting.DARK_RED);
        ScoreboardSystem.update(player, generated);
    }

    private static void spawnWave(ServerLevel level, ServerPlayer player, int count) {
        for (int i = 0; i < count; i++) {
            Mob mob = (i % 3 == 0 ? EntityType.SKELETON : EntityType.ZOMBIE).create(level);
            if (mob == null) continue;
            double angle = (Math.PI * 2.0D * i) / Math.max(1, count);
            double x = player.getX() + Math.cos(angle) * 5.0D;
            double z = player.getZ() + Math.sin(angle) * 5.0D;
            mob.moveTo(x, player.getY() + 1.0D, z, 0.0F, 0.0F);
            level.addFreshEntity(mob);
        }
    }

    private static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }

    private static void announce(ServerPlayer player, String text, ChatFormatting color) {
        Component message = Component.literal(text).withStyle(color, ChatFormatting.BOLD);
        player.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("[Siegmann OneBlock] ").withStyle(ChatFormatting.DARK_GRAY).append(message)
                        .append(Component.literal(" — " + player.getName().getString()).withStyle(ChatFormatting.GRAY)), false);
    }
}
