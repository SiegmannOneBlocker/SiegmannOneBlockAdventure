package com.siegmann.oneblockadventure;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.lang.reflect.Method;
import java.util.UUID;

/** Runtime integration with Open Parties and Claims without bundling its classes. */
public final class ClaimIntegration {
    private ClaimIntegration() {}

    public static boolean isOwnedClaim(ServerLevel level, BlockPos pos, ServerPlayer player) {
        try {
            Class<?> apiClass = Class.forName("xaero.pac.common.server.api.OpenPACServerAPI");
            Method getApi = apiClass.getMethod("get", net.minecraft.server.MinecraftServer.class);
            Object api = getApi.invoke(null, level.getServer());
            Object claimsManager = api.getClass().getMethod("getServerClaimsManager").invoke(api);
            Object claim = claimsManager.getClass()
                    .getMethod("get", net.minecraft.resources.ResourceLocation.class, BlockPos.class)
                    .invoke(claimsManager, level.dimension().location(), pos);
            if (claim == null) return false;
            UUID owner = (UUID) claim.getClass().getMethod("getPlayerId").invoke(claim);
            return player.getUUID().equals(owner);
        } catch (ReflectiveOperationException | LinkageError ex) {
            SiegmannOneblockAdventure.LOGGER.error("Could not verify Open Parties and Claims ownership", ex);
            return false;
        }
    }
}
