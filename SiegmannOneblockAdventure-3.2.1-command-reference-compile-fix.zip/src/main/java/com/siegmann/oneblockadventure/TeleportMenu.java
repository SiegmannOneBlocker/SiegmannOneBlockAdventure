package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Centralized server-side teleport GUI.
 *
 * <p>Every destination is resolved again when clicked instead of trusting stale menu data.
 * This prevents teleporting to removed islands, worlds, arenas, or structures.</p>
 */
public final class TeleportMenu {
    private static final int PAGE_SIZE = 36;

    private TeleportMenu() {}

    public static void open(ServerPlayer player) {
        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();

        label(inventory, 4, Items.ENDER_PEARL, "Teleportation Hub",
                "Safe travel to islands, spawn, events, structures, and administrator destinations.");

        button(inventory, actions, 10, Items.GRASS_BLOCK, "My Island",
                "Teleport to your island, or your team owner's island.", TeleportMenu::teleportHome);
        button(inventory, actions, 11, Items.PLAYER_HEAD, "Island Team Destinations",
                "Visit islands belonging to your island team.", p -> openTeamIslands(p, 0));
        button(inventory, actions, 12, Items.LODESTONE, "Server Spawn",
                "Teleport to the Overworld spawn point.", TeleportMenu::teleportSpawn);
        button(inventory, actions, 13, Items.IRON_SWORD, "PvP Arena",
                "Teleport to the configured PvP arena.", TeleportMenu::teleportArena);
        button(inventory, actions, 14, Items.MAP, "Adventure Structures",
                "Browse generated adventure structures.", p -> openStructures(p, 0));
        button(inventory, actions, 15, Items.DRAGON_HEAD, "Dragon Cup",
                "Open Dragon Cup registration and status.", CompetitiveMenu::open);
        button(inventory, actions, 16, Items.COMPASS, "Current Coordinates",
                currentLocationLore(player), p -> sendCurrentLocation(p));

        button(inventory, actions, 28, Items.CHEST, "Main Menu",
                "Return to the main adventure menu.", AdventureSystem::openMenu);
        button(inventory, actions, 30, Items.WRITABLE_BOOK, "Island Team & Permissions",
                "Manage invitations and island member permissions.", IslandTeamMenu::open);

        if (player.hasPermissions(2)) {
            button(inventory, actions, 32, Items.END_PORTAL_FRAME, "Admin World Teleports",
                    "Browse every loaded dimension and teleport to its spawn.", p -> openWorlds(p, 0));
            button(inventory, actions, 33, Items.RECOVERY_COMPASS, "Admin Island Browser",
                    "Browse and teleport to every registered OneBlock island.", p -> openAllIslands(p, 0));
        }

        open(player, inventory, actions, 6, "Teleportation Hub");
    }

    public static int teleportHome(ServerPlayer player) {
        UUID owner = IslandTeamSavedData.get(player.serverLevel()).ownerOf(player.getUUID());
        MultiOneSavedData.Island island = MultiOneSavedData.get(player.serverLevel()).byOwner(owner).orElse(null);
        if (island == null) {
            player.sendSystemMessage(Component.literal("No island destination was found. Create one with /soa startnew.")
                    .withStyle(ChatFormatting.RED));
            return 0;
        }
        return teleportToIsland(player, island, owner.equals(player.getUUID()) ? "your island" : "your team island");
    }

    public static int teleportSpawn(ServerPlayer player) {
        return AdventureSystem.teleportSpawn(player);
    }

    public static int teleportArena(ServerPlayer player) {
        CompetitiveSavedData data = CompetitiveSavedData.get(player.serverLevel());
        if (data.arenaCenter == null) {
            player.sendSystemMessage(Component.literal("The PvP arena has not been generated yet.")
                    .withStyle(ChatFormatting.RED));
            return 0;
        }
        ServerLevel level = player.getServer().overworld();
        return teleport(player, level, data.arenaCenter.above(), "PvP arena");
    }

    public static void openTeamIslands(ServerPlayer player, int requestedPage) {
        IslandTeamSavedData teams = IslandTeamSavedData.get(player.serverLevel());
        MultiOneSavedData islands = MultiOneSavedData.get(player.serverLevel());
        UUID owner = teams.ownerOf(player.getUUID());
        List<UUID> allowed = new ArrayList<>(teams.members(owner));
        allowed.sort(Comparator.comparing(id -> profileName(player, id), String.CASE_INSENSITIVE_ORDER));

        List<MultiOneSavedData.Island> destinations = allowed.stream()
                .map(id -> islands.byOwner(id).orElse(null))
                .filter(java.util.Objects::nonNull)
                .toList();

        openIslandList(player, destinations, requestedPage, false, "Island Team Destinations",
                TeleportMenu::openTeamIslands);
    }

    public static void openAllIslands(ServerPlayer player, int requestedPage) {
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Administrator permission is required.")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        List<MultiOneSavedData.Island> destinations = new ArrayList<>(MultiOneSavedData.get(player.serverLevel()).all());
        destinations.sort(Comparator.comparing(i -> profileName(player, i.owner()), String.CASE_INSENSITIVE_ORDER));
        openIslandList(player, destinations, requestedPage, true, "Admin Island Browser",
                TeleportMenu::openAllIslands);
    }

    private static void openIslandList(ServerPlayer player,
                                       List<MultiOneSavedData.Island> destinations,
                                       int requestedPage,
                                       boolean admin,
                                       String title,
                                       PageOpener opener) {
        int pages = Math.max(1, (destinations.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();

        int start = page * PAGE_SIZE;
        int end = Math.min(destinations.size(), start + PAGE_SIZE);
        for (int index = start; index < end; index++) {
            MultiOneSavedData.Island island = destinations.get(index);
            int slot = index - start;
            String ownerName = profileName(player, island.owner());
            int phase = CreateProgression.phaseNumber(island.generated());
            String lore = "Phase " + phase + " • " + island.dimension().location() + " • " + island.pos().toShortString();
            button(inventory, actions, slot, Items.GRASS_BLOCK, ownerName + "'s Island", lore,
                    p -> {
                        if (!admin && !IslandTeamSavedData.get(p.serverLevel())
                                .isMember(IslandTeamSavedData.get(p.serverLevel()).ownerOf(p.getUUID()), island.owner())) {
                            p.sendSystemMessage(Component.literal("You no longer have permission to visit that island.")
                                    .withStyle(ChatFormatting.RED));
                            return;
                        }
                        MultiOneSavedData.Island current = MultiOneSavedData.get(p.serverLevel())
                                .byOwner(island.owner()).orElse(null);
                        if (current == null) {
                            p.sendSystemMessage(Component.literal("That island no longer exists.")
                                    .withStyle(ChatFormatting.RED));
                            return;
                        }
                        teleportToIsland(p, current, ownerName + "'s island");
                    });
        }

        label(inventory, 45, Items.PAPER, "Page " + (page + 1) + " / " + pages,
                destinations.size() + " destination(s)");
        if (page > 0) button(inventory, actions, 48, Items.ARROW, "Previous Page", "Go back one page.", p -> opener.open(p, page - 1));
        button(inventory, actions, 49, Items.ENDER_PEARL, "Teleportation Hub", "Return to the teleport menu.", TeleportMenu::open);
        if (page + 1 < pages) button(inventory, actions, 50, Items.ARROW, "Next Page", "Go forward one page.", p -> opener.open(p, page + 1));
        open(player, inventory, actions, 6, title);
    }

    public static void openStructures(ServerPlayer player, int requestedPage) {
        List<CommunitySavedData.StructureSite> sites = new ArrayList<>(CommunitySavedData.get(player.serverLevel()).structures());
        sites.sort(Comparator.comparingDouble(site -> site.pos().distSqr(player.blockPosition())));
        int pages = Math.max(1, (sites.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));

        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();
        int start = page * PAGE_SIZE;
        int end = Math.min(sites.size(), start + PAGE_SIZE);
        for (int index = start; index < end; index++) {
            CommunitySavedData.StructureSite site = sites.get(index);
            int slot = index - start;
            int distance = (int) Math.sqrt(site.pos().distSqr(player.blockPosition()));
            String name = titleCase(site.type()) + " Structure";
            button(inventory, actions, slot, structureIcon(site.type()), name,
                    site.pos().toShortString() + " • about " + distance + " blocks away",
                    p -> {
                        if (!CommunitySavedData.get(p.serverLevel()).structures().contains(site)) {
                            p.sendSystemMessage(Component.literal("That structure destination is no longer registered.")
                                    .withStyle(ChatFormatting.RED));
                            return;
                        }
                        teleport(p, p.getServer().overworld(), site.pos().above(2), name);
                        CommunitySavedData.get(p.serverLevel()).foundStructure(p.getUUID());
                    });
        }
        if (sites.isEmpty()) {
            label(inventory, 22, Items.BARRIER, "No Structures Registered",
                    "Generate a new island or use /soa admin structure generate <type>.");
        }
        label(inventory, 45, Items.PAPER, "Page " + (page + 1) + " / " + pages, sites.size() + " structure(s)");
        if (page > 0) button(inventory, actions, 48, Items.ARROW, "Previous Page", "Go back one page.", p -> openStructures(p, page - 1));
        button(inventory, actions, 49, Items.ENDER_PEARL, "Teleportation Hub", "Return to the teleport menu.", TeleportMenu::open);
        if (page + 1 < pages) button(inventory, actions, 50, Items.ARROW, "Next Page", "Go forward one page.", p -> openStructures(p, page + 1));
        open(player, inventory, actions, 6, "Adventure Structure Teleports");
    }

    public static void openWorlds(ServerPlayer player, int requestedPage) {
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Administrator permission is required.")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        List<ServerLevel> levels = new ArrayList<>();
        player.getServer().getAllLevels().forEach(levels::add);
        levels.sort(Comparator.comparing(l -> l.dimension().location().toString()));
        int pages = Math.max(1, (levels.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));

        SimpleContainer inventory = new SimpleContainer(54);
        Map<Integer, Consumer<ServerPlayer>> actions = new HashMap<>();
        int start = page * PAGE_SIZE;
        int end = Math.min(levels.size(), start + PAGE_SIZE);
        for (int index = start; index < end; index++) {
            ServerLevel level = levels.get(index);
            int slot = index - start;
            ResourceKey<Level> dimension = level.dimension();
            button(inventory, actions, slot, dimensionIcon(dimension), dimension.location().toString(),
                    "Spawn: " + level.getSharedSpawnPos().toShortString(),
                    p -> {
                        ServerLevel current = p.getServer().getLevel(dimension);
                        if (current == null) {
                            p.sendSystemMessage(Component.literal("That world is no longer loaded.")
                                    .withStyle(ChatFormatting.RED));
                            return;
                        }
                        teleport(p, current, current.getSharedSpawnPos().above(), dimension.location().toString());
                    });
        }
        label(inventory, 45, Items.PAPER, "Page " + (page + 1) + " / " + pages, levels.size() + " loaded world(s)");
        if (page > 0) button(inventory, actions, 48, Items.ARROW, "Previous Page", "Go back one page.", p -> openWorlds(p, page - 1));
        button(inventory, actions, 49, Items.ENDER_PEARL, "Teleportation Hub", "Return to the teleport menu.", TeleportMenu::open);
        if (page + 1 < pages) button(inventory, actions, 50, Items.ARROW, "Next Page", "Go forward one page.", p -> openWorlds(p, page + 1));
        open(player, inventory, actions, 6, "Admin World Teleports");
    }

    private static int teleportToIsland(ServerPlayer player, MultiOneSavedData.Island island, String label) {
        ServerLevel level = player.getServer().getLevel(island.dimension());
        if (level == null) {
            player.sendSystemMessage(Component.literal("The island's world is not loaded: " + island.dimension().location())
                    .withStyle(ChatFormatting.RED));
            return 0;
        }
        return teleport(player, level, island.pos().above(2), label);
    }

    private static int teleport(ServerPlayer player, ServerLevel level, BlockPos destination, String label) {
        player.closeContainer();
        level.getChunkAt(destination);
        player.teleportTo(level, destination.getX() + 0.5D, destination.getY(), destination.getZ() + 0.5D,
                player.getYRot(), player.getXRot());
        player.fallDistance = 0.0F;
        player.sendSystemMessage(Component.literal("Teleported to " + label + ".").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static void sendCurrentLocation(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("Location: " + player.level().dimension().location() + " "
                + player.blockPosition().toShortString()).withStyle(ChatFormatting.AQUA));
    }

    private static String currentLocationLore(ServerPlayer player) {
        return player.level().dimension().location() + " • " + player.blockPosition().toShortString();
    }

    private static String profileName(ServerPlayer viewer, UUID id) {
        return viewer.getServer().getProfileCache().get(id)
                .map(profile -> profile.getName())
                .orElseGet(() -> CommunitySavedData.get(viewer.serverLevel()).name(id));
    }

    private static Item structureIcon(String type) {
        return switch (type) {
            case "camp" -> Items.CAMPFIRE;
            case "tower" -> Items.STONE_BRICKS;
            case "factory" -> Items.BLAST_FURNACE;
            case "pirate_ship" -> Items.OAK_BOAT;
            case "sky_castle" -> Items.QUARTZ_BRICKS;
            case "shrine" -> Items.CHISELED_STONE_BRICKS;
            default -> Items.MOSSY_STONE_BRICKS;
        };
    }

    private static Item dimensionIcon(ResourceKey<Level> dimension) {
        if (dimension.equals(Level.NETHER)) return Items.NETHERRACK;
        if (dimension.equals(Level.END)) return Items.END_STONE;
        return Items.GRASS_BLOCK;
    }

    private static String titleCase(String value) {
        String[] words = value.replace('_', ' ').split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.isBlank()) continue;
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }

    private static void open(ServerPlayer player, SimpleContainer inventory,
                             Map<Integer, Consumer<ServerPlayer>> actions, int rows, String title) {
        player.openMenu(new SimpleMenuProvider(
                (containerId, playerInventory, ignored) -> new ActionMenu(rows, containerId, playerInventory, inventory, actions),
                Component.literal(title)));
    }

    private static void label(SimpleContainer inventory, int slot, Item item, String name, String lore) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD));
        stack.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY))));
        inventory.setItem(slot, stack);
    }

    private static void button(SimpleContainer inventory, Map<Integer, Consumer<ServerPlayer>> actions,
                               int slot, Item item, String name, String lore, Consumer<ServerPlayer> action) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD));
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.literal(lore).withStyle(ChatFormatting.GRAY),
                Component.literal("Click to select").withStyle(ChatFormatting.GREEN))));
        inventory.setItem(slot, stack);
        actions.put(slot, action);
    }

    @FunctionalInterface
    private interface PageOpener {
        void open(ServerPlayer player, int page);
    }
}
