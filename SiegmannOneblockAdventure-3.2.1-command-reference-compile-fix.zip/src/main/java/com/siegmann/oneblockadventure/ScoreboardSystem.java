package com.siegmann.oneblockadventure;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class ScoreboardSystem {
    private static boolean initialized;
    private ScoreboardSystem() {}

    public static void initialize(MinecraftServer server) {
        if (initialized) return;
        initialized = true;
        run(server, "scoreboard objectives add multione_phase dummy {\"text\":\"Siegmann Phase\",\"color\":\"gold\"}");
        run(server, "scoreboard objectives add multione_cash dummy {\"text\":\"Cash\",\"color\":\"green\"}");
        run(server, "scoreboard objectives add multione_prestige dummy {\"text\":\"Prestige\",\"color\":\"light_purple\"}");
        run(server, "scoreboard objectives add soa_rank dummy {\"text\":\"Adventure Rank\",\"color\":\"gold\"}");
        run(server, "scoreboard objectives setdisplay sidebar multione_phase");
        run(server, "scoreboard objectives setdisplay list multione_cash");
        run(server, "scoreboard objectives setdisplay below_name soa_rank");
    }

    public static void update(ServerPlayer player, long generated) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        initialize(server);
        int phase = CreateProgression.phase(generated).number();
        long cashLong = EconomySavedData.get(player.serverLevel()).balance(player.getUUID());
        int cash = (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, cashLong));
        String name = player.getGameProfile().getName();
        run(server, "scoreboard players set " + name + " multione_phase " + phase);
        run(server, "scoreboard players set " + name + " multione_cash " + cash);
        int prestige = PrestigeSavedData.get(player.serverLevel()).level(player.getUUID());
        run(server, "scoreboard players set " + name + " multione_prestige " + prestige);
        RankSystem.update(player, generated);
    }

    private static void run(MinecraftServer server, String command) {
        try {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
        } catch (RuntimeException ignored) {
            // Objective creation returns an error after it already exists; this is harmless.
        }
    }
}
