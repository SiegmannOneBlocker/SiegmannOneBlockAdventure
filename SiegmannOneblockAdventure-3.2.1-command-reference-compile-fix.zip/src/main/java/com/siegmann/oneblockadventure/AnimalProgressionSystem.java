package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Rare, phase-gated passive-animal events. Liquids are never generated as OneBlock states. */
public final class AnimalProgressionSystem {
    private AnimalProgressionSystem() {}

    public static void onPhaseComplete(ServerPlayer player, MultiOneSavedData.Island island, int phase) {
        // Guaranteed animal egg chests at useful farming milestones.
        if (phase == 10 || phase == 20 || phase == 30 || phase == 40 || phase == 70 || phase == 100) {
            RewardChestSystem.animalChest(player, island, phase);
        }
        // Rare live animal arrival; chance rises slightly through progression but stays controlled.
        if (phase < 5 || player.getRandom().nextDouble() >= Math.min(0.30D, 0.08D + phase / 2000.0D)) return;
        String entity = select(player, phase);
        BlockPos pos = island.pos().offset(2, 1, 2);
        MinecraftServer server = player.getServer();
        if (server == null) return;
        String command = "summon " + entity + " " + (pos.getX()+0.5D) + " " + pos.getY() + " " + (pos.getZ()+0.5D) + " {PersistenceRequired:1b}";
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withLevel(player.serverLevel()).withPosition(net.minecraft.world.phys.Vec3.atCenterOf(pos)).withSuppressedOutput(), command);
        player.sendSystemMessage(Component.literal("Animal event: a " + entity.substring(entity.indexOf(':') + 1).replace('_',' ') + " arrived!").withStyle(ChatFormatting.GREEN));
    }

    private static String select(ServerPlayer player, int phase) {
        int roll = player.getRandom().nextInt(100);
        if (phase >= 180 && roll < 2) return "minecraft:mooshroom";
        if (phase >= 120 && roll < 7) return "minecraft:horse";
        if (phase >= 70 && roll < 15) return "minecraft:rabbit";
        if (phase >= 40 && roll < 35) return "minecraft:pig";
        if (phase >= 30 && roll < 58) return "minecraft:sheep";
        if (phase >= 20 && roll < 80) return "minecraft:cow";
        return "minecraft:chicken";
    }
}
