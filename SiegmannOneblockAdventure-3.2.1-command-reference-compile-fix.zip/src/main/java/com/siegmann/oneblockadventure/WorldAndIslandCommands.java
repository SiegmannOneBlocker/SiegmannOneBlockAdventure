package com.siegmann.oneblockadventure;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.UUID;

@EventBusSubscriber(modid=SiegmannOneblockAdventure.MOD_ID)
public final class WorldAndIslandCommands {
 private WorldAndIslandCommands(){}
 @SubscribeEvent public static void register(RegisterCommandsEvent e){var d=e.getDispatcher();
  d.register(Commands.literal("islandteam").executes(c->{IslandTeamMenu.open(c.getSource().getPlayerOrException());return 1;})
   .then(Commands.literal("invite").then(Commands.argument("player",EntityArgument.player()).executes(c->invite(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player")))))
   .then(Commands.literal("accept").then(Commands.argument("owner",EntityArgument.player()).executes(c->accept(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"owner")))))
   .then(Commands.literal("decline").then(Commands.argument("owner",EntityArgument.player()).executes(c->decline(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"owner")))))
   .then(Commands.literal("kick").then(Commands.argument("player",EntityArgument.player()).executes(c->kick(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player")))))
   .then(Commands.literal("leave").executes(c->leave(c.getSource().getPlayerOrException())))
   .then(Commands.literal("permission").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("permission",StringArgumentType.word()).then(Commands.argument("value",BoolArgumentType.bool()).executes(c->permission(c.getSource().getPlayerOrException(),EntityArgument.getPlayer(c,"player"),StringArgumentType.getString(c,"permission"),BoolArgumentType.getBool(c,"value"))))))));
  d.register(Commands.literal("soaworld").requires(s->s.hasPermission(2))
   .then(Commands.literal("list").executes(c->worlds(c.getSource().getPlayerOrException())))
   .then(Commands.literal("sharedoneblock").then(Commands.literal("create").executes(c->shared(c.getSource().getPlayerOrException(),false))).then(Commands.literal("reset").then(Commands.literal("CONFIRM").executes(c->shared(c.getSource().getPlayerOrException(),true))))));
 }
 private static int invite(ServerPlayer p,ServerPlayer t){IslandTeamSavedData d=IslandTeamSavedData.get(p.serverLevel());UUID owner=d.ownerOf(p.getUUID());if(!owner.equals(p.getUUID())&&!d.permissions(p.getUUID()).invite()){p.sendSystemMessage(Component.literal("Only the island owner or a member with invite permission can invite."));return 0;}if(t.equals(p)||d.isMember(owner,t.getUUID()))return 0;d.invite(owner,t.getUUID());t.sendSystemMessage(Component.literal(p.getName().getString()+" invited you to their island. Use /islandteam accept "+p.getName().getString()).withStyle(ChatFormatting.GREEN));return 1;}
 private static int accept(ServerPlayer p,ServerPlayer owner){var d=IslandTeamSavedData.get(p.serverLevel());if(!d.accept(p.getUUID(),owner.getUUID())){p.sendSystemMessage(Component.literal("No invitation from that player."));return 0;}p.sendSystemMessage(Component.literal("Joined "+owner.getName().getString()+"'s island."));return 1;}
 private static int decline(ServerPlayer p,ServerPlayer owner){IslandTeamSavedData.get(p.serverLevel()).removeInvite(p.getUUID(),owner.getUUID());return 1;}
 private static int kick(ServerPlayer p,ServerPlayer t){var d=IslandTeamSavedData.get(p.serverLevel());if(!d.ownerOf(p.getUUID()).equals(p.getUUID())||!d.isMember(p.getUUID(),t.getUUID())||p.equals(t))return 0;d.removeMember(t.getUUID());return 1;}
 private static int leave(ServerPlayer p){var d=IslandTeamSavedData.get(p.serverLevel());if(d.ownerOf(p.getUUID()).equals(p.getUUID())){p.sendSystemMessage(Component.literal("Owners cannot leave their own island. Kick members or reset the island."));return 0;}d.removeMember(p.getUUID());return 1;}
 private static int permission(ServerPlayer p,ServerPlayer t,String key,boolean value){var d=IslandTeamSavedData.get(p.serverLevel());if(!d.ownerOf(p.getUUID()).equals(p.getUUID())||!d.isMember(p.getUUID(),t.getUUID())||p.equals(t))return 0;var x=d.permissions(t.getUUID());var n=switch(key.toLowerCase()){case"build"->new IslandTeamSavedData.Permissions(value,x.breakBlocks(),x.containers(),x.machines(),x.invite());case"break"->new IslandTeamSavedData.Permissions(x.build(),value,x.containers(),x.machines(),x.invite());case"containers"->new IslandTeamSavedData.Permissions(x.build(),x.breakBlocks(),value,x.machines(),x.invite());case"machines"->new IslandTeamSavedData.Permissions(x.build(),x.breakBlocks(),x.containers(),value,x.invite());case"invite"->new IslandTeamSavedData.Permissions(x.build(),x.breakBlocks(),x.containers(),x.machines(),value);default->null;};if(n==null)return 0;d.setPermissions(t.getUUID(),n);return 1;}
 private static int worlds(ServerPlayer admin){admin.sendSystemMessage(Component.literal("Loaded dimensions/worlds:").withStyle(ChatFormatting.GOLD));for(ServerLevel l:admin.getServer().getAllLevels())admin.sendSystemMessage(Component.literal("- "+l.dimension().location()+" spawn="+l.getSharedSpawnPos().toShortString()));admin.sendSystemMessage(Component.literal("Minecraft cannot safely create/delete normal save folders while the server is running. Use a new server world folder or a dimension-management mod for that."));return 1;}
 private static int shared(ServerPlayer admin,boolean reset){ServerLevel l=admin.getServer().overworld();BlockPos c=l.getSharedSpawnPos().atY(100);if(reset){for(int x=-12;x<=12;x++)for(int y=90;y<=112;y++)for(int z=-12;z<=12;z++)l.setBlockAndUpdate(c.offset(x,y-100,z),Blocks.AIR.defaultBlockState());}l.setBlockAndUpdate(c,Blocks.GRASS_BLOCK.defaultBlockState());l.setBlockAndUpdate(c.below(),Blocks.BEDROCK.defaultBlockState());l.setDefaultSpawnPos(c.above(),0F);for(ServerPlayer p:admin.getServer().getPlayerList().getPlayers())p.teleportTo(l,c.getX()+.5,c.getY()+1,c.getZ()+.5,p.getYRot(),p.getXRot());admin.sendSystemMessage(Component.literal("Shared OneBlock spawn created. This does not delete the save; it creates/resets the shared spawn platform safely."));return 1;}
}
