package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

@EventBusSubscriber(modid = SiegmannOneblockAdventure.MOD_ID)
public final class TimeRewardSystem {
    private TimeRewardSystem() {}

    public record Reward(int hours, Item icon, String name, String description, Consumer<ServerPlayer> grant) {}

    private static final List<Reward> REWARDS = List.of(
        new Reward(1, Items.BREAD, "Settler Supplies", "$2,500, 32 bread, and 32 torches.", p -> { AdventureSystem.addCash(p,2500); give(p,new ItemStack(Items.BREAD,32)); give(p,new ItemStack(Items.TORCH,32)); }),
        new Reward(2, Items.CHEST, "Common Crate Bundle", "$5,000 and 3 common crates.", p -> { AdventureSystem.addCash(p,5000); AdventureSavedData.get(p.serverLevel()).addCrate(p.getUUID(),"common",3); }),
        new Reward(4, Items.VILLAGER_SPAWN_EGG, "First Villager", "One villager spawn egg and $10,000.", p -> { AdventureSystem.addCash(p,10000); give(p,new ItemStack(Items.VILLAGER_SPAWN_EGG)); }),
        new Reward(6, Items.DIAMOND, "Mining Cache", "12 diamonds, 32 iron ingots, and one rare crate.", p -> { give(p,new ItemStack(Items.DIAMOND,12)); give(p,new ItemStack(Items.IRON_INGOT,32)); AdventureSavedData.get(p.serverLevel()).addCrate(p.getUUID(),"rare",1); }),
        new Reward(10, Items.VILLAGER_SPAWN_EGG, "Second Villager", "A second villager spawn egg, $25,000, and one epic crate.", p -> { AdventureSystem.addCash(p,25000); give(p,new ItemStack(Items.VILLAGER_SPAWN_EGG)); AdventureSavedData.get(p.serverLevel()).addCrate(p.getUUID(),"epic",1); }),
        new Reward(16, Items.EMERALD, "Trading Reserve", "64 emeralds and $50,000.", p -> { AdventureSystem.addCash(p,50000); give(p,new ItemStack(Items.EMERALD,64)); }),
        new Reward(24, Items.TOTEM_OF_UNDYING, "One-Day Reward", "A Totem of Undying and one legendary crate.", p -> { give(p,new ItemStack(Items.TOTEM_OF_UNDYING)); AdventureSavedData.get(p.serverLevel()).addCrate(p.getUUID(),"legendary",1); }),
        new Reward(36, Items.NETHERITE_INGOT, "Ancient Supply", "Four Netherite ingots and $150,000.", p -> { AdventureSystem.addCash(p,150000); give(p,new ItemStack(Items.NETHERITE_INGOT,4)); }),
        new Reward(48, Items.ELYTRA, "Veteran Reward", "An Elytra, one mythic crate, and $250,000.", p -> { AdventureSystem.addCash(p,250000); give(p,new ItemStack(Items.ELYTRA)); AdventureSavedData.get(p.serverLevel()).addCrate(p.getUUID(),"mythic",1); }),
        new Reward(72, Items.BEACON, "Three-Day Reward", "A Beacon, a Nether Star, and $500,000.", p -> { AdventureSystem.addCash(p,500000); give(p,new ItemStack(Items.BEACON)); give(p,new ItemStack(Items.NETHER_STAR)); })
    );

    private static int ticks;
    @SubscribeEvent
    public static void afterTick(ServerTickEvent.Post event) {
        if (++ticks < 20) return;
        ticks = 0;
        MinecraftServer server = event.getServer();
        AdventureSavedData data = AdventureSavedData.get(server.overworld());
        boolean changed = false;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            AdventureSavedData.Profile profile = data.profile(player.getUUID());
            profile.playTicks += 20L;
            changed = true;
            grantReached(player, profile);
        }
        if (changed) data.dirty();
    }

    private static void grantReached(ServerPlayer player, AdventureSavedData.Profile profile) {
        for (int i=0;i<REWARDS.size();i++) {
            Reward reward=REWARDS.get(i); long bit=1L<<i;
            if ((profile.timeRewardMask & bit)==0L && profile.playTicks >= reward.hours()*72000L) {
                profile.timeRewardMask |= bit;
                reward.grant().accept(player);
                player.sendSystemMessage(Component.literal("Playtime reward unlocked: "+reward.name()+" — "+reward.description()).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));
            }
        }
    }

    public static void openMenu(ServerPlayer p) {
        SimpleContainer c=new SimpleContainer(54); Map<Integer, Consumer<ServerPlayer>> actions=new HashMap<>();
        AdventureSavedData.Profile profile=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());
        long playedHours=profile.playTicks/72000L;
        ItemStack clock=new ItemStack(Items.CLOCK); clock.set(DataComponents.CUSTOM_NAME,Component.literal("Playtime: "+format(profile.playTicks)).withStyle(ChatFormatting.AQUA)); c.setItem(4,clock);
        int[] slots={10,11,12,13,14,15,16,19,20,21};
        for(int i=0;i<REWARDS.size();i++){
            Reward r=REWARDS.get(i); boolean claimed=(profile.timeRewardMask&(1L<<i))!=0; long remaining=Math.max(0L,r.hours()*72000L-profile.playTicks);
            ItemStack stack=new ItemStack(r.icon());
            stack.set(DataComponents.CUSTOM_NAME,Component.literal((claimed?"Claimed: ":"At "+r.hours()+" Hours: ")+r.name()).withStyle(claimed?ChatFormatting.GREEN:ChatFormatting.GOLD));
            stack.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal(r.description()).withStyle(ChatFormatting.GRAY),Component.literal(claimed?"Automatically received.":"Time remaining: "+format(remaining)).withStyle(claimed?ChatFormatting.GREEN:ChatFormatting.YELLOW))));
            c.setItem(slots[i],stack);
        }
        ItemStack info=new ItemStack(Items.WRITABLE_BOOK); info.set(DataComponents.CUSTOM_NAME,Component.literal("How rewards work").withStyle(ChatFormatting.AQUA)); info.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal("Only active online playtime counts."),Component.literal("Rewards are granted automatically."),Component.literal("Villagers unlock at 4 and 10 hours.")))); c.setItem(40,info);
        ItemStack back=new ItemStack(Items.ARROW); back.set(DataComponents.CUSTOM_NAME,Component.literal("Back")); c.setItem(49,back); actions.put(49,AdventureSystem::openMenu);
        p.openMenu(new SimpleMenuProvider((id,inv,pl)->new ActionMenu(6,id,inv,c,actions),Component.literal("Rewards & Playtime")));
    }

    public static int show(ServerPlayer p){ openMenu(p); return 1; }
    public static long playTicks(ServerPlayer p){ return AdventureSavedData.get(p.serverLevel()).profile(p.getUUID()).playTicks; }
    public static void setPlayHours(ServerPlayer p,int hours){ var d=AdventureSavedData.get(p.serverLevel()); var x=d.profile(p.getUUID()); x.playTicks=Math.max(0L,hours)*72000L; grantReached(p,x); d.dirty(); }
    private static String format(long ticks){ long seconds=Math.max(0,ticks)/20L; long h=seconds/3600; long m=(seconds%3600)/60; return h+"h "+m+"m"; }
    private static void give(ServerPlayer p,ItemStack s){ if(!p.getInventory().add(s))p.drop(s,false); }
}
