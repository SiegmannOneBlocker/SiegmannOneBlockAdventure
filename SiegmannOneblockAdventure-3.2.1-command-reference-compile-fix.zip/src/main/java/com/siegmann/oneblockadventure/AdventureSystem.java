package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class AdventureSystem {
    private AdventureSystem() {}
    public static int skillLevel(int xp){ return Math.max(0,(int)Math.sqrt(Math.max(0,xp)/25.0D)); }
    public static int islandLevel(ServerPlayer p,long generated){ AdventureSavedData.Profile x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID()); int prestige=PrestigeSavedData.get(p.serverLevel()).level(p.getUUID()); return (int)Math.min(Integer.MAX_VALUE, generated/100L + prestige*100L + (x.luckUpgrade+x.moneyUpgrade+x.rareUpgrade+x.mobDropUpgrade+x.storageUpgrade+x.experienceUpgrade)*25L); }
    public static long addCash(ServerPlayer p,long base){ AdventureSavedData d=AdventureSavedData.get(p.serverLevel()); AdventureSavedData.Profile x=d.profile(p.getUUID()); long amount=Math.max(0L,Math.round(base*d.globalCashMultiplier()*(1D+x.moneyUpgrade*0.05D)*PlayerClassSystem.cashMultiplier(p)*Stage31System.cashMultiplier(p))); EconomySavedData.get(p.serverLevel()).add(p.getUUID(),amount); x.cashEarned+=amount; d.dirty(); return amount; }
    public static void onOneBlockBreak(ServerPlayer p,long generated){ AdventureSavedData d=AdventureSavedData.get(p.serverLevel()); AdventureSavedData.Profile x=d.profile(p.getUUID()); x.blocksBroken++; x.miningXp+=PlayerClassSystem.miningXp(p,1+x.experienceUpgrade); if(generated>5000)x.engineeringXp+=PlayerClassSystem.engineeringXp(p,1); d.dirty(); double chance=(0.002D+x.luckUpgrade*0.0005D+x.rareUpgrade*0.0005D)*d.globalRareMultiplier(); if(p.getRandom().nextDouble()<chance){ x.luckyBlocks++; String tier=p.getRandom().nextDouble()<0.01?"mythic":p.getRandom().nextDouble()<0.05?"legendary":p.getRandom().nextDouble()<0.15?"epic":p.getRandom().nextDouble()<0.35?"rare":"common"; d.addCrate(p.getUUID(),tier,1); p.sendSystemMessage(Component.literal("✦ Lucky Block! You found a "+tier.toUpperCase(Locale.ROOT)+" crate. Use /crates open "+tier).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD)); }
    }
    public static int daily(ServerPlayer p){ AdventureSavedData d=AdventureSavedData.get(p.serverLevel()); AdventureSavedData.Profile x=d.profile(p.getUUID()); long day=LocalDate.now(ZoneOffset.UTC).toEpochDay(); if(x.lastDailyDay==day){p.sendSystemMessage(Component.literal("You already claimed today's reward."));return 0;} x.dailyStreak=x.lastDailyDay==day-1?x.dailyStreak+1:1; x.lastDailyDay=day; long cash=addCash(p,250L+Math.min(30,x.dailyStreak)*50L); String tier=x.dailyStreak%30==0?"mythic":x.dailyStreak%14==0?"legendary":x.dailyStreak%7==0?"epic":"common"; d.addCrate(p.getUUID(),tier,1); d.dirty(); p.sendSystemMessage(Component.literal("Daily streak "+x.dailyStreak+": +$"+cash+" and 1 "+tier+" crate!").withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD)); return 1; }
    public static int openCrate(ServerPlayer p,String tier){ tier=tier.toLowerCase(Locale.ROOT); AdventureSavedData d=AdventureSavedData.get(p.serverLevel()); if(!List.of("common","rare","epic","legendary","mythic").contains(tier)||!d.takeCrate(p.getUUID(),tier)){p.sendSystemMessage(Component.literal("You do not have that crate."));return 0;} int rank=List.of("common","rare","epic","legendary","mythic").indexOf(tier)+1; long cash=addCash(p,rank*rank*250L); ItemStack reward=switch(rank){case 1->new ItemStack(Items.IRON_INGOT,16);case 2->new ItemStack(Items.GOLD_INGOT,12);case 3->new ItemStack(Items.DIAMOND,6);case 4->new ItemStack(Items.NETHERITE_SCRAP,2);default->new ItemStack(Items.NETHERITE_INGOT,1);}; if(!p.getInventory().add(reward))p.drop(reward,false); AdventureSavedData.Profile x=d.profile(p.getUUID());x.cratesOpened++;d.dirty();p.sendSystemMessage(Component.literal("Opened "+tier+" crate: +$"+cash+" and "+reward.getCount()+"x "+reward.getHoverName().getString()).withStyle(ChatFormatting.LIGHT_PURPLE));return 1; }
    public static String season(){ int m=LocalDate.now().getMonthValue(); return m==12?"Winter Festival":m==10?"Haunted Factory":m>=6&&m<=8?"Summer Automation":m==3||m==4?"Spring Workshop":"Industrial Season"; }
    public static int teleportSpawn(ServerPlayer p) {
        var level = p.getServer().overworld();
        var pos = level.getSharedSpawnPos();
        p.teleportTo(level, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, p.getYRot(), p.getXRot());
        p.sendSystemMessage(Component.literal("Teleported to server spawn.").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    public static void openMenu(ServerPlayer p){
        SimpleContainer c=new SimpleContainer(54); Map<Integer,java.util.function.Consumer<ServerPlayer>> a=new HashMap<>();
        label(c,4,Items.NETHER_STAR,"Siegmann OneBlock Adventure","Choose a section below.");
        button(c,a,10,Items.COMPASS,"Progress","Phase counter, rank, milestones, and next unlock.",ExpansionSystem::openProgress);
        button(c,a,11,Items.GOLDEN_HELMET,"Leaderboards","Phase, money, prestige, playtime, ratings, and more.",ExpansionSystem::openLeaderboards);
        button(c,a,12,Items.GRASS_BLOCK,"Island","Island information, upgrades, and home teleport.",AdventureSystem::openIslandMenu);
        button(c,a,13,Items.EMERALD,"Shop","Unlocked items, quantities, selling, spawners, and premium kits.",ShopSystem::openCategories);
        button(c,a,14,Items.WRITABLE_BOOK,"Quests","View and claim progression quests.",QuestSystem::open);
        button(c,a,15,Items.DIAMOND_PICKAXE,"Skills & Kits","Skill levels and claimable skill kits.",AdventureSystem::openSkillsMenu);
        button(c,a,16,Items.CHEST,"Crates","Open earned reward crates.",AdventureSystem::openCratesMenu);
        button(c,a,19,Items.CLOCK,"Rewards","Playtime, milestone, kit, and progression rewards.",TimeRewardSystem::openMenu);
        button(c,a,20,Items.ENCHANTED_BOOK,"Premium Kits","Buy powerful enchanted progression kits.",PremiumKitSystem::openMenu);
        button(c,a,21,Items.BEACON,"Prestige","View and claim Endless Mode prestige.",AdventureSystem::openPrestigeMenu);
        button(c,a,22,Items.FIREWORK_STAR,"Cosmetics","Ranks, titles, particles, and break effects.",AdventureSystem::openCosmeticsMenu);
        button(c,a,23,Items.PLAYER_HEAD,"Statistics","Lifetime account and island statistics.",AdventureSystem::openStatsMenu);
        button(c,a,24,Items.GOLD_INGOT,"Marketplace","Browse player listings.",AdventureSystem::openMarketMenu);
        button(c,a,25,Items.MAP,"Adventure & Community","Structures, encyclopedia, achievements, merchant, events, and ratings.",ExpansionSystem::openHub);
        button(c,a,28,Items.ENDER_PEARL,"Teleportation Hub","Open all island, spawn, structure, event, and admin teleport destinations.",TeleportMenu::open);
        button(c,a,30,Items.LODESTONE,"Server Spawn","Return to server spawn.",pl->{pl.closeContainer();teleportSpawn(pl);});
        button(c,a,32,Items.CLOCK,"Daily Reward","Claim your daily streak reward.",AdventureSystem::openDailyMenu);
        button(c,a,33,Items.IRON_SWORD,"Competitive Events","Dragon Cup registration, PvP arena, leaderboards, and rewards.",CompetitiveMenu::open);
        button(c,a,34,Items.SUNFLOWER,"Season & Events","View the current seasonal event.",AdventureSystem::openSeasonMenu);
        button(c,a,37,Items.WRITTEN_BOOK,"Command Guide","Browse every player and administrator command by category.",CommandReferenceMenu::open);
        button(c,a,38,Items.EXPERIENCE_BOTTLE,"RPG Profession","Choose or review your permanent class and passive bonuses.",PlayerClassSystem::open);
        button(c,a,39,Items.BUNDLE,"Server Systems","Mail, backpack, auction house, public islands, and configuration-backed systems.",Stage25Menus::openHub);
        button(c,a,40,Items.RECOVERY_COMPASS,"World & Server Expansion","World profiles, Create milestones, live events, guide, hub, backups, and compatibility.",Stage31Menus::openHub);
        if(p.hasPermissions(2)){
            button(c,a,42,Items.COMMAND_BLOCK,"Administrator Control","Central control panel for worlds, structures, events, economy, players, and diagnostics.",AdminControlMenu::open);
            button(c,a,43,Items.COMPARATOR,"Server Diagnostics","Run live checks for progression, structures, worlds, events, and saved data.",DiagnosticsSystem::openMenu);
        }
        p.openMenu(new SimpleMenuProvider((id,inv,pl)->new ActionMenu(6,id,inv,c,a),Component.literal("Siegmann OneBlock Adventure")));
    }

    public static void openCratesMenu(ServerPlayer p){
        SimpleContainer c=new SimpleContainer(27);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();
        String[] tiers={"common","rare","epic","legendary","mythic"}; Item[] icons={Items.CHEST,Items.ENDER_CHEST,Items.AMETHYST_SHARD,Items.DIAMOND,Items.NETHER_STAR};
        for(int i=0;i<tiers.length;i++){String t=tiers[i];int slot=10+i;int count=AdventureSavedData.get(p.serverLevel()).crateCount(p.getUUID(),t);button(c,a,slot,icons[i],capitalize(t)+" Crates",count+" available",pl->{openCrate(pl,t);openCratesMenu(pl);});}
        back(c,a,22);open(p,c,a,3,"Crates");
    }
    public static void openSkillsMenu(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());SimpleContainer c=new SimpleContainer(36);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>(); skillButton(c,a,10,Items.DIAMOND_PICKAXE,"Mining",skillLevel(x.miningXp),x.miningXp,p,"mining");skillButton(c,a,12,Items.REDSTONE,"Engineering",skillLevel(x.engineeringXp),x.engineeringXp,p,"engineering");skillButton(c,a,14,Items.WHEAT,"Farming",skillLevel(x.farmingXp),x.farmingXp,p,"farming");skillButton(c,a,16,Items.IRON_SWORD,"Combat",skillLevel(x.combatXp),x.combatXp,p,"combat");back(c,a,31);open(p,c,a,4,"Skills & Kits");}
    public static void openStatsMenu(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());SimpleContainer c=new SimpleContainer(27);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();label(c,10,Items.STONE,"OneBlocks Broken",String.valueOf(x.blocksBroken));label(c,11,Items.GOLD_INGOT,"Cash Earned","$"+x.cashEarned);label(c,12,Items.CHEST,"Crates Opened",String.valueOf(x.cratesOpened));label(c,13,Items.NETHER_STAR,"Lucky Blocks",String.valueOf(x.luckyBlocks));label(c,14,Items.IRON_SWORD,"Bosses Defeated",String.valueOf(x.bossesDefeated));label(c,15,Items.BEACON,"Prestige",String.valueOf(PrestigeSavedData.get(p.serverLevel()).level(p.getUUID())));back(c,a,22);open(p,c,a,3,"Statistics");}
    public static void openIslandMenu(ServerPlayer p){long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());SimpleContainer c=new SimpleContainer(36);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();label(c,4,Items.GRASS_BLOCK,"Island Level",String.valueOf(islandLevel(p,g)));String[] n={"storage","luck","money","rare","mobdrops","experience"};Item[] it={Items.CHEST,Items.RABBIT_FOOT,Items.GOLD_INGOT,Items.DIAMOND,Items.ROTTEN_FLESH,Items.EXPERIENCE_BOTTLE};int[] lv={x.storageUpgrade,x.luckUpgrade,x.moneyUpgrade,x.rareUpgrade,x.mobDropUpgrade,x.experienceUpgrade};for(int i=0;i<n.length;i++){String type=n[i];int level=lv[i];long cost=1000L*(level+1)*(level+1);button(c,a,10+i,it[i],capitalize(type)+" Upgrade","Level "+level+" | Next: $"+cost,pl->{AdventureCommands.buyUpgrade(pl,type);openIslandMenu(pl);});}button(c,a,25,Items.ENDER_PEARL,"Teleportation Hub","Open island, spawn, structure, event, and admin destinations.",TeleportMenu::open);back(c,a,31);open(p,c,a,4,"Island");}
    public static void openCosmeticsMenu(ServerPlayer p){var x=AdventureSavedData.get(p.serverLevel()).profile(p.getUUID());long g=MultiOneSavedData.get(p.serverLevel()).byOwner(p.getUUID()).map(MultiOneSavedData.Island::generated).orElse(0L);SimpleContainer c=new SimpleContainer(54);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();int slot=0;button(c,a,slot++,Items.BARRIER,"No Custom Title","Display only your automatic rank.",pl->{AdventureCommands.setTitle(pl,"none");openCosmeticsMenu(pl);});for(String t:RankSystem.unlockedTitles(g)){if(slot>=36)break;String title=t;button(c,a,slot++,Items.NAME_TAG,title,x.title.equalsIgnoreCase(title)?"Equipped":"Unlocked by progression",pl->{AdventureCommands.setTitle(pl,title);openCosmeticsMenu(pl);});}String[] parts={"none","happy","flame","portal"};for(int i=0;i<parts.length;i++){String t=parts[i];button(c,a,37+i,Items.FIREWORK_STAR,capitalize(t)+" Particles",x.particle.equals(t)?"Equipped":"Click to equip",pl->{AdventureCommands.setParticles(pl,t);openCosmeticsMenu(pl);});}button(c,a,42,Items.GLOWSTONE_DUST,"Break Effects",x.breakEffects?"Enabled":"Disabled",pl->{AdventureCommands.toggleBreakEffects(pl);openCosmeticsMenu(pl);});back(c,a,49);open(p,c,a,6,"Ranks, Titles & Cosmetics");}
    public static void openDailyMenu(ServerPlayer p){SimpleContainer c=new SimpleContainer(27);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();button(c,a,13,Items.CLOCK,"Claim Daily Reward","Cash and a crate based on your streak.",pl->{daily(pl);openDailyMenu(pl);});back(c,a,22);open(p,c,a,3,"Daily Reward");}
    public static void openPrestigeMenu(ServerPlayer p){SimpleContainer c=new SimpleContainer(27);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();int level=PrestigeSavedData.get(p.serverLevel()).level(p.getUUID());label(c,11,Items.NETHER_STAR,"Current Prestige",String.valueOf(level));button(c,a,15,Items.BEACON,"Claim Prestige","Available during Endless Mode.",pl->{pl.closeContainer();MultiOneCommands.prestige(pl.createCommandSourceStack(),pl);});back(c,a,22);open(p,c,a,3,"Prestige");}
    public static void openMarketMenu(ServerPlayer p){SimpleContainer c=new SimpleContainer(54);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();int slot=0;for(var l:AdventureSavedData.get(p.serverLevel()).listings()){if(slot>=45)break;Item item=resolve(l.itemId());ItemStack st=new ItemStack(item,l.count());st.set(DataComponents.CUSTOM_NAME,Component.literal(l.count()+"x "+st.getHoverName().getString()).withStyle(ChatFormatting.GOLD));st.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal("$"+l.price()+" — Seller: "+l.sellerName()).withStyle(ChatFormatting.GRAY),Component.literal("Use /market buy "+l.id()).withStyle(ChatFormatting.GREEN))));c.setItem(slot++,st);}back(c,a,49);open(p,c,a,6,"Marketplace");}
    public static void openSeasonMenu(ServerPlayer p){SimpleContainer c=new SimpleContainer(27);Map<Integer,java.util.function.Consumer<ServerPlayer>>a=new HashMap<>();label(c,13,Items.SUNFLOWER,"Current Event",season());back(c,a,22);open(p,c,a,3,"Season");}

    private static void open(ServerPlayer p,SimpleContainer c,Map<Integer,java.util.function.Consumer<ServerPlayer>>a,int rows,String title){p.openMenu(new SimpleMenuProvider((id,inv,pl)->new ActionMenu(rows,id,inv,c,a),Component.literal(title)));}
    private static void back(SimpleContainer c,Map<Integer,java.util.function.Consumer<ServerPlayer>>a,int slot){button(c,a,slot,Items.BARRIER,"Back","Return to the main menu.",AdventureSystem::openMenu);}
    private static void button(SimpleContainer c,Map<Integer,java.util.function.Consumer<ServerPlayer>>a,int slot,Item item,String name,String lore,java.util.function.Consumer<ServerPlayer>action){ItemStack s=new ItemStack(item);s.set(DataComponents.CUSTOM_NAME,Component.literal(name).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));s.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal(lore).withStyle(ChatFormatting.GRAY),Component.literal("Click").withStyle(ChatFormatting.GREEN))));c.setItem(slot,s);a.put(slot,action);}
    private static void label(SimpleContainer c,int slot,Item item,String name,String value){ItemStack s=new ItemStack(item);s.set(DataComponents.CUSTOM_NAME,Component.literal(name).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));s.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal(value).withStyle(ChatFormatting.GRAY))));c.setItem(slot,s);}
    private static void skillButton(SimpleContainer c,Map<Integer,java.util.function.Consumer<ServerPlayer>>a,int slot,Item item,String name,int level,int xp,ServerPlayer player,String skill){int next=SkillKitSystem.nextKitLevel(player,skill);String lore="Level "+level+" | XP "+xp+" | "+(next<0?"All kits claimed":"Next kit: level "+next);button(c,a,slot,item,name,lore,pl->{SkillKitSystem.claim(pl,skill);openSkillsMenu(pl);});}
    private static void info(SimpleContainer c,int slot,Item item,String name,int level,int xp){label(c,slot,item,name,"Level "+level+" | XP "+xp);}
    private static String capitalize(String s){return s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}
    public static Item resolve(String id){ try{return BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));}catch(Exception e){return Items.AIR;} }
}
