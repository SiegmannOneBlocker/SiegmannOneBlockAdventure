package com.siegmann.oneblockadventure;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

import java.util.ArrayList;
import java.util.List;

/** Places protected progression chests beside the island instead of generating liquids as the OneBlock. */
public final class RewardChestSystem {
    private RewardChestSystem() {}

    public static void phaseChest(ServerPlayer player, MultiOneSavedData.Island island, int phase) {
        List<ItemStack> contents = new ArrayList<>();
        if (phase == 10) {
            contents.add(new ItemStack(Items.WATER_BUCKET));
            contents.add(new ItemStack(Items.KELP, 8));
            contents.add(new ItemStack(Items.SUGAR_CANE, 8));
        } else if (phase == 30) {
            contents.add(new ItemStack(Items.LAVA_BUCKET));
            contents.add(new ItemStack(Items.OBSIDIAN, 4));
            contents.add(new ItemStack(Items.FIRE_CHARGE, 4));
        } else if (phase % 25 == 0) {
            contents.add(new ItemStack(Items.CHEST, 2));
            contents.add(new ItemStack(Items.IRON_INGOT, Math.min(32, 6 + phase / 10)));
            contents.add(new ItemStack(Items.GOLD_INGOT, Math.min(16, 2 + phase / 25)));
            if (phase >= 100) contents.add(new ItemStack(Items.DIAMOND, Math.min(8, phase / 50)));
        } else return;
        place(player, island.pos(), contents, "Phase " + phase + " Reward Chest");
    }

    public static void animalChest(ServerPlayer player, MultiOneSavedData.Island island, int phase) {
        List<ItemStack> contents = new ArrayList<>();
        if (phase >= 10) contents.add(new ItemStack(Items.CHICKEN_SPAWN_EGG, 2));
        if (phase >= 20) contents.add(new ItemStack(Items.COW_SPAWN_EGG, 2));
        if (phase >= 30) contents.add(new ItemStack(Items.SHEEP_SPAWN_EGG, 2));
        if (phase >= 40) contents.add(new ItemStack(Items.PIG_SPAWN_EGG, 2));
        if (phase >= 70) contents.add(new ItemStack(Items.RABBIT_SPAWN_EGG, 2));
        if (phase >= 100) contents.add(new ItemStack(Items.HORSE_SPAWN_EGG, 1));
        if (!contents.isEmpty()) place(player, island.pos(), contents, "Animal Reward Chest");
    }

    private static void place(ServerPlayer player, BlockPos origin, List<ItemStack> contents, String name) {
        ServerLevel level = player.serverLevel();
        BlockPos target = findAir(level, origin);
        if (target == null) {
            for (ItemStack stack : contents) if (!player.getInventory().add(stack)) player.drop(stack, false);
            player.sendSystemMessage(Component.literal(name + " could not be placed, so its contents were delivered to you.").withStyle(ChatFormatting.YELLOW));
            return;
        }
        level.setBlockAndUpdate(target, Blocks.CHEST.defaultBlockState());
        if (level.getBlockEntity(target) instanceof ChestBlockEntity chest) {
            for (int i = 0; i < contents.size() && i < chest.getContainerSize(); i++) chest.setItem(i, contents.get(i));
            // ChestBlockEntity#setCustomName is not exposed in the NeoForge 1.21.1 mappings.
            // Keep the reward name in the player notification while leaving the chest GUI title vanilla.
            chest.setChanged();
        }
        player.sendSystemMessage(Component.literal("A " + name + " appeared near your OneBlock.").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD));
    }

    private static BlockPos findAir(ServerLevel level, BlockPos origin) {
        int[][] offsets = {{3,0},{-3,0},{0,3},{0,-3},{3,3},{-3,3},{3,-3},{-3,-3}};
        for (int[] o : offsets) {
            BlockPos p = origin.offset(o[0], 0, o[1]);
            if (level.getBlockState(p).isAir() && level.getBlockState(p.above()).isAir()
                    && !level.getBlockState(p.below()).isAir()) return p;
        }
        return null;
    }
}
