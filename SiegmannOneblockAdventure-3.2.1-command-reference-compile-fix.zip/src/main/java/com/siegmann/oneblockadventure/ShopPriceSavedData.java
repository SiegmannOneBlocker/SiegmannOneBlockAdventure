package com.siegmann.oneblockadventure;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Persistent administrator-controlled shop price percentages. 100% means the normal price. */
public final class ShopPriceSavedData extends SavedData {
    private static final String NAME = "siegmann_oneblock_shop_prices";
    private static final Factory<ShopPriceSavedData> FACTORY =
            new Factory<>(ShopPriceSavedData::new, ShopPriceSavedData::load, null);

    private int globalBuyPercent = 100;
    private int globalSellPercent = 100;
    private final Map<String, Integer> itemBuyPercent = new HashMap<>();
    private final Map<String, Integer> itemSellPercent = new HashMap<>();

    public static ShopPriceSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    public int globalBuyPercent() { return globalBuyPercent; }
    public int globalSellPercent() { return globalSellPercent; }
    public int itemBuyPercent(String itemId) { return itemBuyPercent.getOrDefault(normalize(itemId), 100); }
    public int itemSellPercent(String itemId) { return itemSellPercent.getOrDefault(normalize(itemId), 100); }

    public void setGlobalBuyPercent(int percent) { globalBuyPercent = clamp(percent); setDirty(); }
    public void setGlobalSellPercent(int percent) { globalSellPercent = clamp(percent); setDirty(); }
    public void setItemBuyPercent(String itemId, int percent) { itemBuyPercent.put(normalize(itemId), clamp(percent)); setDirty(); }
    public void setItemSellPercent(String itemId, int percent) { itemSellPercent.put(normalize(itemId), clamp(percent)); setDirty(); }

    public void resetGlobal() { globalBuyPercent = 100; globalSellPercent = 100; setDirty(); }
    public void resetItem(String itemId) {
        String key = normalize(itemId);
        itemBuyPercent.remove(key);
        itemSellPercent.remove(key);
        setDirty();
    }

    public long adjustedBuy(String itemId, long base) {
        return apply(apply(base, globalBuyPercent), itemBuyPercent(itemId));
    }

    public long adjustedSell(String itemId, long base) {
        return applyAllowZero(applyAllowZero(base, globalSellPercent), itemSellPercent(itemId));
    }

    private static long apply(long value, int percent) {
        if (value <= 0) return 0;
        return Math.max(1L, Math.round(value * (percent / 100.0D)));
    }

    private static long applyAllowZero(long value, int percent) {
        if (value <= 0 || percent <= 0) return 0;
        return Math.max(1L, Math.round(value * (percent / 100.0D)));
    }

    private static int clamp(int percent) { return Math.max(0, Math.min(10000, percent)); }
    private static String normalize(String id) { return id == null ? "" : id.toLowerCase(Locale.ROOT).trim(); }

    private static ShopPriceSavedData load(CompoundTag tag, HolderLookup.Provider provider) {
        ShopPriceSavedData data = new ShopPriceSavedData();
        data.globalBuyPercent = clamp(tag.contains("GlobalBuyPercent") ? tag.getInt("GlobalBuyPercent") : 100);
        data.globalSellPercent = clamp(tag.contains("GlobalSellPercent") ? tag.getInt("GlobalSellPercent") : 100);
        readMap(tag.getList("ItemBuyPercent", Tag.TAG_COMPOUND), data.itemBuyPercent);
        readMap(tag.getList("ItemSellPercent", Tag.TAG_COMPOUND), data.itemSellPercent);
        return data;
    }

    private static void readMap(ListTag list, Map<String, Integer> target) {
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            String id = normalize(entry.getString("Item"));
            if (!id.isBlank()) target.put(id, clamp(entry.getInt("Percent")));
        }
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putInt("GlobalBuyPercent", globalBuyPercent);
        tag.putInt("GlobalSellPercent", globalSellPercent);
        tag.put("ItemBuyPercent", writeMap(itemBuyPercent));
        tag.put("ItemSellPercent", writeMap(itemSellPercent));
        return tag;
    }

    private static ListTag writeMap(Map<String, Integer> source) {
        ListTag list = new ListTag();
        source.forEach((id, percent) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("Item", id);
            entry.putInt("Percent", percent);
            list.add(entry);
        });
        return list;
    }
}
