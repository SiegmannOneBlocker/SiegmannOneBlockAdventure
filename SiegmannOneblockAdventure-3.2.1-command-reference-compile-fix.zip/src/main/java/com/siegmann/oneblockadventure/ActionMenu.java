package com.siegmann.oneblockadventure;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.function.Consumer;

/** Server-side clickable chest menu. No client mod screen is required. */
public final class ActionMenu extends ChestMenu {
    private final Map<Integer, Consumer<ServerPlayer>> actions;
    private final int rows;
    private boolean handling;

    public ActionMenu(int rows, int containerId, Inventory inventory, Container container,
                      Map<Integer, Consumer<ServerPlayer>> actions) {
        super(typeForRows(rows), containerId, inventory, container, rows);
        this.actions = actions;
        this.rows = rows;
    }

    private static MenuType<?> typeForRows(int rows) {
        return switch (rows) {
            case 1 -> MenuType.GENERIC_9x1;
            case 2 -> MenuType.GENERIC_9x2;
            case 3 -> MenuType.GENERIC_9x3;
            case 4 -> MenuType.GENERIC_9x4;
            case 5 -> MenuType.GENERIC_9x5;
            default -> MenuType.GENERIC_9x6;
        };
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (handling) return;
        Consumer<ServerPlayer> action = actions.get(slotId);
        if (action != null && player instanceof ServerPlayer serverPlayer) {
            handling = true;
            try {
                action.accept(serverPlayer);
            } finally {
                handling = false;
            }
            return;
        }

        // All GUI inventories are display-only. Blocking every other click prevents
        // shift-click, number-key, drag, throw, and double-click duplication exploits.
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }
}
