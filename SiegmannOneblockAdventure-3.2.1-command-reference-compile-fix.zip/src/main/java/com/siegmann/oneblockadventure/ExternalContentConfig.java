package com.siegmann.oneblockadventure;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User-editable content files. Any valid registry ID from any installed mod can be used.
 * Invalid or missing IDs are ignored safely when the server is running.
 */
public final class ExternalContentConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIRECTORY = FMLPaths.CONFIGDIR.get().resolve("siegmann_oneblock_adventure");
    private static final Path PHASE_FILE = DIRECTORY.resolve("phase_additions.json");
    private static final Path SHOP_FILE = DIRECTORY.resolve("shop_offers.json");

    private static volatile Map<Integer, List<CreateProgression.WeightedBlock>> phaseAdditions = Map.of();
    private static volatile List<ShopSystem.Offer> shopOffers = List.of();

    private ExternalContentConfig() {}

    public static synchronized void load() {
        try {
            Files.createDirectories(DIRECTORY);
            writeExamplesIfMissing();
            phaseAdditions = Collections.unmodifiableMap(readPhaseAdditions());
            shopOffers = List.copyOf(readShopOffers());
            SiegmannOneblockAdventure.LOGGER.info("Loaded {} custom phase entries across {} phases and {} custom shop offers",
                    phaseAdditions.values().stream().mapToInt(List::size).sum(), phaseAdditions.size(), shopOffers.size());
        } catch (Exception exception) {
            SiegmannOneblockAdventure.LOGGER.error("Could not load SiegmannOneblockAdventure content configs", exception);
            phaseAdditions = Map.of();
            shopOffers = List.of();
        }
    }

    public static List<CreateProgression.WeightedBlock> blocksForPhase(int phase) {
        return phaseAdditions.getOrDefault(phase, List.of());
    }

    public static List<ShopSystem.Offer> shopOffers() {
        return shopOffers;
    }

    private static Map<Integer, List<CreateProgression.WeightedBlock>> readPhaseAdditions() throws IOException {
        Map<Integer, List<CreateProgression.WeightedBlock>> result = new HashMap<>();
        try (Reader reader = Files.newBufferedReader(PHASE_FILE)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null || !root.has("additions") || !root.get("additions").isJsonArray()) return result;
            for (JsonElement element : root.getAsJsonArray("additions")) {
                if (!element.isJsonObject()) continue;
                JsonObject entry = element.getAsJsonObject();
                int phase = integer(entry, "phase", 1);
                String id = string(entry, "block", "");
                int weight = integer(entry, "weight", 1);
                if (phase < 1 || phase > CreateProgression.STORY_PHASES || id.isBlank() || weight <= 0) continue;
                result.computeIfAbsent(phase, ignored -> new ArrayList<>())
                        .add(new CreateProgression.WeightedBlock(id, weight));
            }
        }
        return result;
    }

    private static List<ShopSystem.Offer> readShopOffers() throws IOException {
        List<ShopSystem.Offer> result = new ArrayList<>();
        try (Reader reader = Files.newBufferedReader(SHOP_FILE)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null || !root.has("offers") || !root.get("offers").isJsonArray()) return result;
            for (JsonElement element : root.getAsJsonArray("offers")) {
                if (!element.isJsonObject()) continue;
                JsonObject entry = element.getAsJsonObject();
                String id = string(entry, "item", "");
                int count = integer(entry, "count", 1);
                int buy = integer(entry, "buy", 0);
                int sell = integer(entry, "sell", 0);
                int unlock = integer(entry, "unlockPhase", 1);
                String category = string(entry, "category", "Custom");
                if (id.isBlank() || count <= 0 || buy < 0 || sell < 0 || unlock < 1 || unlock > CreateProgression.STORY_PHASES) continue;
                result.add(new ShopSystem.Offer(id, count, buy, sell, unlock, category));
            }
        }
        return result;
    }

    private static void writeExamplesIfMissing() throws IOException {
        if (Files.notExists(PHASE_FILE)) {
            JsonObject root = new JsonObject();
            root.addProperty("instructions", "Add blocks from any installed mod. Phase must be 1-250. Weight controls relative spawn chance. Restart the server or use /soa admin reload after editing.");
            JsonArray additions = new JsonArray();
            JsonObject example = new JsonObject();
            example.addProperty("phase", 40);
            example.addProperty("block", "examplemod:example_block");
            example.addProperty("weight", 3);
            additions.add(example);
            root.add("additions", additions);
            try (Writer writer = Files.newBufferedWriter(PHASE_FILE)) { GSON.toJson(root, writer); }
        }
        if (Files.notExists(SHOP_FILE)) {
            JsonObject root = new JsonObject();
            root.addProperty("instructions", "Add shop items from any installed mod. Set buy or sell to 0 to disable that direction. Restart the server or use /soa admin reload after editing.");
            JsonArray offers = new JsonArray();
            JsonObject example = new JsonObject();
            example.addProperty("item", "examplemod:example_item");
            example.addProperty("count", 1);
            example.addProperty("buy", 500);
            example.addProperty("sell", 50);
            example.addProperty("unlockPhase", 25);
            example.addProperty("category", "Custom");
            offers.add(example);
            root.add("offers", offers);
            try (Writer writer = Files.newBufferedWriter(SHOP_FILE)) { GSON.toJson(root, writer); }
        }
    }

    private static int integer(JsonObject object, String key, int fallback) {
        try { return object.has(key) ? object.get(key).getAsInt() : fallback; }
        catch (Exception ignored) { return fallback; }
    }

    private static String string(JsonObject object, String key, String fallback) {
        try { return object.has(key) ? object.get(key).getAsString() : fallback; }
        catch (Exception ignored) { return fallback; }
    }
}
