package com.siegmann.oneblockadventure.core;
import com.siegmann.oneblockadventure.core.profile.SoaProfiler;import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class ProfilerTest {@Test void capturesScope(){SoaProfiler.reset();try(var ignored=SoaProfiler.start("test")){}assertTrue(SoaProfiler.report().stream().anyMatch(s->s.startsWith("test:")));}}
