package com.siegmann.oneblockadventure.core;
import com.siegmann.oneblockadventure.core.event.*;import org.junit.jupiter.api.Test;import java.util.UUID;import java.util.concurrent.atomic.AtomicInteger;import static org.junit.jupiter.api.Assertions.*;
class SoaEventBusTest {@Test void dispatchesTypedEvent() throws Exception{AtomicInteger calls=new AtomicInteger();AutoCloseable sub=SoaEventBus.subscribe(GameplayEvents.QuestCompleted.class,e->calls.incrementAndGet());SoaEventBus.post(new GameplayEvents.QuestCompleted(UUID.randomUUID(),"q"));assertEquals(1,calls.get());sub.close();}}
