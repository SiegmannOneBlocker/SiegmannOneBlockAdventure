# SiegmannOneblockAdventure 3.1.0 — World & Production Systems

Added world rule profiles, spawn-hub generation, live events, Create factory metrics foundation, expanded in-game guide, compatibility diagnostics, safe save/backup marker command, and optional dashboard JSON export.

## Safety boundaries
- Loaded Minecraft world folders are never deleted or replaced by an in-game command.
- `/soastage31 backup` forces a Minecraft save and writes an audit marker; full snapshots remain the responsibility of the server host.
- Dashboard support exports JSON only and does not open a network port.
- Create metrics are persistent, but direct Create event adapters must be validated against the exact installed Create build.
