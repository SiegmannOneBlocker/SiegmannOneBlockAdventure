# SiegmannOneblockAdventure 2.2.0 — Teleportation & Menu Stage

## Player commands

- `/teleports` — opens the complete teleportation hub.
- `/warp` — alias for the teleportation hub.
- `/soa teleports` — opens the teleportation hub.
- `/spawn` and `/soa spawn` — immediately teleport to server spawn.
- `/soa tp` — legacy direct island-home teleport remains available.

## Teleportation hub

The main menu now links to one organized teleportation hub containing:

- My island / team owner island.
- Island-team destinations.
- Server spawn.
- PvP arena.
- Generated adventure structures.
- Dragon Cup and competitive-event menu.
- Current coordinates.
- Island team and permissions.
- Main-menu return button.

Operators also see:

- Loaded-world/dimension browser with click-to-spawn teleportation.
- Registered-island browser with pagination.

All destination data is revalidated when clicked. Removed islands, unloaded worlds, missing arenas, and removed structures fail safely instead of teleporting to stale coordinates.

## Safety and GUI behavior

- All teleport GUIs use `ActionMenu`, which blocks item movement, shift-clicking, hotbar swaps, drops, dragging, and double-click movement.
- Menus support pagination with 36 destinations per page.
- Destination chunks are loaded before teleporting.
- Fall distance is reset after teleporting.
- Team-island access is checked again at click time.
- Administrator-only destinations are permission checked both when opening and clicking.

## Compatibility note

This source was statically audited in the available environment. A real NeoForge compile and dedicated-server runtime test is still required before production deployment.
