# SiegmannOneblockAdventure 2.4.0 — Server Systems Expansion

## Added

- Persistent RPG profession system: Engineer, Farmer, Miner, Hunter, Merchant, and Explorer.
- Protected profession-selection GUI available through `/class` and the main menu.
- Profession bonuses integrated into cash, mining XP, and engineering XP calculations.
- Persistent server economy layer with separate buy and sell percentages.
- Central administrator control GUI through `/adminmenu`.
- New `/soasystems` command group for profession administration, economy controls, class locking, and season advancement.
- Main-menu entries for professions and the administrator control panel.
- Command-guide updates.

## Important stabilization fix

The pre-existing `CompetitiveSystem.commands` command tree contained a Java syntax error in the nested Dragon Cup schedule command. It was rewritten and now passes Java syntax parsing.

## Administrator commands

- `/adminmenu`
- `/soasystems`
- `/soasystems menu`
- `/soasystems class reset <player>`
- `/soasystems class set <player> <profession>`
- `/soasystems class lock <true|false>`
- `/soasystems economy status`
- `/soasystems economy buypercent <10-500>`
- `/soasystems economy sellpercent <10-500>`
- `/soasystems season next`

## Player commands

- `/class`
- `/class choose <engineer|farmer|miner|hunter|merchant|explorer>`

## Testing performed here

- ZIP/source layout inspection.
- Java lexical/delimiter validation for all newly added classes.
- Java parser pass across the complete project. The parser reaches dependency-resolution errors only; no remaining Java syntax error appears before missing NeoForge/Minecraft dependencies.
- Duplicate-class scan.
- Version metadata check.
- ZIP integrity check.

A full NeoForge compile and runtime test still requires Gradle with the exact server dependencies.
