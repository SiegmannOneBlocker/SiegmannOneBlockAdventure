# SiegmannOneblockAdventure 2.0.0 Command Audit

## Player commands
- `/menu` or `/soa menu` — organized main menu.
- `/soa startnew` — create the first random island.
- `/soa tp`, `/soa spawn`, `/soa progress`, `/soa info` — travel and progress.
- `/shop`, `/quests`, `/quest claim <number>`, `/skills`, `/kit <skill>`, `/kits`, `/rewards`, `/crates`, `/stats`, `/cosmetics`, `/market`, `/daily`, `/prestige`, `/endgame`.
- `/soa adventure` — community and exploration hub.
- `/leaderboard`, `/phasecounter`, `/structures locate`, `/encyclopedia`, `/collection`, `/achievements`, `/challenge`, `/artifacts`, `/merchant`, `/events`.
- `/soa rate <player> <1-5>` — island rating.

## Administrator commands
- `/soa admin resetplayer <player> CONFIRM` — complete destructive reset.
- `/soa admin structure generate <camp|ruin|shrine|tower|factory|pirate_ship|sky_castle|random>`.
- `/soa admin event start <name> <minutes>` and `/soa admin event stop`.
- `/soa admin weeklyboss`.
- `/soa admin auditcommands` and `/soa admin auditprogression`.
- Existing economy, phase, skill, crate, playtime, rank, shop percentage, and config reload commands remain registered.

## Reset coverage
The complete reset removes the registered island, nearby starter island blocks, eligibility lock, set cooldown, balance, marketplace listings, Adventure profile, crates, playtime rewards, daily streak, statistics, skill XP, skill kit claims, upgrades, cosmetics, title, prestige, quests, community profile, ratings, collection data, inventory, ender chest, XP, and scoreboard/rank state.

## Menu organization
The main menu is now grouped around Progress, Leaderboards, Island, Shop, Quests, Skills, Crates, Rewards, Premium Kits, Prestige, Cosmetics, Statistics, Marketplace, Adventure & Community, Island Home, Server Spawn, Daily Reward, and Season & Events.
