# SiegmannOneblockAdventure 2.3.0 — Final stabilization stage

## Added
- Clickable `/commands` and `/soa commands` command-reference menu.
- Operator-only `/soadiagnose` and `/soa admin diagnose`.
- Main-menu links for command help and server diagnostics.
- Read-only live checks for worlds, islands, structures, shop offers, all 250 phases, PvP arena, and Dragon Cup registration.
- Safer final-stage menu organization and documentation.

## Important testing boundary
This source package has been statically audited. A real NeoForge compile and multiplayer runtime test must still be performed with Java 21 and the supplied CraftBound dependency.
