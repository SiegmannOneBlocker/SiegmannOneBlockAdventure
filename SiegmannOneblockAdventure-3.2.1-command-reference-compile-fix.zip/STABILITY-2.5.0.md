# SiegmannOneblockAdventure 2.5.0 — Data-Driven Core

## Implemented

- Safe JSON configuration root under `config/siegmann_oneblock_adventure/` with eleven organized categories.
- Last-known-good configuration behavior: malformed JSON is reported and does not replace the active snapshot.
- `/soaconfig reload|status` administrator commands and a protected configuration status GUI.
- Persistent offline mail with `/mail`, `/mail send`, claim-by-click rewards, and administrator cash-reward mail.
- Persistent ten-tier virtual backpack with click withdrawal, main-hand deposit, capacity limits, and economy upgrades.
- Clickable `/ah` auction browser integrated with the existing marketplace and `/ah sell <price>`.
- Public island directory with owner privacy toggle and safe visit-time revalidation.
- `/systems` organized menu integrated into the main menu.
- Login notice for unclaimed mail.

## Deliberate safety choices

- Backpack storage records registry item IDs and counts; it rejects no data but does not preserve custom NBT/components. Valuable custom tools should remain in normal inventory until component-aware storage is added and runtime-tested.
- Configuration files are validated and exposed to future systems. Existing hard-coded progression remains the source of truth in this release to avoid silently changing live worlds.
- World file creation/deletion and backups remain outside a running server process because live save-folder mutation risks corruption.

## Commands

Player:
- `/systems`
- `/mail`
- `/mail send <player> <message>`
- `/backpack`
- `/ah`
- `/ah sell <price>`
- `/islandbrowser`

Administrator:
- `/soaconfig reload`
- `/soaconfig status`
- `/soamail reward <player> <cash> <message>`
