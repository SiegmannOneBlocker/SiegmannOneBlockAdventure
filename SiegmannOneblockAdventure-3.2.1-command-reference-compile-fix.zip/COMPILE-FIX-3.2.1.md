# Compile Fix 3.2.1

Fixed `CommandReferenceMenu.java` line 50.

The stream originally inferred `List<MutableComponent>`, while NeoForge/Minecraft's `ItemLore` constructor requires `List<Component>`.
The stream now explicitly maps to `Component`, preserving the same gray command lore while satisfying the constructor type.

A Gradle wrapper is not included in this source archive, so a full compile could not be run in this environment.
