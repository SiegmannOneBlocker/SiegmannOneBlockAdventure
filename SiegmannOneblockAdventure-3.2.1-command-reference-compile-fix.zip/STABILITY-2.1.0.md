# SiegmannOneblockAdventure 2.1.0 — Stability and Systems Pass

## Added

### Island teams and permissions
- `/islandteam` opens the team menu.
- `/islandteam invite <player>`
- `/islandteam accept <owner>`
- `/islandteam decline <owner>`
- `/islandteam kick <player>`
- `/islandteam leave`
- `/islandteam permission <player> build|break|containers|machines|invite <true|false>`
- Persistent invitations, membership, and permissions.

Important: the permission data is complete and persistent, but claim enforcement still depends on Open Parties & Claims. This release does not bypass or rewrite OPAC internals. Use the team system as the authoritative membership layer and configure OPAC consistently.

### World administration
- `/soaworld list` lists all loaded dimensions and their spawn positions.
- `/soaworld sharedoneblock create` creates a safe shared OneBlock spawn and teleports online players.
- `/soaworld sharedoneblock reset CONFIRM` clears a 25×23×25 area around shared spawn and rebuilds it.

Minecraft cannot safely create or delete ordinary save folders while a running dedicated server owns them. “Create a new world” should be performed by changing `level-name` while stopped or by using a dedicated dimension-management mod. The command intentionally does not pretend to do unsafe filesystem operations.

### Dragon Cup
- Phase 150 minimum.
- Maximum five registered competitors.
- 72-hour schedule persisted in world saved data.
- Ten-minute server-wide warning.
- `/dragoncup`, `/dragoncup register`, `/dragoncup leave`.
- Admin: `/soacompetitive dragon start|stop|schedulehours <hours>`.
- Teleports registered online players to the End, creates a dragon, ends after defeat or 45 minutes, and returns players to their islands.

### PvP arena
- Admin placement: `/soacompetitive arena generate`.
- Player commands: `/pvp`, `/pvp join`, `/pvp leave`, `/pvp leaderboard`.
- Persistent kills/deaths and a $250 kill reward.
- Competitive Events button added to the main menu.

## Structure-generation diagnosis
The custom `StructureSystem` places blocks directly. Vanilla “Generate Structures” world creation settings and ordinary gamerules do not disable direct block placement. Existing islands may not receive structures if generation only runs during new island creation. Use the structure audit and manual generation commands from 2.0.0 to distinguish an old-world issue from a placement failure.

## Verification performed in this environment
- ZIP integrity and source-tree checks.
- Java brace/string/comment lexical balance.
- Duplicate fully qualified class-name check.
- Command literal extraction and duplicate-root report.
- Saved-data `load`/`save` field review for the new systems.

## Verification not possible here
The environment cannot download Gradle/NeoForge dependencies and contains no installed Gradle distribution. A real `compileJava`, dedicated-server launch, client join, Create-machine integration test, and multiplayer runtime test must still be run on the target machine. No document should claim runtime perfection until those tests pass.
