@echo off
setlocal
where java >nul 2>nul || (
  echo Java was not found. Install Java 21 JDK first.
  pause
  exit /b 1
)
java -version
set "G1=C:\Users\Adams\Downloads\gradle-8.10.2-all\gradle-8.10.2\bin\gradle.bat"
set "G2=C:\Users\Adams\Downloads\gradle-8.10.2-all\bin\gradle.bat"
if exist "%G1%" (
  call "%G1%" build
) else if exist "%G2%" (
  call "%G2%" build
) else (
  echo Could not find Gradle in either expected location.
  echo Edit build-windows.bat and set the correct path to gradle.bat.
  pause
  exit /b 1
)
pause
