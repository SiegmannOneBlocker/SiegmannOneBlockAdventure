# SiegmannOneblockAdventure 3.2.0 — Phase 1 Refactor Foundation

This release begins the production cleanup without deleting legacy commands.

## Player join flow

First-time players receive a branded welcome with progression highlights and `/soa menu` instructions.
Returning players receive a compact dashboard containing OneBlock count, balance, factory tier, active event, and waiting mail.

## New grouped aliases

- `/soa home`
- `/soa guide`
- `/soa profile`
- `/soa admin menu`
- `/soa admin diagnostics`
- `/soa admin compatibility`

Existing roots remain registered so current documentation, command blocks, and player habits do not break during the refactor.

## Verification performed

- ZIP extraction and integrity checks.
- Java delimiter and package scans.
- Duplicate class-name scan.
- Command literal inventory generated.
- Join flow inspected against persistent player profile storage.

A real NeoForge compile and dedicated server test are still required for runtime verification.
