
## Version 1.8.0
- Every story phase now lasts 200 OneBlock breaks (50,000 total before Endless Mode).
- Added phase-specific block variation so the ten phases inside each era no longer share an identical pool.
- Added all vanilla wood families gradually: oak, birch, spruce, jungle, acacia, dark oak, mangrove, and cherry.
- Saplings and farming seeds are delivered through safe item rewards so they do not break instantly above the OneBlock bedrock base.
- The first 20 phases guarantee rotating farming and tree-progression essentials.
- Every completed phase grants one weighted random surprise reward; every tenth phase grants a second milestone roll.
- Common resources remain common, while diamonds, precision mechanisms, ancient debris, shulker shells, Totems, Nether Stars, and enchanted golden apples use low weights and late unlocks.
- Existing guaranteed milestone rewards remain in place, including buckets, a Create wrench, a water wheel, blaze rods, precision mechanisms, railway casings, a Netherite upgrade template, and the final Elytra.
- Added more natural, building, biome, Nether, sculk, and End blocks across all 250 phases.
- Retains the protected quest/menu interfaces, item-detail shop menus, dedicated section UIs, and `/spawn` support from version 1.7.0.


## Version 1.9.5 additions

- Added a final fluid-state safety filter to all built-in and custom phase entries.
- Water, flowing water, lava, and flowing lava can no longer be selected as the OneBlock.
- Added automatic cleanup for existing water or lava at registered OneBlock positions without advancing progress.
- Water and lava remain obtainable only from reward chests and skill kits.

## Version 1.9.1 additions
- 250 blocks per phase.
- Milestone reward chests for water and lava; liquids never become the OneBlock.
- Passive-animal events and spawn-egg chests.
- `/kit mining|engineering|farming|combat` with five progression tiers.
- 25 automatic progression ranks and unlockable titles.
- Rank prefix in player names and Adventure Rank below the name.
- Expanded `/soa admin` controls.


## Progression audit (1.9.5)
- Phase length remains 250 blocks.
- Unsafe crop, kelp, chorus, water, and lava block states are excluded from the OneBlock.
- Water is guaranteed in the Phase 10 reward chest; lava is guaranteed in the Phase 30 reward chest.
- Essential Create progression items are guaranteed at ten-phase milestones through Phase 250.
- Block quest thresholds were recalculated for 250-block phases.
- Operators can run `/soa admin auditprogression` after installing the full modpack to verify all registered phase blocks and guaranteed rewards.

## 1.9.5 shop quantity and administrator pricing controls

All base shop offers are one item. The amount menu no longer contains a 16-item option. Unstackable items only show a single-item purchase button; normal stackable items use 1, 4, 8, 32, and 64 where appropriate.

Operator-only pricing commands:

- `/soa admin shoppercent` — show global percentages.
- `/soa admin shoppercent global buy <percent>`
- `/soa admin shoppercent global sell <percent>`
- `/soa admin shoppercent global both <percent>`
- `/soa admin shoppercent item <namespace:item> buy <percent>`
- `/soa admin shoppercent item <namespace:item> sell <percent>`
- `/soa admin shoppercent item <namespace:item> both <percent>`
- `/soa admin shoppercent reset global`
- `/soa admin shoppercent reset item <namespace:item>`

`100%` is the normal price, `150%` is 1.5 times the normal price, and `50%` is half. Settings persist in the world save. Sell prices are still capped at one third of the current buy price to prevent buy-low/sell-high exploits. The global buy percentage also affects endgame spawners.

## Version 1.10.0 starter and premium kit update

New islands receive one water bucket, one lava bucket, one oak sapling, three wheat seeds, a complete stone tool set, food, torches, cobblestone, oak logs, bone meal, a crafting table, and a chest.

The main `/menu` now includes **Premium Kits**. Use `/kits` or `/soa kits` to open the same menu. Premium kits are expensive, phase-gated, repeatable purchases containing custom-named enchanted tools and valuable progression materials. Every purchase is checked server-side for phase and balance.


## Version 2.0.0 rewards and playtime update
- Added `/rewards` and `/soa rewards`, plus a Rewards button in `/menu`.
- Rewards menu lists obtainable timed rewards and explains how to earn them.
- Active online playtime is saved per player. Rewards are granted automatically.
- Villager spawn eggs are guaranteed at 4 and 10 hours.
- Additional milestones at 1, 2, 6, 16, 24, 36, 48, and 72 hours provide cash, crates, resources, and rare items.
- Admin command: `/soa admin setplayhours <player> <hours>`.

## Version 2.4.0 additions

Use `/class` to choose a persistent RPG profession. Operators can open `/adminmenu` for the centralized server control panel and use `/soasystems` for economy, profession, and season controls. See `STABILITY-2.4.0.md` for the complete command list and audit notes.

## Version 2.5.0 systems

Use `/systems` for the new mail, virtual backpack, auction house, public-island browser, and configuration status menus. Server-editable JSON is created automatically under `config/siegmann_oneblock_adventure/`. See `STABILITY-2.5.0.md` for commands and safety limitations.


## 3.1.0 World & Production Systems

New player menus: `/guide`, `/events`, `/createprogress`. New administrator menu: `/worldprofiles`. Administrative controls live under `/soastage31` for events, world profiles, spawn hub generation, safe save markers, dashboard JSON export, and compatibility checks.

## 3.2.0 Phase 1 — Refactor Foundation

- Added first-time welcome message and returning-player dashboard.
- Added grouped `/soa home`, `/soa guide`, `/soa profile`, and `/soa admin ...` aliases.
- Preserved legacy command roots for save and player compatibility.
- Added first-join detection without replacing existing player data.
- Added a Phase 1 command/menu audit document.
