# SiegmannOneblockAdventure 3.0.0 Architecture Stage

This stage introduces a maintainable architecture around the existing gameplay implementation without deleting compatibility-critical legacy systems.

## Added
- Lifecycle-based module registry with named modules for core, economy, shops, islands, Create, adventure, PvP, Dragon Cup, quests, structures, admin and API.
- Internal typed event bus and standard gameplay event records.
- Public `EconomyAPI` and `IslandAPI` facades.
- Storage abstraction with atomic JSON storage and JDBC support for SQLite/MySQL/MariaDB when a driver is supplied.
- Bounded two-thread async service for non-world work. World mutations must remain on the server thread.
- Lightweight profiler and operator commands.
- Schema migration metadata and startup migration.
- Startup/shutdown lifecycle handling.
- Unit tests for storage, event dispatch and profiler logic.

## New operator commands
- `/soa dev`
- `/soa profile`
- `/soa profile reset`
- `/soa modules`
- `/soa migrate`
- `/soa queues`

## Safety decisions
- Existing saved-data classes remain authoritative, avoiding destructive save migrations.
- JDBC is opt-in architecture only; JSON remains the default.
- No world block/entity operation is moved off-thread.
- Module failures are logged and isolated instead of terminating every module startup.

## Verification still required
Run `gradlew clean test build`, then a dedicated NeoForge server with the exact live modpack. Static checks cannot prove runtime compatibility with Create, Connector, OPAC or CraftBound.
