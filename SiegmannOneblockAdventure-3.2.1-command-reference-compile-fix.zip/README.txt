SiegmannOneblockAdventure 1.2.1 SOURCE
Minecraft 1.21.1 / NeoForge 21.1.235

CORE
- 250 Create-focused phases and endless endgame
- Unlimited prestige
- One-time create, 48-hour set cooldown, claim ownership check
- Bedrock under the OneBlock
- Economy, shop, quests, scoreboard and special messages

NEW FEATURE EXPANSION (NO VOTING REWARDS)
- /soa and /menu main menu
- /daily streak rewards
- Common, Rare, Epic, Legendary and Mythic crates
- Lucky-block crate drops while mining the OneBlock
- Mining and engineering skill progression framework
- Island level and purchasable Storage, Luck, Money, Rare, Mob Drops and Experience upgrades
- Statistics tracking for OneBlock breaks, cash earned, crates, lucky blocks and prestige
- Cosmetic title, particle preference and break-effect settings
- Seasonal event name rotation
- Persistent player marketplace: /market, /market sellhand <price>, /market buy <id>, /market cancel <id>
- Admin runtime controls: /soa admin cashmultiplier <value>, raremultiplier <value>, reload

MAIN COMMANDS
/soa
/soa create
/soa set
/soa tp
/soa progress
/soa shop
/soa quests
/soa endgame
/soa prestige
/menu
/daily
/crates [open <tier>]
/skills
/stats
/island [upgrade <type>]
/cosmetics
/season
/market

BUILD
Run build-windows.bat with Java 21. The JAR will be in build\libs.
Remove older versions before installing. Keep CraftBound OneBlock and Open Parties and Claims installed. Back up the world first.

IMPORTANT
The main menu is a chest-style navigation display. Minecraft inventory clicks are not wired as buttons in this source; each icon displays the command to use. Marketplace listings preserve the base item ID and stack count, but not custom item components/enchantments.


CUSTOM CONTENT CONFIG
On first server start, the mod creates:
config/siegmann_oneblock_adventure/phase_additions.json
config/siegmann_oneblock_adventure/shop_offers.json

Use registry IDs from ANY installed mod, for example create:shaft or farmersdelight:rich_soil.
Invalid or missing IDs are skipped safely. Run /soa admin reload after editing, or restart the server.
The built-in content remains active; these files add extra blocks and offers without editing Java.


AUDIT NOTES (1.2.1)
- Mod metadata now reads the version directly from the built JAR, preventing version mismatches.
- Shop window branding changed from MultiOne to Siegmann OneBlock.
- Config templates were JSON-validated.
- Existing craftbound_multione saved-data keys remain unchanged intentionally so upgrades keep player data. The Java package is now com.siegmann.oneblockadventure to prevent duplicate-package module conflicts with older CraftBound MultiOne builds.


IMPORTANT INSTALL NOTE
----------------------
REMOVE ALL OLD BUILDS named craftbound_multione*.jar or older SiegmannOneblockAdventure*.jar from the server mods folder before installing this build. Keep only the newest SiegmannOneblockAdventure JAR plus the original CraftBound OneBlock dependency.

VERSION 1.6.3 — AUDITED SHOP AND PROGRESSION
- The shop now automatically discovers every normal registered item from Minecraft and every installed mod.
- It is no longer limited to a hard-coded Create list.
- Use /shop page <number> to browse all pages.
- Use /shop search <name-or-modid> to filter items, for example /shop search create or /shop search copper.
- Every icon shows its global purchase number; buy it with /shop buy <number>.
- shop_offers.json overrides the generated count, buy price, sell price, unlock phase, and category for any item ID.
- Dangerous operator/technical items are excluded by default, but may be explicitly added through shop_offers.json.

VERSION 1.6.0 CLICKABLE MENU UPDATE
- /soa and /menu now open a clickable main menu.
- /shop now opens automatically generated clickable categories.
- Clicking a shop item purchases it directly.
- Previous/next page, categories, balance, sell hand, sell inventory, and back buttons are clickable.
- Categories are generated from every installed mod namespace, so newly installed mods appear automatically.
- /shop search <text> remains available because vanilla chest screens do not provide a text-entry box without a client-side custom screen.


VERSION 1.6.0 - RANDOM STARTER ISLANDS
- /soa startnew creates a first island at a random Overworld location.
- Random islands are centered in separate chunks and kept at least 5,000 blocks apart.
- Creates a 9x9 grass-and-dirt starter platform with bedrock beneath the OneBlock.
- Teleports the owner to the island and gives a small starter kit.
- The command is one-time for regular players. Admins may use /soa startnew <player>.
- Existing /soa create remains available for manual creation inside a player-owned claim.

1.6.0 POLISH AND BALANCE CHANGES
- The shop now completely hides locked items rather than displaying red locked entries.
- Categories with no unlocked offers are hidden automatically.
- Shop searches return unlocked items only.
- Direct /shop buy attempts still enforce the required phase on the server.
- Automatic prices now scale by item type, rarity, stack amount, and progression tier.
- Configured offers are sanitized to prevent negative values, invalid phase numbers, oversized stacks, and buy-low/sell-high exploits.
- Selling remains locked until Phase 250 is completed.
- Shop menus no longer send repeated selling-lock messages simply from being opened.
- Phase progress text now shows progress within the current 250-block phase.
- The Phase 250 transition is labeled Endless Mode rather than Phase 251.


VERSION 1.6.3 — ENDGAME SPAWNERS
--------------------------------
The clickable shop now contains a hidden Endgame Spawners category. It appears only after the player reaches Endless Tier 5. Individual spawners remain hidden until their required tier is reached. Spawners are buy-only and cannot be sold back to the shop.

Unlocks and prices:
- Tier 5: Zombie ($5,000,000), Skeleton ($5,000,000), Spider ($4,500,000)
- Tier 10: Creeper ($10,000,000)
- Tier 15: Blaze ($15,000,000)
- Tier 20: Enderman ($25,000,000)
- Tier 25: Witch ($35,000,000)
- Tier 30: Iron Golem ($50,000,000)


## Progression audit (1.9.5)
- Phase length remains 250 blocks.
- Unsafe crop, kelp, chorus, water, and lava block states are excluded from the OneBlock.
- Water is guaranteed in the Phase 10 reward chest; lava is guaranteed in the Phase 30 reward chest.
- Essential Create progression items are guaranteed at ten-phase milestones through Phase 250.
- Block quest thresholds were recalculated for 250-block phases.
- Operators can run `/soa admin auditprogression` after installing the full modpack to verify all registered phase blocks and guaranteed rewards.
